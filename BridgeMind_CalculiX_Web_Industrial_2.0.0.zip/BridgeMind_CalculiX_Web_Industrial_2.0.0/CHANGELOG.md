# 变更记录

## 2.0.0 - 2026-08-19

- 应用版本升级为 BridgeMind 2.0.0，BSDL Industrial 语言版本保持独立的 1.1.0。
- 新增设计上下文、需求、目标、约束、偏好、变量、任务书、候选、评价计划、评价结果、设计迭代和人工决策语义。
- 固定生成式设计为 `modeling → computation → evaluation → feedback`；“生成”不作为平行环节。
- 新增自然语言设计意图编译、多候选生成、桥塔/拱桥/梁系参数化物化和透明 Pareto 筛选。
- 新增真实空间梁候选预览，并明确 `authoritative=false` 和部分证据状态。
- 新增完整工程证据覆盖率、最终选择闸门、人类批准、Design Skill 固化和动态技能读回。
- 新增 BridgeMind 2.0 Web 面板、API、CLI、桥塔示例和专项测试。
- 代理或占位来源不能标记为 `verified`；部分目标证据不能直接选择候选。

# Changelog

## 1.1.0 — 2026-08-14

- 接通 BSDL Experience 的跨项目自动读回链，策略生成默认先运行规则专家，再检索历史经验。
- 新增与项目本地 ID、绝对坐标解耦的 Region 特征描述和稳定 Feature Signature。
- 历史网格尺寸改为以 `targetSize/baseSize` 形式迁移，避免直接复制绝对尺寸。
- 新增 Memory 相似度、可信权重、多经验聚合、`needs_review` 安全门和 FEA/人工区域保护。
- 读回经验自动写入 `experienceRefs`、Region attributes、CognitiveMap `experience` 决策边、Feedback 与 Audit。
- 新增默认 `memory_policy` 模板以及 `/memory/preview` 只读预览 API。
- 保持 SQLite Schema 向后兼容，新版 Feature/Action Descriptor 复用 JSON 列保存。
- 新增跨项目新用户继承回归测试，完整测试集由 26 项增加到 29 项。

## 1.0.0 — 2026-08-13

- 将本地 BSDL 研究 Demo 升级为响应式手机触控 PWA 和可部署网站。
- 增加 BSDL Industrial 1.0 Schema、迁移、工业验证和能力矩阵。
- 增加 CalculiX 2.23 混合梁/壳/实体/T3D2 导出、静态检查、运行、DAT 回读和结果写回。
- 增加摩擦接触、四种预应力表示和施工阶段编译。
- 增加 IFC 4.3 可选导入、项目 MVD Profile、源身份与转换损失报告。
- 增加版本化规则包、规范验算结果和审计修订。
- 增加 API 密钥、生产路径、Docker、Compose、Nginx、健康检查和持久化卷。
- 增加工业示例、预应力夹具和工业/API/PWA/部署自动测试。
- 增加手机与桌面网页的浏览器会话密钥输入，自动附加 `X-API-Key` 并清除无效凭据。
