# BridgeMind 2.0 + BSDL Industrial 1.1.0

BridgeMind 2.0 是面向桥梁生成式设计与工程分析的可运行原型。它在既有 BridgeMind 1.1.0 的点云/BIM、结构语义、有限元建模、CalculiX、版本治理和经验读回基础上，增加了设计意图、多目标、候选方案、参数化模型物化、计算证据、人工决策与设计 Skill 固化语义。

BridgeMind 2.0 固定采用以下生成式设计闭环：


a) `modeling`：根据设计意图生成并物化候选模型；

b) `computation`：调用确定性建模、网格和求解工具获得结果；

c) `evaluation`：按活动目标与硬约束评价候选；

d) `feedback`：由工程证据和人工决定下一轮建模动作。

“生成”不是与建模、计算、评价并列的独立环节。Agent 的职责是理解意图、规划任务、选择与调用方法、读取反馈，并推进下一次 `modeling`。

## 1. 版本关系

| 项目 | 版本 | 含义 |
|---|---:|---|
| BridgeMind 应用 | `2.0.0` | 上游设计意图、多目标候选和人机反馈闭环 |
| BSDL Industrial | `1.1.0` | 工业结构语义、设计过程语义与执行证据契约 |
| CalculiX Adapter | `1.1.0` | BSDL 到 CalculiX 2.23 的确定性适配器 |

## 2. BridgeMind 2.0 解决的语义链

```text
自然语言与场地条件  # 上游设计输入。
→ Requirement / Objective / Constraint / Preference / DesignVariable  # 机器可执行设计意图。
→ CandidateScheme  # 可比较候选方案。
→ BSDL Component / Connection / Material / Load  # 物理与结构语义。
→ AnalysisTask / MeshPolicy / SolverPlan  # 分析执行语义。
→ Result / Evidence / EvaluationResult  # 计算与评价证据。
→ Human Decision / Revision / Design Skill  # 人工批准、版本和经验固化。
```

它重点打通“设计意图—候选模型—分析执行—评价反馈”的对象链，而不是把自然语言、几何、网格或求解器文件混为同一个模型。

## 3. 已实现能力

| 能力 | 状态 | 主要入口 |
|---|---|---|
| 自然语言设计意图编译 | 已实现规则化原型 | `bridge_mind/design/engine.py::compile_design_intent` |
| 多目标、硬约束、偏好与设计变量 | 已实现 | `designProcess` 与 BSDL 1.1 Schema |
| 多候选生成与动态 Design Skill 读回 | 已实现 | `generate_design_candidates` |
| 候选参数化物化 | 已实现桥塔、拱桥和最小梁系生成器 | `bridge_mind/design/generators.py` |
| 固定生成式四阶段迭代 | 已实现 | `designProcess.iterations` |
| 透明概念筛选与 Pareto 分层 | 已实现，明确标记 `screening_surrogate` | `evaluate_design_candidates` |
| 候选空间梁数值预览 | 已实现，标记 `authoritative=false` | `preview_project_design_candidate` |
| 完整工程证据写入 | 已实现 | `record_design_evidence` |
| 最终选择证据闸门 | 已实现 | 只有完整 `verified` 结果可被人工 `selected` |
| 人工反馈与 Design Skill 固化 | 已实现 | `apply_design_feedback`、`build_design_skill` |
| BridgeMind 1.1 原有点云/BIM、认知地图与经验链 | 保留 | `bridge_mind/importers/`、`cognition/`、`memory.py` |
| CalculiX 工业执行、结果回读和转换损失报告 | 保留 | `bridge_mind/adapters/calculix.py` |
| Web 端 BridgeMind 2.0 面板 | 已实现 | `web/index.html`、`web/app.js` |

## 4. 证据边界

BridgeMind 2.0 区分三种状态：

- `screening_surrogate`：透明代理或启发式筛选，只用于排序候选；
- `partially_verified`：部分目标或约束已有真实证据，但覆盖不完整；
- `verified`：评价计划中的全部活动目标和硬约束均有可追溯证据。

系统执行以下硬约束：

1. 代理筛选不能冒充有限元或工程验证；
2. 内置空间梁预览是真实数值计算，但只是窄域、非权威预览；
3. 最终 `selected` 必须由人类批准，并引用完整 `verified` 工程评价；
4. Design Skill 只能从人类批准且证据完整的决策中固化；
5. Schema 通过、求解成功和工程放行是三个不同等级的事实。

## 5. 五分钟启动

```bash
python -m pip install -r requirements.txt  # 安装运行依赖。
python scripts/run_lan.py  # 启动本机与局域网 Web 服务。
```

浏览器访问 `http://127.0.0.1:8000`。页面中的“BridgeMind 2.0 生成式设计”区域支持：

- 编译设计意图；
- 生成候选；
- 运行代理筛选；
- 逐候选物化和数值预览；
- 写入外部 FEA、规范、试验或人工审查证据；
- 人工选择、拒绝或要求修订；
- 将批准决策固化为新的设计 Skill。

## 6. CLI 示例

```bash
python -m bridge_mind validate examples/bridge_pylon_design_2.0.bsdl.json  # 验证 BridgeMind 2.0 桥塔示例。
python -m bridge_mind design-run examples/two_girder_bridge.bsdl.json --text "设计一座倒Y型桥塔，兼顾安全、造型和可建造性" --count 4 --output runs/pylon_candidates.bsdl.json  # 编译意图并生成候选。
python -m bridge_mind design-materialize runs/pylon_candidates.bsdl.json --candidate DESIGN_CANDIDATE_ID --output runs/pylon_materialized.bsdl.json  # 物化指定候选；把占位 ID 替换为上一步输出中的真实 ID。
```

`design-run` 只完成意图编译、候选建模提案和透明代理筛选，不会自动宣布工程最优。

## 7. HTTP API

主要接口：

- `POST /api/projects/{project_id}/design/intent`
- `POST /api/projects/{project_id}/design/candidates`
- `POST /api/projects/{project_id}/design/materialize`
- `POST /api/projects/{project_id}/design/preview`
- `POST /api/projects/{project_id}/design/evaluate`
- `POST /api/projects/{project_id}/design/evidence`
- `POST /api/projects/{project_id}/design/feedback`
- `POST /api/projects/{project_id}/design/skills`
- `POST /api/projects/{project_id}/design/cycle`

`design/cycle` 会运行全部候选的建模—计算—评价流程，但在人工最终决策前停止。

## 8. 示例

`examples/bridge_pylon_design_2.0.bsdl.json` 展示：

- 多目标桥塔设计意图；
- 四个候选方案；
- 固定 `modeling → computation → evaluation → feedback` 迭代；
- 已物化候选的结构语义、网格与求解预览契约；
- 代理筛选结果与部分有限元预览证据；
- 未被错误标记为最终批准方案。

## 9. 验证

```bash
pytest -q  # 运行全部自动化测试。
python tools/self_check.py  # 运行项目综合自检。
node --check web/app.js  # 检查浏览器脚本语法。
```

设计闭环专项测试位于 `tests/test_design_2.py`，覆盖意图编译、硬约束保持、代理证据标签、候选物化、部分证据闸门、完整证据、人类批准、Skill 固化和技能读回。

## 10. 工程边界

本版本是研究与 Demo 原型，不是无人审查的桥梁工程放行系统。真实工程仍需责任工程师确认设计任务、结构理想化、荷载与边界条件、求解器适用性、网格收敛、规范验算、试验或监测证据，以及最终方案批准。

详细设计见：

- `docs/BRIDGEMIND_2_DESIGN_LOOP.md`
- `docs/BSDL_Industrial_1.1_语言规范.md`
- `docs/CalculiX_工业实现说明.md`
- `docs/能力边界与验证声明.md`
