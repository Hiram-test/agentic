# BridgeMind 2.0 快速启动

## 1. 安装与启动

```bash
python -m pip install -r requirements.txt  # 安装核心运行依赖。
python scripts/run_lan.py  # 启动 Web 服务并打印本机与局域网地址。
```

电脑访问 `http://127.0.0.1:8000`。首次启动会建立 SQLite 数据库，并载入包含 BridgeMind 2.0 桥塔设计语义的示例项目。

## 2. Web 演示顺序

1. 选择“BridgeMind 2.0 桥塔多目标生成式设计”项目；
2. 在自然语言设计任务中输入桥型、尺寸、目标、约束与偏好；
3. 点击“编译意图”；
4. 点击“生成候选”；
5. 点击“代理筛选”；
6. 对候选执行“物化 + FEA 预览”；
7. 检查候选是否为 `screening`、`partial` 或 `verified`；
8. 写入真实外部工程证据；
9. 由工程师批准候选；
10. 将批准决策固化为 Design Skill。

## 3. 固定闭环

```text
modeling  # 生成并物化候选模型。
→ computation  # 调用网格、求解器或其他确定性工程技能。
→ evaluation  # 根据目标、约束和证据评价候选。
→ feedback  # 人工或系统决定下一轮建模动作。
```

“生成”是这一闭环的运行范式，不是第五个平行步骤。

## 4. CLI 最小验证

```bash
python -m bridge_mind validate examples/bridge_pylon_design_2.0.bsdl.json  # 验证 BSDL 1.1 桥塔示例。
python -m bridge_mind design-run examples/two_girder_bridge.bsdl.json --text "设计一座倒Y型桥塔，兼顾安全、造型和可建造性" --count 4 --output runs/pylon_candidates.bsdl.json  # 生成并筛选候选。
```

## 5. 重要限制

- 代理筛选结果不等于工程评价；
- 内置空间梁预览不等于高保真桥塔有限元；
- `partially_verified` 不允许最终选择；
- `selected` 必须同时具备完整 `verified` 证据和人类批准；
- 只有批准决策才能固化为可读回 Design Skill。
