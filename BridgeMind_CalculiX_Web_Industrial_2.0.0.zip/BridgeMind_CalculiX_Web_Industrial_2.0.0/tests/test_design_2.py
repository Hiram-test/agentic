"""验证 BridgeMind 2.0 的设计意图、多目标候选、模型物化、证据门槛和技能读回。"""  # 说明测试文件用途。
from __future__ import annotations  # 启用延迟类型注解。
from pathlib import Path  # 提供临时数据库和项目路径类型。
from typing import Any  # 提供通用 JSON 类型注解。
import pytest  # 提供异常断言和测试框架。
from fastapi.testclient import TestClient  # 提供同步 API 测试客户端。
from bridge_mind.api import create_app  # 导入可测试应用工厂。
from bridge_mind.design.engine import apply_design_feedback, build_design_skill, compile_design_intent, evaluate_design_candidates, generate_design_candidates, materialize_design_candidate, record_design_evidence  # 导入 BridgeMind 2.0 设计闭环函数。
from bridge_mind.service import BridgeMindService  # 导入高层项目与修订编排服务。
from bridge_mind.utils import deep_copy, load_json  # 导入文档复制与 JSON 读取工具。
from bridge_mind.validator import validate_document  # 导入完整 BSDL 验证器。


ROOT = Path(__file__).resolve().parents[1]  # 获取项目根目录。
DESIGN_TEXT = "请设计一座倒Y型桥塔，高度80 m，材料体积分数不超过30%，兼顾结构安全、造型质量和可建造性。"  # 定义稳定的多目标桥塔任务。


def _compile_and_generate(document: dict[str, Any], count: int = 4) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:  # 构造可复用的意图编译与候选生成夹具。
    compiled, intent_report = compile_design_intent(document, DESIGN_TEXT, "software.test.design")  # 编译自然语言设计意图。
    generated, generation_report = generate_design_candidates(compiled, intent_report["briefId"], count, "software.test.design", None)  # 生成受约束候选方案。
    return generated, intent_report, generation_report  # 返回候选文档和两个步骤报告。


def _full_engineering_payload(document: dict[str, Any], candidate_id: str, evidence_ref: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:  # 为契约测试构造完整且显式的工程评价载荷。
    process = document["designProcess"]  # 读取设计过程对象。
    candidate = next(item for item in process["candidates"] if item["id"] == candidate_id)  # 查找目标候选。
    plan = next(item for item in process["evaluationPlans"] if item["briefRef"] == candidate["briefRef"] and item["status"] == "active")  # 查找活动评价计划。
    objectives = {item["id"]: item for item in process["objectives"]}  # 建立设计目标索引。
    constraints = {item["id"]: item for item in process["constraints"]}  # 建立设计约束索引。
    objective_values = [{"objectiveRef": objective_ref, "rawValue": 0.80, "normalizedValue": 0.80, "unit": objectives[objective_ref].get("unit"), "direction": objectives[objective_ref]["direction"], "source": "independent_engineering_review_fixture", "evidenceRefs": [evidence_ref], "confidence": 0.90} for objective_ref in plan["objectiveRefs"]]  # 为每个活动目标提供一条非代理工程值。
    constraint_checks = []  # 初始化硬约束检查列表。
    for constraint_ref in plan["constraintRefs"]:  # 遍历评价计划约束。
        constraint = constraints[constraint_ref]  # 读取约束定义。
        if not constraint.get("hard", True):  # 跳过非硬约束。
            continue  # 继续下一约束。
        variable_ref = constraint["expression"]  # 读取约束绑定变量。
        value = candidate["variableValues"].get(variable_ref)  # 读取候选变量值。
        constraint_checks.append({"constraintRef": constraint_ref, "passed": True, "value": value, "limit": constraint.get("limit"), "unit": constraint.get("unit"), "margin": 0.0, "source": "independent_engineering_review_fixture", "evidenceRefs": [evidence_ref], "message": "测试夹具显式确认该硬约束通过。"})  # 为每个硬约束提供一条显式检查。
    return objective_values, constraint_checks  # 返回完整目标和约束证据载荷。


def test_design_intent_compiles_to_bsdl_1_1_and_multi_objective_brief(bridge_document: dict[str, Any]) -> None:  # 检查上游设计语义能够进入 BSDL 1.1。
    compiled, report = compile_design_intent(bridge_document, DESIGN_TEXT, "software.test.design")  # 编译桥塔设计任务。
    process = compiled["designProcess"]  # 读取设计过程对象。
    assert compiled["languageVersion"] == "1.1.0"  # 确认语言升级到 BSDL 1.1.0。
    assert report["bridgeType"] == "pylon"  # 确认桥塔语义被识别。
    assert {item["category"] for item in process["objectives"]} == {"safety", "aesthetic", "constructability"}  # 确认三类目标被结构化。
    assert abs(sum(float(item["weight"]) for item in process["objectives"]) - 1.0) < 1.0e-9  # 确认多目标权重归一。
    height_constraint = next(item for item in process["constraints"] if item["id"] == "design.constraint.height")  # 读取桥塔高度硬约束。
    assert height_constraint["operator"] == "==" and height_constraint["limit"] == 80.0  # 确认固定高度被表达为硬等式。
    assert validate_document(compiled)["valid"] is True  # 确认完整 BSDL 验证通过。


def test_candidate_generation_preserves_hard_equalities_and_labels_proxy_screening(bridge_document: dict[str, Any]) -> None:  # 检查候选生成不破坏硬条件且不冒充工程证据。
    generated, intent_report, generation_report = _compile_and_generate(bridge_document, 4)  # 编译任务并生成四个候选。
    candidates = generated["designProcess"]["candidates"]  # 读取候选列表。
    assert generation_report["candidateCount"] == 4  # 确认候选数量满足预算。
    assert all(candidate["variableValues"]["design.variable.height"] == 80.0 for candidate in candidates)  # 确认所有候选保持高度硬等式。
    evaluated, evaluation_report = evaluate_design_candidates(generated, intent_report["briefId"], generation_report["candidateIds"], "software.test.design")  # 执行透明代理筛选。
    results = evaluated["designProcess"]["evaluationResults"]  # 读取筛选结果。
    assert evaluation_report["requiresEngineeringVerification"] is True  # 确认筛选报告明确要求工程验证。
    assert all(result["evidenceLevel"] == "screening_surrogate" for result in results)  # 确认代理筛选等级没有伪装成 FEA。
    assert all(result["status"] == "needs_engineering_verification" for result in results)  # 确认代理筛选不能直接进入 verified。
    assert validate_document(evaluated)["valid"] is True  # 确认代理筛选状态仍满足语言契约。


def test_candidate_materialization_creates_real_bsdl_structure_and_preview_contract(bridge_document: dict[str, Any]) -> None:  # 检查候选能够进入可执行建模状态。
    generated, intent_report, generation_report = _compile_and_generate(bridge_document, 2)  # 生成两个桥塔候选。
    evaluated, _ = evaluate_design_candidates(generated, intent_report["briefId"], generation_report["candidateIds"], "software.test.design")  # 建立候选评价计划和筛选基线。
    candidate_id = generation_report["candidateIds"][0]  # 选择第一个候选用于物化测试。
    materialized, report = materialize_design_candidate(evaluated, candidate_id, "software.test.design", False)  # 执行确定性参数化物化。
    candidate = next(item for item in materialized["designProcess"]["candidates"] if item["id"] == candidate_id)  # 读取物化后的候选。
    generated_component_ids = set(report["componentRefs"])  # 收集新生成构件 ID。
    assert generated_component_ids  # 确认候选不是仅保存自由文本参数。
    assert generated_component_ids.issubset({item["id"] for item in materialized["components"]})  # 确认生成构件进入 BSDL 结构对象层。
    assert report["generation"]["analysisTaskRef"] in {item["id"] for item in materialized["analysisTasks"]}  # 确认预览分析任务真实存在。
    assert report["generation"]["meshPolicyRef"] in {item["id"] for item in materialized["meshPolicies"]}  # 确认网格策略真实存在。
    assert candidate["status"] == "materialized"  # 确认候选状态更新为已物化。
    assert report["requiresEngineeringVerification"] is True  # 确认模型物化不等同工程放行。
    assert validate_document(materialized)["valid"] is True  # 确认物化后的语言和工程规则通过。


def test_verified_evidence_rejects_unknown_missing_and_surrogate_sources(bridge_document: dict[str, Any]) -> None:  # 检查工程证据接口严格阻止伪证据升级。
    generated, intent_report, generation_report = _compile_and_generate(bridge_document, 2)  # 生成两个候选。
    evaluated, _ = evaluate_design_candidates(generated, intent_report["briefId"], generation_report["candidateIds"], "software.test.design")  # 创建评价计划和代理筛选。
    candidate_id = generation_report["candidateIds"][0]  # 选择一个候选。
    with pytest.raises(ValueError):  # 预期未知证据引用被拒绝。
        record_design_evidence(evaluated, candidate_id, [], [], "finite_element", ["artifact.unknown"], "software.test.design")  # 尝试写入悬空证据引用。
    evidenced = deep_copy(evaluated)  # 复制候选文档用于加入可追溯测试产物。
    artifact_id = "artifact.test.engineering"  # 定义测试工程证据 ID。
    evidenced["artifacts"].append({"id": artifact_id, "kind": "solver_output", "uri": "runs/test_engineering.json", "format": "json", "hash": "0" * 64, "createdAt": "2026-08-19T00:00:00Z"})  # 添加具有稳定 ID 和哈希的测试产物。
    with pytest.raises(ValueError):  # 预期缺失全部目标和硬约束被拒绝。
        record_design_evidence(evidenced, candidate_id, [], [], "finite_element", [artifact_id], "software.test.design")  # 尝试以空载荷升级工程评价。
    objective_values, constraint_checks = _full_engineering_payload(evidenced, candidate_id, artifact_id)  # 构造完整工程评价载荷。
    objective_values[0]["source"] = "screening_surrogate_carried_with_fea"  # 故意把一个目标来源改为代理筛选。
    with pytest.raises(ValueError):  # 预期代理来源不能进入 verified 工程评价。
        record_design_evidence(evidenced, candidate_id, objective_values, constraint_checks, "combined", [artifact_id], "software.test.design")  # 尝试把代理值伪装成组合工程证据。


def test_proxy_only_candidate_cannot_be_selected_by_service(tmp_path: Path) -> None:  # 检查服务层在保存修订前阻止代理筛选候选被人工放行。
    service = BridgeMindService(ROOT, tmp_path / "proxy_gate.sqlite3", tmp_path / "runs")  # 使用隔离数据库和运行目录创建服务。
    service.seed_examples()  # 装入默认桥梁项目。
    service.seed_templates()  # 装入设计意图和评价模板。
    loop = service.run_project_design_loop("project.two_girder_bridge", DESIGN_TEXT, 2, None, None, True, "software.test.design")  # 保存代理筛选闭环。
    candidate_id = loop["report"]["generation"]["candidateIds"][0]  # 读取第一个代理筛选候选。
    revision = int(loop["savedRevision"]["revision"])  # 读取代理筛选修订号。
    with pytest.raises(RuntimeError):  # 预期完整验证阻止无工程证据的 selected 决策。
        service.record_project_design_feedback("project.two_girder_bridge", candidate_id, "selected", "仅凭代理筛选选择。", None, [], True, revision, True, "human.test")  # 尝试越过工程证据门。


def test_fea_preview_records_partial_evidence_and_still_stops_before_selection(tmp_path: Path) -> None:  # 检查真实数值预览不会给未覆盖目标伪造 verified 状态。
    service = BridgeMindService(ROOT, tmp_path / "preview_gate.sqlite3", tmp_path / "runs")  # 使用隔离环境创建服务。
    service.seed_examples()  # 装入默认项目。
    service.seed_templates()  # 装入默认模板。
    loop = service.run_project_design_loop("project.two_girder_bridge", DESIGN_TEXT, 2, None, None, True, "software.test.design")  # 保存意图、候选和代理筛选。
    candidate_id = loop["report"]["generation"]["candidateIds"][0]  # 选择一个候选执行真实数值预览。
    preview = service.preview_project_design_candidate("project.two_girder_bridge", candidate_id, int(loop["savedRevision"]["revision"]), True, "software.test.design")  # 执行候选物化和内置 FEA。
    preview_result = next(item for item in preview["document"]["designProcess"]["evaluationResults"] if item["id"] == preview["report"]["evidence"]["evaluationResultId"])  # 读取本次有限元局部预览结果。
    assert preview_result["evidenceLevel"] == "finite_element"  # 确认真有 FEA 产物而非代理筛选。
    assert preview_result["status"] == "partially_verified"  # 确认局部 FEA 只形成部分验证而不会升级为完整 verified。
    assert preview["report"]["evidence"]["completeForSelection"] is False  # 确认部分验证报告明确不能用于最终选择。
    assert 0.0 < preview["report"]["evidence"]["verificationCoverage"] < 1.0  # 确认预览报告量化了有限的工程验证覆盖率。
    assert preview["report"]["evidence"]["unresolvedObjectiveRefs"]  # 确认美学或可建造性等目标缺口被显式列出。
    with pytest.raises(RuntimeError):  # 预期局部 FEA 预览仍不能直接放行多目标候选。
        service.record_project_design_feedback("project.two_girder_bridge", candidate_id, "selected", "只有局部线弹性预览。", None, [preview["report"]["artifactId"]], True, int(preview["savedRevision"]["revision"]), True, "human.test")  # 尝试越过完整多目标验证门。


def test_verified_evidence_human_selection_skill_solidification_and_readback(tmp_path: Path) -> None:  # 检查完整工程证据经过人类选择后才能进入动态知识库。
    service = BridgeMindService(ROOT, tmp_path / "skill_loop.sqlite3", tmp_path / "runs")  # 使用隔离环境创建服务。
    service.seed_examples()  # 装入默认项目。
    service.seed_templates()  # 装入默认模板。
    loop = service.run_project_design_loop("project.two_girder_bridge", DESIGN_TEXT, 2, None, None, True, "software.test.design")  # 保存代理筛选闭环。
    candidate_id = loop["report"]["generation"]["candidateIds"][0]  # 选择候选执行物化和预览。
    preview = service.preview_project_design_candidate("project.two_girder_bridge", candidate_id, int(loop["savedRevision"]["revision"]), True, "software.test.design")  # 生成可追溯 FEA 预览产物。
    artifact_id = preview["report"]["artifactId"]  # 读取真实文件产物 ID。
    objective_values, constraint_checks = _full_engineering_payload(preview["document"], candidate_id, artifact_id)  # 构造完整外部工程复核载荷。
    evidenced = service.record_project_design_evidence("project.two_girder_bridge", candidate_id, objective_values, constraint_checks, "combined", [artifact_id], int(preview["savedRevision"]["revision"]), True, "human.test")  # 写入完整 verified 工程评价。
    feedback = service.record_project_design_feedback("project.two_girder_bridge", candidate_id, "selected", "完整多目标证据通过，人工选择该候选。", None, [evidenced["report"]["evaluationResultId"], artifact_id], True, int(evidenced["savedRevision"]["revision"]), True, "human.test")  # 保存人类最终选择。
    skill = service.solidify_project_design_skill("project.two_girder_bridge", feedback["report"]["decisionId"], int(feedback["savedRevision"]["revision"]), True, "software.test.design")  # 把人工批准且有证据的决策固化为版本化技能。
    assert skill["report"]["template"]["kind"] == "design_skill"  # 确认模板类型为设计技能。
    new_document = load_json(ROOT / "examples" / "two_girder_bridge.bsdl.json")  # 读取一个独立项目基线。
    new_document["documentId"] = "document.skill_readback_bridge"  # 修改文档稳定 ID 避免项目冲突。
    new_document["project"]["id"] = "project.skill_readback_bridge"  # 修改项目稳定 ID。
    new_document["project"]["name"] = "设计技能读回测试桥"  # 修改项目显示名称。
    service.create_project(new_document, "human.test", "test", "创建设计技能读回项目")  # 创建独立项目。
    compiled = service.compile_project_design_intent("project.skill_readback_bridge", DESIGN_TEXT, None, None, True, "software.test.design")  # 编译相似桥塔任务。
    generated = service.generate_project_design_candidates("project.skill_readback_bridge", None, 3, int(compiled["savedRevision"]["revision"]), True, "software.test.design", True)  # 使用全局 design_skill 模板生成新候选。
    assert generated["report"]["skillGuided"] is True  # 确认已发生动态知识读回。
    assert generated["report"]["designSkillRefs"]  # 确认生成报告保存技能引用。
    assert any(item.get("provenance", {}).get("designSkillRef") for item in generated["document"]["designProcess"]["candidates"] if isinstance(item, dict))  # 确认至少一个候选由技能引导生成。


def test_full_cycle_api_stops_at_human_decision_gate(tmp_path: Path) -> None:  # 检查一键完整循环不会把局部 FEA 和代理分数称为工程最优。
    client = TestClient(create_app(tmp_path / "design_cycle_api.sqlite3"))  # 使用临时数据库创建 API 客户端。
    response = client.post("/api/projects/project.two_girder_bridge/design/cycle", json={"rawText": DESIGN_TEXT, "candidateCount": 2, "actor": "software.test.design"})  # 执行意图—建模—计算—评价完整循环。
    assert response.status_code == 200  # 确认完整循环接口成功。
    payload = response.json()  # 解析 API 响应。
    assert payload["report"]["humanDecisionRequired"] is True  # 确认系统停在人类决策门前。
    assert payload["report"]["engineeringRecommendationAvailable"] is False  # 确认局部预览没有被称为完整工程推荐。
    assert payload["report"]["recommendationBasis"] == "screening_surrogate_plus_partial_fea_preview"  # 确认展示候选的证据基础被明确标注。
    assert payload["report"]["screeningRecommendationCandidateId"]  # 确认仍可给出透明代理筛选候选用于继续审查。
    preview_results = [item for item in payload["document"]["designProcess"]["evaluationResults"] if item["evidenceLevel"] == "finite_element"]  # 收集所有有限元局部预览结果。
    assert preview_results and all(item["status"] == "partially_verified" for item in preview_results)  # 确认全部局部预览都保持部分验证状态而非完整工程放行。
