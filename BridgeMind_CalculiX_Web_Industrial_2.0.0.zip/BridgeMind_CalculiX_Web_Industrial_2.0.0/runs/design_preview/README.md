# BridgeMind 2.0 桥塔示例数值预览

本目录中的四个 JSON 文件由 `examples/bridge_pylon_design_2.0.bsdl.json` 对应的四个候选方案生成。

它们是内置空间梁求解器产生的真实数值预览，但只覆盖结构目标的窄域指标，均标记为非权威证据。美学、可建造性以及高保真桥塔工程验证仍未完成，因此示例中的候选只达到 `partially_verified`，没有任何候选被最终批准。
