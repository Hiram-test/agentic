"""验证 BSDL 1.1 与 BridgeMind 2.0 的设计意图、生成式迭代、候选、证据和人工决策语义。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
import math  # 提供有限数检查。
from typing import Any  # 提供通用 JSON 类型注解。
from .model import GENERATION_LOOP  # 复用唯一合法的建模—计算—评价—反馈闭环定义。


def _issue(rule_id: str, severity: str, path: str, message: str, target_id: str | None = None, expected: Any = None, actual: Any = None) -> dict[str, Any]:  # 构造统一设计验证问题。
    return {"ruleId": rule_id, "severity": severity, "path": path, "targetId": target_id, "message": message, "expected": expected, "actual": actual}  # 返回稳定字段结构。


def _as_list(value: Any) -> list[Any]:  # 把合法数组原样返回并把其他值安全降为空数组。
    return value if isinstance(value, list) else []  # 返回可遍历数组。


def _index_top_level(document: dict[str, Any], collection_names: tuple[str, ...]) -> tuple[set[str], dict[str, str]]:  # 建立顶层证据和反馈对象索引。
    ids: set[str] = set()  # 初始化顶层对象 ID 集合。
    paths: dict[str, str] = {}  # 初始化顶层对象路径索引。
    for collection_name in collection_names:  # 遍历允许引用的顶层集合。
        for position, item in enumerate(_as_list(document.get(collection_name))):  # 遍历当前顶层对象。
            if isinstance(item, dict) and isinstance(item.get("id"), str):  # 检查对象是否具有稳定 ID。
                item_id = str(item["id"])  # 读取稳定 ID。
                ids.add(item_id)  # 保存稳定 ID。
                paths[item_id] = f"/{collection_name}/{position}"  # 保存顶层对象路径。
            if collection_name == "resultSets" and isinstance(item, dict) and isinstance(item.get("runRef"), str):  # 检查结果集是否绑定实现层运行记录。
                run_ref = str(item["runRef"])  # 读取运行记录引用。
                ids.add(run_ref)  # 允许运行记录作为证据引用。
                paths.setdefault(run_ref, f"/{collection_name}/{position}/runRef")  # 保存运行记录来源路径。
    return ids, paths  # 返回顶层对象 ID 和路径索引。


def validate_design_process(document: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:  # 执行设计语义跨对象验证。
    process = document.get("designProcess")  # 读取设计过程对象。
    if process is None:  # 兼容未启用上游设计层的旧文档。
        return [], {"designProcessPresent": False, "designBriefs": 0, "designIterations": 0, "designCandidates": 0, "designEvaluations": 0, "designDecisions": 0}  # 返回无设计层统计。
    if not isinstance(process, dict):  # 检查设计过程结构。
        return [_issue("BSDL-DESIGN-001", "critical", "/designProcess", "designProcess 必须为对象。", None, "object", type(process).__name__)], {"designProcessPresent": True}  # 返回结构错误。
    issues: list[dict[str, Any]] = []  # 初始化设计问题列表。
    collection_names = ["contexts", "requirements", "objectives", "constraints", "preferences", "variables", "briefs", "candidates", "evaluationPlans", "evaluationResults", "iterations", "decisions"]  # 定义全部设计实体集合。
    index: dict[str, tuple[str, dict[str, Any]]] = {}  # 初始化设计实体索引。
    for collection_name in collection_names:  # 遍历设计实体集合。
        for position, item in enumerate(_as_list(process.get(collection_name))):  # 遍历设计实体。
            if not isinstance(item, dict) or not isinstance(item.get("id"), str):  # 跳过缺失稳定 ID 的非法对象。
                continue  # 继续下一对象。
            item_id = str(item["id"])  # 读取实体 ID。
            path = f"/designProcess/{collection_name}/{position}"  # 构造实体路径。
            if item_id in index:  # 检查设计层重复 ID。
                issues.append(_issue("BSDL-DESIGN-ID-001", "critical", path + "/id", f"设计对象 ID {item_id!r} 重复。", item_id, "设计层唯一 ID", item_id))  # 记录重复 ID。
            else:  # 处理首次出现 ID。
                index[item_id] = (path, item)  # 保存设计实体索引。
    evidence_refs, evidence_paths = _index_top_level(document, ("artifacts", "resultSets", "codeCheckResults", "feedback", "finiteElementModels", "conversionReports"))  # 建立工程证据对象索引。
    feedback_refs, _feedback_paths = _index_top_level(document, ("feedback",))  # 建立反馈事件对象索引。
    stage_evidence_refs = set(evidence_refs) | {item_id for item_id, (item_path, _item) in index.items() if item_path.startswith("/designProcess/evaluationResults/") or item_path.startswith("/designProcess/decisions/")}  # 允许阶段证据关联原始工程证据、评价结果和人工决策。

    def check_ref(value: Any, path: str, target_id: str | None, allowed: tuple[str, ...], nullable: bool = False) -> dict[str, Any] | None:  # 定义设计对象引用检查器。
        if value is None and nullable:  # 接受可空引用。
            return None  # 结束引用检查。
        if not isinstance(value, str) or value not in index:  # 检查引用存在性。
            issues.append(_issue("BSDL-DESIGN-REF-001", "error", path, f"设计引用 {value!r} 不存在。", target_id, allowed, value))  # 记录悬空引用。
            return None  # 目标缺失时停止类型检查。
        target_path, target = index[value]  # 读取目标路径和对象。
        if not any(target_path.startswith(prefix) for prefix in allowed):  # 检查目标集合类型。
            issues.append(_issue("BSDL-DESIGN-REF-002", "error", path, f"设计引用 {value!r} 指向不允许的对象 {target_path}。", target_id, allowed, target_path))  # 记录引用类型错误。
            return None  # 类型错误时停止后续一致性检查。
        return target  # 返回合法引用目标对象。

    def check_top_ref(value: Any, path: str, target_id: str | None, allowed_refs: set[str], label: str) -> bool:  # 定义顶层工程对象引用检查器。
        if not isinstance(value, str) or value not in allowed_refs:  # 检查顶层引用存在性。
            issues.append(_issue("BSDL-DESIGN-TOPREF-001", "error", path, f"{label}引用 {value!r} 不存在。", target_id, "document top-level object id", value))  # 记录顶层悬空引用。
            return False  # 返回引用失败。
        return True  # 返回引用成功。

    generative_loop = process.get("generativeLoop")  # 读取生成式设计闭环定义。
    if generative_loop != GENERATION_LOOP:  # 检查是否严格采用建模—计算—评价—反馈。
        issues.append(_issue("BSDL-DESIGN-LOOP-001", "critical", "/designProcess/generativeLoop", "生成式设计必须表示为建模—计算—评价—反馈闭环，generation 不是独立过程阶段。", None, GENERATION_LOOP, generative_loop))  # 记录方法层级错误。
    if isinstance(generative_loop, list) and "generation" in generative_loop:  # 检查是否错误加入 generation 阶段。
        issues.append(_issue("BSDL-DESIGN-LOOP-002", "critical", "/designProcess/generativeLoop", "generation 是建模—计算—评价—反馈的整体方法范式，不能作为独立阶段。", None, "no generation stage", generative_loop))  # 明确阻断错误阶段命名。
    active_brief = process.get("activeBriefRef")  # 读取活动设计任务引用。
    check_ref(active_brief, "/designProcess/activeBriefRef", None, ("/designProcess/briefs/",), True)  # 检查活动设计任务引用。
    active_iteration = process.get("activeIterationRef")  # 读取活动设计迭代引用。
    check_ref(active_iteration, "/designProcess/activeIterationRef", None, ("/designProcess/iterations/",), True)  # 检查活动设计迭代引用。

    objective_weights: list[float] = []  # 初始化活动目标权重列表。
    for objective in _as_list(process.get("objectives")):  # 遍历设计目标。
        if not isinstance(objective, dict):  # 跳过非法目标。
            continue  # 继续下一目标。
        weight = objective.get("weight")  # 读取目标权重。
        if objective.get("status") == "active" and isinstance(weight, (int, float)) and math.isfinite(float(weight)):  # 检查活动有限权重。
            objective_weights.append(float(weight))  # 保存活动目标权重。
    if objective_weights and abs(sum(objective_weights) - 1.0) > 1.0e-6:  # 检查权重归一性。
        issues.append(_issue("BSDL-DESIGN-OBJ-001", "error", "/designProcess/objectives", "活动设计目标权重之和必须为 1。", None, 1.0, sum(objective_weights)))  # 记录目标权重错误。

    for position, brief in enumerate(_as_list(process.get("briefs"))):  # 遍历设计任务。
        if not isinstance(brief, dict):  # 跳过非法任务。
            continue  # 继续下一任务。
        brief_id = brief.get("id")  # 读取任务 ID。
        path = f"/designProcess/briefs/{position}"  # 构造任务路径。
        ref_groups = [("contextRefs", ("/designProcess/contexts/",)), ("requirementRefs", ("/designProcess/requirements/",)), ("objectiveRefs", ("/designProcess/objectives/",)), ("constraintRefs", ("/designProcess/constraints/",)), ("preferenceRefs", ("/designProcess/preferences/",)), ("variableRefs", ("/designProcess/variables/",))]  # 定义任务引用组。
        for field, allowed in ref_groups:  # 遍历任务引用组。
            for ref_position, ref in enumerate(_as_list(brief.get(field))):  # 遍历引用列表。
                check_ref(ref, f"{path}/{field}/{ref_position}", brief_id, allowed)  # 检查任务引用。

    for position, plan in enumerate(_as_list(process.get("evaluationPlans"))):  # 遍历评价计划。
        if not isinstance(plan, dict):  # 跳过非法计划。
            continue  # 继续下一计划。
        plan_id = plan.get("id")  # 读取计划 ID。
        path = f"/designProcess/evaluationPlans/{position}"  # 构造计划路径。
        check_ref(plan.get("briefRef"), path + "/briefRef", plan_id, ("/designProcess/briefs/",))  # 检查任务引用。
        for field, allowed in [("objectiveRefs", ("/designProcess/objectives/",)), ("constraintRefs", ("/designProcess/constraints/",))]:  # 遍历计划引用组。
            for ref_position, ref in enumerate(_as_list(plan.get(field))):  # 遍历计划引用。
                check_ref(ref, f"{path}/{field}/{ref_position}", plan_id, allowed)  # 检查计划引用。

    for position, iteration in enumerate(_as_list(process.get("iterations"))):  # 遍历生成式设计迭代。
        if not isinstance(iteration, dict):  # 跳过非法迭代。
            continue  # 继续下一迭代。
        iteration_id = iteration.get("id")  # 读取迭代 ID。
        path = f"/designProcess/iterations/{position}"  # 构造迭代路径。
        brief = check_ref(iteration.get("briefRef"), path + "/briefRef", iteration_id, ("/designProcess/briefs/",))  # 检查迭代任务引用。
        plan = check_ref(iteration.get("planRef"), path + "/planRef", iteration_id, ("/designProcess/evaluationPlans/",), True)  # 检查迭代评价计划引用。
        if isinstance(brief, dict) and isinstance(plan, dict) and plan.get("briefRef") != brief.get("id"):  # 检查评价计划与迭代任务是否一致。
            issues.append(_issue("BSDL-DESIGN-ITER-001", "error", path + "/planRef", "设计迭代的评价计划必须属于同一 DesignBrief。", iteration_id, brief.get("id"), plan.get("briefRef")))  # 记录任务与计划不一致。
        if iteration.get("stageSequence") != GENERATION_LOOP:  # 检查迭代阶段顺序。
            issues.append(_issue("BSDL-DESIGN-ITER-002", "critical", path + "/stageSequence", "每轮生成式设计必须严格按 modeling、computation、evaluation、feedback 记录。", iteration_id, GENERATION_LOOP, iteration.get("stageSequence")))  # 记录阶段顺序错误。
        stage_records = _as_list(iteration.get("stageRecords"))  # 读取阶段记录。
        stage_names = [item.get("stage") for item in stage_records if isinstance(item, dict)]  # 收集阶段名称。
        if stage_names != GENERATION_LOOP or len(stage_names) != len(set(stage_names)):  # 检查阶段记录是否完整、唯一且有序。
            issues.append(_issue("BSDL-DESIGN-ITER-003", "critical", path + "/stageRecords", "每轮迭代必须且只能包含一次建模、计算、评价和反馈阶段。", iteration_id, GENERATION_LOOP, stage_names))  # 记录阶段记录错误。
        if "generation" in stage_names:  # 检查是否把生成误写为独立阶段。
            issues.append(_issue("BSDL-DESIGN-ITER-004", "critical", path + "/stageRecords", "generation 不是独立阶段；候选生成应作为 modeling 的方法与产物记录。", iteration_id, "no generation stage", stage_names))  # 记录层级错位。
        for stage_position, stage_record in enumerate(stage_records):  # 遍历阶段记录。
            if not isinstance(stage_record, dict):  # 跳过非法阶段记录。
                continue  # 继续下一阶段。
            for ref_position, ref in enumerate(_as_list(stage_record.get("artifactRefs"))):  # 遍历阶段产物引用。
                check_top_ref(ref, f"{path}/stageRecords/{stage_position}/artifactRefs/{ref_position}", iteration_id, evidence_refs, "阶段产物")  # 检查阶段产物存在性。
            for ref_position, ref in enumerate(_as_list(stage_record.get("evidenceRefs"))):  # 遍历阶段证据引用。
                check_top_ref(ref, f"{path}/stageRecords/{stage_position}/evidenceRefs/{ref_position}", iteration_id, stage_evidence_refs, "阶段证据")  # 检查阶段证据、评价或人工决策存在性。
        for ref_position, ref in enumerate(_as_list(iteration.get("candidateRefs"))):  # 遍历迭代候选引用。
            candidate = check_ref(ref, f"{path}/candidateRefs/{ref_position}", iteration_id, ("/designProcess/candidates/",))  # 检查候选引用。
            if isinstance(candidate, dict) and candidate.get("iterationRef") != iteration_id:  # 检查候选反向引用一致性。
                issues.append(_issue("BSDL-DESIGN-ITER-005", "error", f"{path}/candidateRefs/{ref_position}", "迭代候选引用与 CandidateScheme.iterationRef 不一致。", iteration_id, iteration_id, candidate.get("iterationRef")))  # 记录候选归属错误。
        for ref_position, ref in enumerate(_as_list(iteration.get("evaluationResultRefs"))):  # 遍历迭代评价引用。
            result = check_ref(ref, f"{path}/evaluationResultRefs/{ref_position}", iteration_id, ("/designProcess/evaluationResults/",))  # 检查评价引用。
            if isinstance(result, dict) and result.get("iterationRef") != iteration_id:  # 检查评价反向引用一致性。
                issues.append(_issue("BSDL-DESIGN-ITER-006", "error", f"{path}/evaluationResultRefs/{ref_position}", "迭代评价引用与 EvaluationResult.iterationRef 不一致。", iteration_id, iteration_id, result.get("iterationRef")))  # 记录评价归属错误。
        selected_candidate = check_ref(iteration.get("selectedCandidateRef"), path + "/selectedCandidateRef", iteration_id, ("/designProcess/candidates/",), True)  # 检查本轮选定候选引用。
        if isinstance(selected_candidate, dict) and selected_candidate.get("iterationRef") != iteration_id:  # 检查选定候选是否属于本轮。
            issues.append(_issue("BSDL-DESIGN-ITER-007", "error", path + "/selectedCandidateRef", "设计迭代只能选择本轮生成的候选。", iteration_id, iteration_id, selected_candidate.get("iterationRef")))  # 记录跨轮选择错误。
        for ref_position, ref in enumerate(_as_list(iteration.get("feedbackRefs"))):  # 遍历本轮反馈事件引用。
            check_top_ref(ref, f"{path}/feedbackRefs/{ref_position}", iteration_id, feedback_refs, "反馈事件")  # 检查反馈事件存在性。
        if iteration.get("status") == "completed":  # 检查已完成迭代的闭环完整性。
            feedback_record = next((item for item in stage_records if isinstance(item, dict) and item.get("stage") == "feedback"), None)  # 读取反馈阶段记录。
            approved_decision = next((item for item in _as_list(process.get("decisions")) if isinstance(item, dict) and item.get("iterationRef") == iteration_id and item.get("humanApproval") is True and item.get("status") == "approved"), None)  # 查找本轮人工批准决策。
            if not isinstance(feedback_record, dict) or feedback_record.get("status") != "completed" or approved_decision is None:  # 检查反馈阶段和人工决策是否真正完成。
                issues.append(_issue("BSDL-DESIGN-ITER-008", "error", path + "/status", "completed 设计迭代必须完成 feedback 阶段并具有人类批准的决策记录。", iteration_id, "completed feedback plus approved human decision", {"feedback": feedback_record, "decision": approved_decision}))  # 记录虚假完成状态。

    for position, candidate in enumerate(_as_list(process.get("candidates"))):  # 遍历候选方案。
        if not isinstance(candidate, dict):  # 跳过非法候选。
            continue  # 继续下一候选。
        candidate_id = candidate.get("id")  # 读取候选 ID。
        path = f"/designProcess/candidates/{position}"  # 构造候选路径。
        brief = check_ref(candidate.get("briefRef"), path + "/briefRef", candidate_id, ("/designProcess/briefs/",))  # 检查候选任务引用。
        iteration = check_ref(candidate.get("iterationRef"), path + "/iterationRef", candidate_id, ("/designProcess/iterations/",))  # 检查候选迭代引用。
        if isinstance(iteration, dict) and isinstance(brief, dict) and iteration.get("briefRef") != brief.get("id"):  # 检查候选任务与迭代任务一致性。
            issues.append(_issue("BSDL-DESIGN-CAND-001", "error", path + "/iterationRef", "CandidateScheme 的 briefRef 和 iterationRef 必须指向同一设计任务。", candidate_id, brief.get("id"), iteration.get("briefRef")))  # 记录候选上下文不一致。
        if isinstance(iteration, dict) and candidate_id not in _as_list(iteration.get("candidateRefs")):  # 检查候选是否被其迭代正向收录。
            issues.append(_issue("BSDL-DESIGN-CAND-002", "error", path + "/iterationRef", "CandidateScheme 必须出现在所属 DesignIteration.candidateRefs 中。", candidate_id, candidate_id, iteration.get("candidateRefs")))  # 记录迭代正反向关系缺失。
        check_ref(candidate.get("parentRef"), path + "/parentRef", candidate_id, ("/designProcess/candidates/",), True)  # 检查候选父引用。
        for ref_position, ref in enumerate(_as_list(candidate.get("evaluationResultRefs"))):  # 遍历候选评价引用。
            result = check_ref(ref, f"{path}/evaluationResultRefs/{ref_position}", candidate_id, ("/designProcess/evaluationResults/",))  # 检查评价引用。
            if isinstance(result, dict) and result.get("candidateRef") != candidate_id:  # 检查评价反向候选引用一致性。
                issues.append(_issue("BSDL-DESIGN-CAND-003", "error", f"{path}/evaluationResultRefs/{ref_position}", "候选评价引用必须反向指向当前候选。", candidate_id, candidate_id, result.get("candidateRef")))  # 记录评价反向引用错误。
        for ref_position, ref in enumerate(_as_list(candidate.get("modelArtifactRefs"))):  # 遍历候选模型产物引用。
            check_top_ref(ref, f"{path}/modelArtifactRefs/{ref_position}", candidate_id, evidence_refs, "候选模型产物")  # 检查模型产物存在性。
        for ref_position, ref in enumerate(_as_list(candidate.get("resultArtifactRefs"))):  # 遍历候选计算产物引用。
            check_top_ref(ref, f"{path}/resultArtifactRefs/{ref_position}", candidate_id, evidence_refs, "候选计算产物")  # 检查计算产物存在性。
        materialization = candidate.get("provenance", {}).get("materialization") if isinstance(candidate.get("provenance"), dict) else None  # 读取物化来源记录。
        if candidate.get("modelArtifactRefs") and (not isinstance(materialization, dict) or not materialization.get("applied")):  # 检查模型产物是否具有成功物化审计。
            issues.append(_issue("BSDL-DESIGN-MAT-001", "error", path + "/provenance/materialization", "具有模型产物的候选必须保存成功模型补丁与确定性生成审计。", candidate_id, "applied materialization audit", materialization))  # 记录物化审计缺失。

    constraints_by_id = {item.get("id"): item for item in _as_list(process.get("constraints")) if isinstance(item, dict)}  # 建立约束对象索引。
    for position, result in enumerate(_as_list(process.get("evaluationResults"))):  # 遍历评价结果。
        if not isinstance(result, dict):  # 跳过非法结果。
            continue  # 继续下一结果。
        result_id = result.get("id")  # 读取结果 ID。
        path = f"/designProcess/evaluationResults/{position}"  # 构造结果路径。
        candidate = check_ref(result.get("candidateRef"), path + "/candidateRef", result_id, ("/designProcess/candidates/",))  # 检查候选引用。
        iteration = check_ref(result.get("iterationRef"), path + "/iterationRef", result_id, ("/designProcess/iterations/",))  # 检查迭代引用。
        plan = check_ref(result.get("planRef"), path + "/planRef", result_id, ("/designProcess/evaluationPlans/",))  # 检查评价计划引用。
        if isinstance(candidate, dict) and isinstance(iteration, dict) and candidate.get("iterationRef") != iteration.get("id"):  # 检查评价与候选迭代一致性。
            issues.append(_issue("BSDL-DESIGN-EVAL-001", "error", path + "/iterationRef", "EvaluationResult 必须与 CandidateScheme 属于同一设计迭代。", result_id, candidate.get("iterationRef"), iteration.get("id")))  # 记录评价迭代错误。
        if isinstance(iteration, dict) and result_id not in _as_list(iteration.get("evaluationResultRefs")):  # 检查评价是否被所属迭代正向收录。
            issues.append(_issue("BSDL-DESIGN-EVAL-002", "error", path + "/iterationRef", "EvaluationResult 必须出现在所属 DesignIteration.evaluationResultRefs 中。", result_id, result_id, iteration.get("evaluationResultRefs")))  # 记录评价正反向关系缺失。
        if isinstance(candidate, dict) and isinstance(plan, dict) and candidate.get("briefRef") != plan.get("briefRef"):  # 检查评价计划是否属于候选任务。
            issues.append(_issue("BSDL-DESIGN-EVAL-003", "error", path + "/planRef", "评价计划与候选方案必须属于同一 DesignBrief。", result_id, candidate.get("briefRef"), plan.get("briefRef")))  # 记录评价上下文错误。
        for value_position, value in enumerate(_as_list(result.get("objectiveValues"))):  # 遍历目标值。
            if isinstance(value, dict):  # 检查目标值对象。
                check_ref(value.get("objectiveRef"), f"{path}/objectiveValues/{value_position}/objectiveRef", result_id, ("/designProcess/objectives/",))  # 检查目标引用。
        for check_position, check in enumerate(_as_list(result.get("constraintChecks"))):  # 遍历约束检查。
            if isinstance(check, dict):  # 检查约束对象。
                check_ref(check.get("constraintRef"), f"{path}/constraintChecks/{check_position}/constraintRef", result_id, ("/designProcess/constraints/",))  # 检查约束引用。
        result_status = str(result.get("status", ""))  # 读取评价结果状态。
        if result_status in {"partially_verified", "verified"}:  # 对任何非代理工程评价检查总证据可追溯性。
            result_evidence_refs = _as_list(result.get("evidenceRefs"))  # 读取评价级证据引用。
            if result.get("evidenceLevel") == "screening_surrogate" or not result_evidence_refs:  # 检查工程评价是否仍错误使用代理等级或缺少总证据。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-001", "error", path, "部分或完整工程评价必须采用非代理证据等级并保存 evidenceRefs。", result_id, "non-surrogate engineering evidence", {"evidenceLevel": result.get("evidenceLevel"), "evidenceRefs": result_evidence_refs}))  # 记录工程评价总证据错误。
            unknown_result_refs = sorted(set(result_evidence_refs) - evidence_refs)  # 检查评价级证据引用是否可追溯。
            if unknown_result_refs:  # 检查是否存在悬空工程证据。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-002", "error", path + "/evidenceRefs", "部分或完整工程评价的 evidenceRefs 必须指向文档内现有工程证据对象。", result_id, "known evidence refs", unknown_result_refs))  # 记录悬空工程证据。
            coverage = result.get("verificationCoverage")  # 读取显式工程验证覆盖率。
            if not isinstance(coverage, (int, float)) or not math.isfinite(float(coverage)) or not 0.0 <= float(coverage) <= 1.0:  # 检查覆盖率合法性。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-003", "error", path + "/verificationCoverage", "工程评价必须保存零到一之间的 verificationCoverage。", result_id, "0 <= coverage <= 1", coverage))  # 记录覆盖率错误。
            unverified_refs = [*_as_list(result.get("unverifiedObjectiveRefs")), *_as_list(result.get("unverifiedConstraintRefs"))]  # 合并未验证目标与约束引用。
            if result_status == "partially_verified" and not unverified_refs:  # 检查部分验证是否真实存在证据缺口。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-004", "error", path, "partially_verified 评价必须至少列出一个未验证目标或约束。", result_id, "non-empty unverified refs", unverified_refs))  # 记录虚假的部分验证状态。
            if result_status == "verified" and (unverified_refs or coverage != 1.0):  # 检查完整评价是否仍保留证据缺口。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-005", "error", path, "verified 评价必须达到 100% 工程验证覆盖且没有未验证目标或约束。", result_id, {"coverage": 1.0, "unverified": []}, {"coverage": coverage, "unverified": unverified_refs}))  # 记录虚假完整评价。
            for value_position, value in enumerate(_as_list(result.get("objectiveValues"))):  # 遍历工程评价中的目标值。
                if not isinstance(value, dict):  # 跳过已由 Schema 报告的非法目标值。
                    continue  # 继续下一目标值。
                verification_status = value.get("verificationStatus")  # 读取单目标验证状态。
                if verification_status not in {"screening", "verified", "unresolved"}:  # 检查单目标验证状态是否明确。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-006", "error", f"{path}/objectiveValues/{value_position}/verificationStatus", "工程评价中的每个目标值必须显式标记 screening、verified 或 unresolved。", result_id, "verification status", verification_status))  # 记录单目标状态缺失。
                if result_status == "verified" and verification_status != "verified":  # 检查完整评价是否夹带未验证目标。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-007", "error", f"{path}/objectiveValues/{value_position}/verificationStatus", "verified 评价中的每个目标值都必须标记 verified。", result_id, "verified", verification_status))  # 记录未验证目标混入完整评价。
            for check_position, check in enumerate(_as_list(result.get("constraintChecks"))):  # 遍历工程评价中的约束检查。
                if not isinstance(check, dict):  # 跳过已由 Schema 报告的非法约束检查。
                    continue  # 继续下一约束检查。
                verification_status = check.get("verificationStatus")  # 读取单约束验证状态。
                if verification_status not in {"screening", "verified", "unresolved"}:  # 检查单约束验证状态是否明确。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-008", "error", f"{path}/constraintChecks/{check_position}/verificationStatus", "工程评价中的每个约束检查必须显式标记 screening、verified 或 unresolved。", result_id, "verification status", verification_status))  # 记录单约束状态缺失。
                if result_status == "verified" and verification_status != "verified":  # 检查完整评价是否夹带未验证约束。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-009", "error", f"{path}/constraintChecks/{check_position}/verificationStatus", "verified 评价中的每个硬约束检查都必须标记 verified。", result_id, "verified", verification_status))  # 记录未验证约束混入完整评价。
        if result_status == "verified" and isinstance(plan, dict):  # 对完成工程验证的评价执行严格覆盖守门。
            required_objective_refs = set(_as_list(plan.get("objectiveRefs")))  # 读取计划要求的全部目标。
            provided_objective_refs = [value.get("objectiveRef") for value in _as_list(result.get("objectiveValues")) if isinstance(value, dict)]  # 收集评价实际提供的目标。
            if set(provided_objective_refs) != required_objective_refs or len(provided_objective_refs) != len(set(provided_objective_refs)):  # 检查目标完整覆盖和唯一性。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-010", "error", path + "/objectiveValues", "verified 评价必须对评价计划中的每个目标且只提供一条目标值。", result_id, sorted(required_objective_refs), provided_objective_refs))  # 记录目标覆盖缺口。
            for value_position, value in enumerate(_as_list(result.get("objectiveValues"))):  # 遍历 verified 目标证据。
                if not isinstance(value, dict):  # 跳过非法目标值。
                    continue  # 继续下一目标值。
                source = str(value.get("source", ""))  # 读取目标证据来源。
                if any(token in source.lower() for token in ("screening_surrogate", "unresolved", "placeholder", "proxy_only")):  # 检查是否夹带代理筛选或未解决占位值。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-011", "error", f"{path}/objectiveValues/{value_position}/source", "verified 评价不得包含代理筛选、未解决项或占位目标值。", result_id, "engineering evidence source", source))  # 记录代理伪装问题。
                value_refs = _as_list(value.get("evidenceRefs"))  # 读取目标级证据引用。
                unknown_value_refs = sorted(set(value_refs) - evidence_refs)  # 检查目标级证据是否可追溯。
                if not value_refs or unknown_value_refs:  # 检查目标级证据是否缺失或悬空。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-012", "error", f"{path}/objectiveValues/{value_position}/evidenceRefs", "verified 目标值必须关联文档内现有工程证据。", result_id, "non-empty known evidence refs", {"refs": value_refs, "unknown": unknown_value_refs}))  # 记录目标证据缺口。
            required_hard_constraint_refs = {ref for ref in _as_list(plan.get("constraintRefs")) if constraints_by_id.get(ref, {}).get("hard", True)}  # 读取计划要求的全部硬约束。
            provided_constraint_refs = [check.get("constraintRef") for check in _as_list(result.get("constraintChecks")) if isinstance(check, dict)]  # 收集评价实际提供的约束检查。
            if set(provided_constraint_refs) != required_hard_constraint_refs or len(provided_constraint_refs) != len(set(provided_constraint_refs)):  # 检查硬约束完整覆盖和唯一性。
                issues.append(_issue("BSDL-DESIGN-EVIDENCE-013", "error", path + "/constraintChecks", "verified 评价必须对评价计划中的每个硬约束且只提供一条检查。", result_id, sorted(required_hard_constraint_refs), provided_constraint_refs))  # 记录硬约束覆盖缺口。
            for check_position, check in enumerate(_as_list(result.get("constraintChecks"))):  # 遍历 verified 约束证据。
                if not isinstance(check, dict):  # 跳过非法约束检查。
                    continue  # 继续下一约束检查。
                check_refs = _as_list(check.get("evidenceRefs"))  # 读取约束级证据引用。
                unknown_check_refs = sorted(set(check_refs) - evidence_refs)  # 检查约束级证据是否可追溯。
                if not check_refs or unknown_check_refs:  # 检查约束级证据是否缺失或悬空。
                    issues.append(_issue("BSDL-DESIGN-EVIDENCE-014", "error", f"{path}/constraintChecks/{check_position}/evidenceRefs", "verified 硬约束检查必须关联文档内现有工程证据。", result_id, "non-empty known evidence refs", {"refs": check_refs, "unknown": unknown_check_refs}))  # 记录约束证据缺口。

    for position, decision in enumerate(_as_list(process.get("decisions"))):  # 遍历设计决策。
        if not isinstance(decision, dict):  # 跳过非法决策。
            continue  # 继续下一决策。
        decision_id = decision.get("id")  # 读取决策 ID。
        path = f"/designProcess/decisions/{position}"  # 构造决策路径。
        brief = check_ref(decision.get("briefRef"), path + "/briefRef", decision_id, ("/designProcess/briefs/",))  # 检查任务引用。
        iteration = check_ref(decision.get("iterationRef"), path + "/iterationRef", decision_id, ("/designProcess/iterations/",))  # 检查迭代引用。
        selected_candidate = check_ref(decision.get("selectedCandidateRef"), path + "/selectedCandidateRef", decision_id, ("/designProcess/candidates/",), True)  # 检查选定候选引用。
        for ref_position, ref in enumerate(_as_list(decision.get("candidateRefs"))):  # 遍历候选集合引用。
            candidate = check_ref(ref, f"{path}/candidateRefs/{ref_position}", decision_id, ("/designProcess/candidates/",))  # 检查候选引用。
            if isinstance(candidate, dict) and isinstance(iteration, dict) and candidate.get("iterationRef") != iteration.get("id"):  # 检查决策候选是否属于本轮。
                issues.append(_issue("BSDL-DESIGN-HITL-001", "error", f"{path}/candidateRefs/{ref_position}", "人工决策只能比较同一设计迭代中的候选。", decision_id, iteration.get("id"), candidate.get("iterationRef")))  # 记录跨轮比较错误。
        if isinstance(brief, dict) and isinstance(iteration, dict) and iteration.get("briefRef") != brief.get("id"):  # 检查决策任务与迭代任务一致性。
            issues.append(_issue("BSDL-DESIGN-HITL-002", "error", path + "/iterationRef", "人工决策的 briefRef 和 iterationRef 必须属于同一设计任务。", decision_id, brief.get("id"), iteration.get("briefRef")))  # 记录决策上下文错误。
        if isinstance(selected_candidate, dict) and isinstance(iteration, dict) and selected_candidate.get("iterationRef") != iteration.get("id"):  # 检查选定候选是否属于当前迭代。
            issues.append(_issue("BSDL-DESIGN-HITL-003", "error", path + "/selectedCandidateRef", "selectedCandidateRef 必须属于当前 DesignIteration。", decision_id, iteration.get("id"), selected_candidate.get("iterationRef")))  # 记录跨轮选择错误。
        if decision.get("decision") == "selected" and not decision.get("humanApproval"):  # 检查最终选定是否经过人工批准。
            issues.append(_issue("BSDL-DESIGN-HITL-004", "error", path + "/humanApproval", "候选被标记 selected 时必须有人工批准。", decision_id, True, decision.get("humanApproval")))  # 记录人机责任错误。
        if decision.get("decision") == "selected" and isinstance(selected_candidate, dict):  # 检查最终选定候选的工程证据。
            result_refs = _as_list(selected_candidate.get("evaluationResultRefs"))  # 读取候选评价引用。
            verified = any(isinstance(index.get(ref), tuple) and index[ref][1].get("status") == "verified" and index[ref][1].get("evidenceLevel") != "screening_surrogate" and bool(index[ref][1].get("evidenceRefs")) for ref in result_refs)  # 检查真实工程证据。
            if not verified:  # 检查最终选择是否缺少工程证据。
                issues.append(_issue("BSDL-DESIGN-HITL-005", "error", path + "/selectedCandidateRef", "最终 selected 候选必须至少关联一条 verified 工程评价；代理筛选和部分预览不能直接放行。", decision_id, "verified non-surrogate evaluation", result_refs))  # 记录最终选择证据缺失。

    active_iteration_value = index.get(active_iteration, (None, None))[1] if isinstance(active_iteration, str) else None  # 读取活动迭代对象。
    active_stage = None  # 初始化活动阶段名称。
    if isinstance(active_iteration_value, dict):  # 检查是否存在活动迭代。
        active_stage_record = next((item for item in _as_list(active_iteration_value.get("stageRecords")) if isinstance(item, dict) and item.get("status") in {"active", "requires_human", "blocked"}), None)  # 查找当前活动或阻断阶段。
        active_stage = active_stage_record.get("stage") if isinstance(active_stage_record, dict) else None  # 保存当前阶段名称。
    stats = {"designProcessPresent": True, "designBriefs": len(_as_list(process.get("briefs"))), "designIterations": len(_as_list(process.get("iterations"))), "designCandidates": len(_as_list(process.get("candidates"))), "designEvaluations": len(_as_list(process.get("evaluationResults"))), "designDecisions": len(_as_list(process.get("decisions"))), "designObjectives": len(_as_list(process.get("objectives"))), "designConstraints": len(_as_list(process.get("constraints"))), "activeIterationRef": active_iteration, "activeDesignStage": active_stage, "generativeLoop": generative_loop, "evidenceObjectCount": len(evidence_refs), "evidencePaths": evidence_paths}  # 汇总设计层统计和当前闭环位置。
    return issues, stats  # 返回设计问题和统计。
