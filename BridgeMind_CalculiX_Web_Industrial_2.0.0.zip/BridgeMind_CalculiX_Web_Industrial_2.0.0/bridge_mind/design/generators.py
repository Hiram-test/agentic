"""把 BridgeMind 2.0 候选方案确定性物化为可验证的桥梁语义与预览分析模型。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
import hashlib  # 提供稳定候选后缀与模型摘要。
import math  # 提供拱轴线、距离和有限数计算。
from typing import Any  # 提供通用 JSON 类型注解。
from ..utils import deep_copy  # 复用安全深复制。


def _suffix(candidate_id: str) -> str:  # 从候选 ID 生成合法且稳定的短后缀。
    return hashlib.sha256(candidate_id.encode("utf-8")).hexdigest()[:10]  # 返回十位哈希后缀。


def _number(value: Any, default: float) -> float:  # 把候选变量安全转换为有限浮点数。
    try:  # 捕获非法数值。
        parsed = float(value)  # 尝试转换为浮点数。
        return parsed if math.isfinite(parsed) else default  # 返回有限值或默认值。
    except (TypeError, ValueError):  # 处理空值和非数值文本。
        return default  # 返回默认值。


def _candidate_value(candidate: dict[str, Any], variable_id: str, default: float) -> float:  # 读取候选变量并提供有限数回退。
    values = candidate.get("variableValues", {}) if isinstance(candidate.get("variableValues"), dict) else {}  # 读取候选变量字典。
    return _number(values.get(variable_id), default)  # 返回指定变量的数值。


def _is_generated(item: Any) -> bool:  # 判断对象是否由候选预览生成。
    if not isinstance(item, dict):  # 跳过非对象成员。
        return False  # 非对象不视为设计生成对象。
    attributes = item.get("attributes", {}) if isinstance(item.get("attributes"), dict) else {}  # 读取对象扩展属性。
    tags = item.get("tags", []) if isinstance(item.get("tags"), list) else []  # 读取对象标签。
    return attributes.get("designGenerated") is True or attributes.get("placeholder") is True or "design_generated" in tags  # 返回设计生成标记。


def _remove_generated(document: dict[str, Any]) -> None:  # 移除上一轮候选生成的语义与预览对象。
    for collection in ["nodes", "components", "connections", "loads", "materials", "sections"]:  # 遍历带设计生成标识的对象集合。
        values = document.get(collection, []) if isinstance(document.get(collection), list) else []  # 读取当前集合。
        document[collection] = [item for item in values if not _is_generated(item)]  # 保留非设计生成对象。
    for collection, prefix in [("analysisTasks", "task.design.generated."), ("meshPolicies", "mesh.design.generated."), ("solverPlans", "solver.design.generated.")]:  # 遍历以稳定 ID 标记的任务对象集合。
        values = document.get(collection, []) if isinstance(document.get(collection), list) else []  # 读取当前任务对象集合。
        document[collection] = [item for item in values if not (isinstance(item, dict) and str(item.get("id", "")).startswith(prefix))]  # 移除上一轮生成任务对象。
    load_cases = document.get("loadCases", []) if isinstance(document.get("loadCases"), list) else []  # 读取荷载工况集合。
    document["loadCases"] = [item for item in load_cases if not (isinstance(item, dict) and str(item.get("id", "")).startswith("lc.design.generated."))]  # 移除上一轮生成工况。


def _ensure_agent(document: dict[str, Any], actor: str) -> None:  # 确保生成主体存在于责任主体集合。
    agents = document.setdefault("agents", [])  # 获取责任主体集合。
    if not any(isinstance(item, dict) and item.get("id") == actor for item in agents):  # 检查主体是否已登记。
        agents.append({"id": actor, "name": "BridgeMind 2.0 Design Agent", "kind": "software", "version": "2.0.0"})  # 添加生成主体记录。


def _ensure_material_and_section(document: dict[str, Any], suffix: str, candidate: dict[str, Any]) -> tuple[str, str, dict[str, float]]:  # 创建与构件尺度变量一致的窄域预览材料和截面。
    candidate_id = str(candidate["id"])  # 读取候选 ID。
    member_scale = min(max(_candidate_value(candidate, "design.variable.member_scale", 1.0), 0.25), 4.0)  # 读取并约束构件尺度系数。
    area = 3.20 * member_scale**2  # 依据相似尺度计算截面面积代理。
    inertia = 4.20 * member_scale**4  # 依据相似尺度计算主惯性矩代理。
    torsion = 2.10 * member_scale**4  # 依据相似尺度计算扭转常数代理。
    material_id = f"mat.design.generated.{suffix}"  # 构造材料 ID。
    section_id = f"sec.design.generated.{suffix}"  # 构造截面 ID。
    materials = document.setdefault("materials", [])  # 获取材料集合。
    sections = document.setdefault("sections", [])  # 获取截面集合。
    materials.append({"id": material_id, "name": "C50 等效线弹性混凝土", "model": "linear_elastic", "density": 2500.0, "elasticModulus": 34500000000.0, "poissonRatio": 0.20, "shearModulus": 14375000000.0, "thermalExpansion": 1.0e-5, "yieldStrength": None, "tags": ["design_generated", "preview_only", candidate_id], "plasticity": None, "creep": None, "relaxation": None})  # 添加预览材料。
    sections.append({"id": section_id, "name": "候选预览等效截面", "shape": "generic", "area": area, "iy": inertia, "iz": inertia, "torsionConstant": torsion, "dimensions": {"memberScale": member_scale, "previewOnly": 1.0}, "tags": ["design_generated", "preview_only", candidate_id]})  # 添加候选尺度控制的预览截面。
    return material_id, section_id, {"memberScale": member_scale, "area": area, "inertia": inertia, "torsionConstant": torsion, "density": 2500.0}  # 返回材料、截面和透明截面指标。


def _root_component(document: dict[str, Any]) -> str | None:  # 查找非生成桥梁根构件作为候选父对象。
    for component in document.get("components", []):  # 遍历现有构件。
        if isinstance(component, dict) and component.get("category") == "bridge" and not _is_generated(component):  # 检查桥梁根构件。
            return str(component.get("id"))  # 返回桥梁根构件 ID。
    return None  # 未找到时返回空。


def _node(node_id: str, name: str, position: list[float], support: bool, candidate_id: str, actor: str) -> dict[str, Any]:  # 构造设计生成结构节点。
    constraints = {"ux": support, "uy": True, "uz": support, "rx": True, "ry": support, "rz": True}  # 固定全部支座自由度，并约束普通节点的出平面自由度形成稳定二维框架。
    roles = ["geometry", "joint"] + (["support"] if support else [])  # 构造节点语义角色。
    return {"id": node_id, "name": name, "position": [float(value) for value in position], "coordinateSystemRef": "cs.global", "roles": roles, "constraints": constraints, "tags": ["design_generated"], "sourceIds": {}, "attributes": {"designGenerated": True, "designCandidateRef": candidate_id, "generatedBy": actor, "plane": "xz"}}  # 返回节点对象。


def _component(component_id: str, name: str, start_ref: str, end_ref: str, start: list[float], end: list[float], parent_ref: str | None, material_ref: str, section_ref: str, candidate_id: str, actor: str, role: str) -> dict[str, Any]:  # 构造设计生成线构件。
    category = "crossbeam" if role == "crossbeam" else "girder" if role in {"girder", "deck", "arch_rib"} else "rod" if role in {"hanger", "diagonal"} else "column"  # 根据设计角色选择桥梁构件类别。
    return {"id": component_id, "name": name, "category": category, "topology": "line", "parentRef": parent_ref, "nodeRefs": [start_ref, end_ref], "materialRef": material_ref, "sectionRef": section_ref, "geometry": {"kind": "line", "points": [[float(value) for value in start], [float(value) for value in end]]}, "analysis": {"elementType": "frame3d", "active": True, "localUp": [0.0, 1.0, 0.0], "finiteElementModelRef": None, "shellSectionRef": None, "solidSectionRef": None}, "attributes": {"designGenerated": True, "designCandidateRef": candidate_id, "generatedBy": actor, "designRole": role, "loadBearing": True, "previewOnly": True}, "featureDescriptors": {"length": math.dist(start, end)}, "tags": ["design_generated", role], "sourceIds": {}}  # 返回构件对象。


def _connection(connection_id: str, name: str, node_ref: str, participants: list[str], candidate_id: str, actor: str) -> dict[str, Any]:  # 构造节点处刚性语义连接。
    return {"id": connection_id, "name": name, "kind": "shared_node", "nodeRef": node_ref, "participantRefs": list(participants), "coordinateSystemRef": "cs.global", "mechanical": {"dofs": {"ux": True, "uy": True, "uz": True, "rx": True, "ry": True, "rz": True}, "stiffness": None, "gap": None, "friction": None}, "attributes": {"designGenerated": True, "designCandidateRef": candidate_id, "generatedBy": actor}}  # 返回连接对象。


def _archetype_aesthetic_prior(archetype: str) -> float:  # 返回透明且非权威的桥型造型先验。
    priors = {"inverted_y": 0.90, "portal_truss": 0.76, "diamond": 0.94, "h_frame": 0.68, "portal_pylon": 0.76, "h_pylon": 0.68, "split_pylon": 0.90, "deck_arch": 0.84, "through_arch": 0.88, "tied_arch": 0.80, "network_arch": 0.94}  # 定义窄域候选原型先验。
    return float(priors.get(archetype, 0.75))  # 返回原型先验或保守默认值。


def _geometry_metrics(candidate: dict[str, Any], points: dict[str, tuple[list[float], bool]], edges: list[tuple[str, str, str, str]], section_metrics: dict[str, float]) -> dict[str, float | int | str]:  # 计算候选模型的透明几何与资源代理指标。
    total_length = sum(math.dist(points[left][0], points[right][0]) for left, right, _role, _name in edges)  # 计算全部线构件总长度。
    mass_proxy = total_length * float(section_metrics["area"]) * float(section_metrics["density"])  # 计算等效材料质量代理。
    archetype = str(candidate.get("archetype", "unknown"))  # 读取候选原型。
    member_count = len(edges)  # 统计线构件数量。
    joint_count = len(points)  # 统计语义节点数量。
    symmetry_error = 0.0  # 当前确定性生成器保持关于 x=0 或跨中对称的窄域先验。
    constructability_score = max(0.0, min(1.0, 1.0 - max(member_count - 6, 0) * 0.035 - symmetry_error * 0.20))  # 使用构件数量和对称性形成可解释可建造性代理。
    return {"archetype": archetype, "memberCount": member_count, "jointCount": joint_count, "totalMemberLength": round(total_length, 6), "equivalentMassProxy": round(mass_proxy, 6), "memberScale": round(float(section_metrics["memberScale"]), 6), "aestheticPrior": round(_archetype_aesthetic_prior(archetype), 6), "constructabilityProxy": round(constructability_score, 6), "symmetryError": symmetry_error}  # 返回透明且明确非权威的模型指标。


def _append_graph(document: dict[str, Any], candidate: dict[str, Any], actor: str, points: dict[str, tuple[list[float], bool]], edges: list[tuple[str, str, str, str]], loaded_nodes: list[str], generated_kind: str) -> dict[str, Any]:  # 把节点边图写入 BSDL 并建立预览任务。
    candidate_id = str(candidate["id"])  # 读取候选 ID。
    short = _suffix(candidate_id)  # 生成候选短后缀。
    material_ref, section_ref, section_metrics = _ensure_material_and_section(document, short, candidate)  # 创建候选尺度控制的材料和截面。
    parent_ref = _root_component(document)  # 查找桥梁根构件。
    node_ids = {key: f"node.design.generated.{short}.{key}" for key in points}  # 建立逻辑节点到 BSDL ID 的映射。
    new_nodes = [_node(node_ids[key], key, value[0], value[1], candidate_id, actor) for key, value in points.items()]  # 构造全部节点对象。
    new_components = []  # 初始化构件对象列表。
    incident: dict[str, list[str]] = {key: [] for key in points}  # 初始化节点邻接构件索引。
    for position, (left, right, role, name) in enumerate(edges):  # 遍历构件边定义。
        component_id = f"comp.design.generated.{short}.{position + 1}"  # 构造构件 ID。
        new_components.append(_component(component_id, name, node_ids[left], node_ids[right], points[left][0], points[right][0], parent_ref, material_ref, section_ref, candidate_id, actor, role))  # 构造并保存构件。
        incident[left].append(component_id)  # 记录起点邻接构件。
        incident[right].append(component_id)  # 记录终点邻接构件。
    new_connections = [_connection(f"conn.design.generated.{short}.{key}", f"{key} 连接", node_ids[key], refs, candidate_id, actor) for key, refs in incident.items() if refs]  # 构造节点连接对象。
    document.setdefault("nodes", []).extend(new_nodes)  # 写入设计生成节点。
    document.setdefault("components", []).extend(new_components)  # 写入设计生成构件。
    document.setdefault("connections", []).extend(new_connections)  # 写入设计生成连接。
    load_case_ref = f"lc.design.generated.{short}"  # 构造预览荷载工况 ID。
    task_ref = f"task.design.generated.{short}"  # 构造预览分析任务 ID。
    mesh_policy_ref = f"mesh.design.generated.{short}"  # 构造预览网格策略 ID。
    solver_plan_ref = f"solver.design.generated.{short}"  # 构造预览求解计划 ID。
    document.setdefault("loadCases", []).append({"id": load_case_ref, "name": "候选结构线弹性预览工况", "type": "static", "factor": 1.0})  # 写入预览荷载工况。
    load_scale = 1.0 / max(len(loaded_nodes), 1)  # 计算多加载点分配系数。
    for position, logical_ref in enumerate(loaded_nodes):  # 遍历加载节点。
        document.setdefault("loads", []).append({"id": f"load.design.generated.{short}.{position + 1}", "name": f"候选预览荷载 {position + 1}", "caseRef": load_case_ref, "kind": "nodal", "targetNodeRef": node_ids[logical_ref], "targetComponentRef": None, "force": [120000.0 * load_scale, 0.0, -600000.0 * load_scale], "moment": [0.0, 0.0, 0.0], "coordinateSystemRef": "cs.global", "attributes": {"designGenerated": True, "designCandidateRef": candidate_id, "previewOnly": True}})  # 写入节点荷载。
    characteristic = max(max(abs(value) for value in coordinates) for coordinates, _support in points.values())  # 计算几何特征尺度。
    document.setdefault("analysisTasks", []).append({"id": task_ref, "name": "BridgeMind 2.0 候选线弹性预览", "type": "linear_static", "loadCaseRefs": [load_case_ref], "qoi": ["maxTranslation", "maxMoment", "relativeForceBalanceResidual"], "accuracyTarget": 0.05, "budget": {"maxElements": 5000, "maxRuns": 20, "maxWallSeconds": 120.0}, "status": "approved"})  # 写入预览分析任务。
    document.setdefault("meshPolicies", []).append({"id": mesh_policy_ref, "name": "BridgeMind 2.0 候选线构件网格", "taskRef": task_ref, "baseSize": max(characteristic / 12.0, 0.5), "elementFamily": "frame", "regionRules": [], "budget": {"maxElements": 5000, "maxIterations": 2}, "status": "approved"})  # 写入预览网格策略。
    document.setdefault("solverPlans", []).append({"id": solver_plan_ref, "name": "BridgeMind 2.0 内置空间梁预览", "taskRef": task_ref, "meshPolicyRef": mesh_policy_ref, "solver": "builtin_frame3d", "settings": {"authoritative": False, "purpose": "candidate_screening", "analysis": "linear_static", "plane": "xz"}, "status": "approved", "solverProfileRef": None, "finiteElementModelRef": None, "stageRefs": []})  # 写入与实际执行器一致的预览求解计划。
    metrics = _geometry_metrics(candidate, points, edges, section_metrics)  # 计算透明几何、材料和可建造性代理指标。
    model_digest = hashlib.sha256(str(sorted((item["id"], item["nodeRefs"]) for item in new_components)).encode("utf-8")).hexdigest()  # 计算当前候选线框拓扑摘要。
    return {"generatedKind": generated_kind, "nodeRefs": [item["id"] for item in new_nodes], "componentRefs": [item["id"] for item in new_components], "connectionRefs": [item["id"] for item in new_connections], "materialRef": material_ref, "sectionRef": section_ref, "loadCaseRef": load_case_ref, "analysisTaskRef": task_ref, "meshPolicyRef": mesh_policy_ref, "solverPlanRef": solver_plan_ref, "engineeringMetrics": metrics, "modelHash": f"sha256:{model_digest}", "previewOnly": True}  # 返回生成报告。


def _pylon_graph(candidate: dict[str, Any]) -> tuple[dict[str, tuple[list[float], bool]], list[tuple[str, str, str, str]], list[str], str]:  # 根据桥塔原型生成稳定线框拓扑。
    height = max(_candidate_value(candidate, "design.variable.height", 100.0), 10.0)  # 读取并约束桥塔高度。
    slenderness = max(_candidate_value(candidate, "design.variable.slenderness", 4.0), 1.2)  # 读取并约束高宽比。
    width = max(_candidate_value(candidate, "design.variable.width", height / slenderness), height / 12.0)  # 读取或推导桥塔宽度。
    bifurcation = min(max(_candidate_value(candidate, "design.variable.bifurcation_ratio", 0.60), 0.20), 0.90)  # 读取并约束分叉高度比。
    crossbeam = min(max(_candidate_value(candidate, "design.variable.crossbeam_ratio", 0.25), 0.08), 0.82)  # 读取并约束横梁高度比。
    archetype = str(candidate.get("archetype", "inverted_y"))  # 读取候选桥塔原型。
    if archetype in {"h_frame", "portal_pylon", "h_pylon"}:  # 生成 H 型或门式桥塔。
        points = {"base_l": ([-width / 2.0, 0.0, 0.0], True), "base_r": ([width / 2.0, 0.0, 0.0], True), "cross_l": ([-width / 2.0, 0.0, height * crossbeam], False), "cross_r": ([width / 2.0, 0.0, height * crossbeam], False), "top_l": ([-width / 2.0, 0.0, height], False), "top_r": ([width / 2.0, 0.0, height], False)}  # 定义 H 型节点。
        edges = [("base_l", "cross_l", "leg", "左塔柱下段"), ("cross_l", "top_l", "leg", "左塔柱上段"), ("base_r", "cross_r", "leg", "右塔柱下段"), ("cross_r", "top_r", "leg", "右塔柱上段"), ("cross_l", "cross_r", "crossbeam", "中横梁"), ("top_l", "top_r", "crossbeam", "塔顶横梁")]  # 定义 H 型构件。
        return points, edges, ["top_l", "top_r"], "pylon_h_frame"  # 返回 H 型图。
    if archetype == "portal_truss":  # 生成门式桁架桥塔。
        upper = max(bifurcation, crossbeam + 0.18)  # 计算上横梁高度比。
        points = {"base_l": ([-width / 2.0, 0.0, 0.0], True), "base_r": ([width / 2.0, 0.0, 0.0], True), "mid_l": ([-width / 2.0, 0.0, height * crossbeam], False), "mid_r": ([width / 2.0, 0.0, height * crossbeam], False), "upper_l": ([-width / 2.0, 0.0, height * upper], False), "upper_r": ([width / 2.0, 0.0, height * upper], False), "top_l": ([-width / 2.0, 0.0, height], False), "top_r": ([width / 2.0, 0.0, height], False)}  # 定义门式桁架节点。
        edges = [("base_l", "mid_l", "leg", "左塔柱下段"), ("mid_l", "upper_l", "leg", "左塔柱中段"), ("upper_l", "top_l", "leg", "左塔柱上段"), ("base_r", "mid_r", "leg", "右塔柱下段"), ("mid_r", "upper_r", "leg", "右塔柱中段"), ("upper_r", "top_r", "leg", "右塔柱上段"), ("mid_l", "mid_r", "crossbeam", "下横梁"), ("upper_l", "upper_r", "crossbeam", "上横梁"), ("mid_l", "upper_r", "diagonal", "左上斜撑"), ("mid_r", "upper_l", "diagonal", "右上斜撑"), ("top_l", "top_r", "crossbeam", "塔顶横梁")]  # 定义门式桁架构件。
        return points, edges, ["top_l", "top_r"], "pylon_portal_truss"  # 返回门式桁架图。
    if archetype in {"diamond", "diamond_pylon", "split_pylon"}:  # 生成钻石型桥塔。
        waist = height * bifurcation  # 计算腰部高度。
        top_half = width * 0.28  # 计算塔顶半宽。
        points = {"base_l": ([-width / 2.0, 0.0, 0.0], True), "base_r": ([width / 2.0, 0.0, 0.0], True), "waist": ([0.0, 0.0, waist], False), "top_l": ([-top_half, 0.0, height], False), "top_r": ([top_half, 0.0, height], False), "cross_l": ([-width * 0.18, 0.0, height * crossbeam], False), "cross_r": ([width * 0.18, 0.0, height * crossbeam], False)}  # 定义钻石型节点。
        edges = [("base_l", "cross_l", "leg", "左下塔腿"), ("cross_l", "waist", "leg", "左下斜腿"), ("base_r", "cross_r", "leg", "右下塔腿"), ("cross_r", "waist", "leg", "右下斜腿"), ("cross_l", "cross_r", "crossbeam", "下横梁"), ("waist", "top_l", "leg", "左上斜腿"), ("waist", "top_r", "leg", "右上斜腿"), ("top_l", "top_r", "crossbeam", "塔顶横梁")]  # 定义钻石型构件。
        return points, edges, ["top_l", "top_r"], "pylon_diamond"  # 返回钻石型图。
    cross_ratio = min(crossbeam, bifurcation * 0.82)  # 计算倒 Y 横梁所在高度比。
    interpolation = cross_ratio / max(bifurcation, 1.0e-6)  # 计算横梁点沿下塔腿的插值比例。
    cross_half = width * 0.5 * (1.0 - interpolation)  # 计算横梁端点半宽。
    points = {"base_l": ([-width / 2.0, 0.0, 0.0], True), "base_r": ([width / 2.0, 0.0, 0.0], True), "cross_l": ([-cross_half, 0.0, height * cross_ratio], False), "cross_r": ([cross_half, 0.0, height * cross_ratio], False), "split": ([0.0, 0.0, height * bifurcation], False), "top": ([0.0, 0.0, height], False)}  # 定义倒 Y 型节点。
    edges = [("base_l", "cross_l", "leg", "左塔腿下段"), ("cross_l", "split", "leg", "左塔腿上段"), ("base_r", "cross_r", "leg", "右塔腿下段"), ("cross_r", "split", "leg", "右塔腿上段"), ("cross_l", "cross_r", "crossbeam", "桥面横梁"), ("split", "top", "leg", "上塔柱")]  # 定义倒 Y 型构件。
    return points, edges, ["top"], "pylon_inverted_y"  # 返回倒 Y 型图。


def _arch_graph(candidate: dict[str, Any]) -> tuple[dict[str, tuple[list[float], bool]], list[tuple[str, str, str, str]], list[str], str]:  # 根据候选参数生成简化拱桥线框。
    span = max(_candidate_value(candidate, "design.variable.span", 80.0), 20.0)  # 读取并约束拱桥跨度。
    depth_ratio = min(max(_candidate_value(candidate, "design.variable.structural_depth_ratio", 0.18), 0.05), 0.40)  # 读取并约束矢跨比。
    rise = span * depth_ratio  # 计算拱矢高。
    point_count = 7  # 设置拱轴离散节点数。
    points: dict[str, tuple[list[float], bool]] = {}  # 初始化拱桥节点。
    for index in range(point_count):  # 生成抛物线拱轴节点。
        ratio = index / (point_count - 1)  # 计算无量纲跨向位置。
        x = span * ratio  # 计算跨向坐标。
        z = 4.0 * rise * ratio * (1.0 - ratio)  # 计算抛物线高程。
        points[f"arch_{index}"] = ([x, 0.0, z], index in {0, point_count - 1})  # 保存拱轴节点并固定两端。
        points[f"deck_{index}"] = ([x, 0.0, rise * 1.08], False)  # 保存桥面节点。
    edges: list[tuple[str, str, str, str]] = []  # 初始化拱桥构件。
    for index in range(point_count - 1):  # 连接相邻拱轴与桥面节点。
        edges.append((f"arch_{index}", f"arch_{index + 1}", "arch_rib", f"拱肋段 {index + 1}"))  # 添加拱肋构件。
        edges.append((f"deck_{index}", f"deck_{index + 1}", "deck", f"桥面梁段 {index + 1}"))  # 添加桥面构件。
    for index in range(point_count):  # 添加端柱和中间竖向联结构件。
        edges.append((f"arch_{index}", f"deck_{index}", "hanger", f"竖向联结 {index + 1}"))  # 添加立柱或吊杆等效构件。
    return points, edges, [f"deck_{index}" for index in range(1, point_count - 1)], "arch_frame"  # 返回拱桥图。


def _girder_graph(candidate: dict[str, Any]) -> tuple[dict[str, tuple[list[float], bool]], list[tuple[str, str, str, str]], list[str], str]:  # 为其他桥型生成最小可求解梁系候选。
    span = max(_candidate_value(candidate, "design.variable.span", 60.0), 10.0)  # 读取并约束梁系跨度。
    points = {"left": ([0.0, 0.0, 0.0], True), "quarter": ([span * 0.25, 0.0, 0.0], False), "mid": ([span * 0.50, 0.0, 0.0], False), "three_quarter": ([span * 0.75, 0.0, 0.0], False), "right": ([span, 0.0, 0.0], True)}  # 定义简化梁系节点。
    edges = [("left", "quarter", "girder", "主梁段 1"), ("quarter", "mid", "girder", "主梁段 2"), ("mid", "three_quarter", "girder", "主梁段 3"), ("three_quarter", "right", "girder", "主梁段 4")]  # 定义简化梁系构件。
    return points, edges, ["quarter", "mid", "three_quarter"], "girder_frame"  # 返回梁系图。


def materialize_candidate_geometry(document: dict[str, Any], candidate: dict[str, Any], actor: str) -> tuple[dict[str, Any], dict[str, Any]]:  # 物化窄域桥塔、拱桥或梁系候选并返回可求解预览契约。
    updated = deep_copy(document)  # 深复制输入文档。
    _remove_generated(updated)  # 清理上一轮候选生成对象。
    _ensure_agent(updated, actor)  # 登记当前生成主体。
    bridge_type = str(candidate.get("provenance", {}).get("bridgeType", "generic_bridge")) if isinstance(candidate.get("provenance"), dict) else "generic_bridge"  # 读取候选桥型。
    if bridge_type in {"pylon", "cable_stayed", "suspension"}:  # 选择桥塔线框生成器。
        points, edges, loaded_nodes, generated_kind = _pylon_graph(candidate)  # 生成桥塔节点边图。
    elif bridge_type == "arch":  # 选择拱桥线框生成器。
        points, edges, loaded_nodes, generated_kind = _arch_graph(candidate)  # 生成拱桥节点边图。
    else:  # 处理其他桥型。
        points, edges, loaded_nodes, generated_kind = _girder_graph(candidate)  # 生成最小梁系节点边图。
    report = _append_graph(updated, candidate, actor, points, edges, loaded_nodes, generated_kind)  # 写入 BSDL 语义、荷载与预览任务。
    updated.setdefault("extensions", {}).setdefault("bridgemind:designGeneration", {})[str(candidate["id"])] = {"generator": "deterministic_parametric_frame_v2", "generatedKind": report["generatedKind"], "previewOnly": True, "componentRefs": report["componentRefs"], "taskRef": report["analysisTaskRef"], "modelHash": report["modelHash"], "engineeringMetrics": report["engineeringMetrics"]}  # 保存生成器契约、模型摘要和透明指标。
    return updated, report  # 返回物化文档与生成报告。
