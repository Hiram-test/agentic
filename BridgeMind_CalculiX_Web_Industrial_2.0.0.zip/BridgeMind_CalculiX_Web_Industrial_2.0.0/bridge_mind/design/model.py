"""定义 BSDL Industrial 1.1 的 BridgeMind 2.0 设计过程基础对象。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
from typing import Any  # 提供通用 JSON 类型注解。
from ..utils import deep_copy  # 复用安全深复制。

GENERATION_LOOP = ["modeling", "computation", "evaluation", "feedback"]  # 固定生成式设计的建模—计算—评价—反馈闭环。


def empty_stage_record(stage: str) -> dict[str, Any]:  # 构造一个尚未执行的设计阶段记录。
    if stage not in GENERATION_LOOP:  # 检查阶段是否属于合法生成式闭环。
        raise ValueError(f"不允许的设计阶段：{stage}")  # 阻断把 generation 等错误概念写成独立阶段。
    return {"stage": stage, "status": "pending", "startedAt": None, "completedAt": None, "actorRef": None, "methodNames": [], "artifactRefs": [], "evidenceRefs": [], "metrics": {}, "limitations": [], "nextAction": None}  # 返回固定字段结构。


def empty_design_process() -> dict[str, Any]:  # 构造 BSDL 1.1 的空设计过程对象。
    return {"version": "2.0.0", "activeBriefRef": None, "activeIterationRef": None, "generativeLoop": list(GENERATION_LOOP), "contexts": [], "requirements": [], "objectives": [], "constraints": [], "preferences": [], "variables": [], "briefs": [], "candidates": [], "evaluationPlans": [], "evaluationResults": [], "iterations": [], "decisions": [], "status": "draft"}  # 返回固定字段结构。


def ensure_design_process(document: dict[str, Any]) -> dict[str, Any]:  # 确保任意工业文档具备完整设计过程容器。
    process = document.setdefault("designProcess", empty_design_process())  # 获取或创建设计过程对象。
    defaults = empty_design_process()  # 读取标准空对象。
    for key, value in defaults.items():  # 遍历标准字段。
        process.setdefault(key, deep_copy(value))  # 为旧文档补齐缺失字段。
    process["version"] = "2.0.0"  # 把运行时设计过程统一升级为 BridgeMind 2.0 语义版本。
    process["generativeLoop"] = list(GENERATION_LOOP)  # 强制生成式设计保持四阶段闭环定义。
    return process  # 返回规范化设计过程对象。
