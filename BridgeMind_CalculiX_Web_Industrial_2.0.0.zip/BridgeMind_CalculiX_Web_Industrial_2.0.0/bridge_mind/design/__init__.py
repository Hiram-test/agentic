"""BridgeMind 2.0 的设计意图、多目标候选、工程证据与反馈闭环。"""  # 说明子包用途。
from .engine import apply_design_feedback, build_design_skill, compile_design_intent, evaluate_design_candidates, generate_design_candidates, materialize_design_candidate, record_design_evidence, run_design_loop  # 导出设计闭环公共函数。
from .model import empty_design_process, ensure_design_process  # 导出设计过程基础对象。
from .validation import validate_design_process  # 导出设计语义验证函数。
__all__ = ["apply_design_feedback", "build_design_skill", "compile_design_intent", "empty_design_process", "ensure_design_process", "evaluate_design_candidates", "generate_design_candidates", "materialize_design_candidate", "record_design_evidence", "run_design_loop", "validate_design_process"]  # 声明公共接口。
