"""把自然语言设计意图编译为可验证的多目标生成式设计闭环。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
import hashlib  # 提供确定性设计对象 ID。
import json  # 提供稳定 JSON 序列化。
import math  # 提供有限数与归一化计算。
import re  # 提供中英文设计条件提取。
from typing import Any  # 提供通用 JSON 类型注解。
from ..utils import deep_copy, utc_now  # 复用深复制和时间戳。
from .generators import materialize_candidate_geometry  # 导入确定性桥塔、拱桥和梁系候选生成器。
from .model import GENERATION_LOOP, empty_design_process, empty_stage_record, ensure_design_process  # 导入生成式闭环和设计过程基础对象。




def _ensure_actor(document: dict[str, Any], actor_id: str) -> None:  # 确保设计操作主体进入责任链。
    agents = document.setdefault("agents", [])  # 获取责任主体列表。
    if any(isinstance(item, dict) and item.get("id") == actor_id for item in agents):  # 检查主体是否已存在。
        return  # 已存在时保持原对象。
    kind = "software" if actor_id.startswith("software.") else "person"  # 根据稳定 ID 推断主体类型。
    agents.append({"id": actor_id, "name": actor_id, "kind": kind, "version": "2.0.0" if kind == "software" else None})  # 添加可追溯责任主体。


def _prepare_document(document: dict[str, Any], actor: str) -> dict[str, Any]:  # 把旧 BSDL 文档升级为 BridgeMind 2.0 可执行设计文档。
    is_current = document.get("languageVersion") == "1.1.0" and str(document.get("$schema", "")).endswith("bsdl-industrial.schema.json")  # 检查是否已采用 BSDL 1.1 工业语义。
    if is_current:  # 处理当前语言文档。
        updated = deep_copy(document)  # 深复制当前文档。
    else:  # 处理旧 BSDL 文档。
        from ..industrial.migration import upgrade_document  # 延迟导入迁移器避免模块初始化循环。
        updated = upgrade_document(document)  # 确定性升级旧文档。
    ensure_design_process(updated)  # 补齐设计过程容器。
    _ensure_actor(updated, actor)  # 登记设计操作责任主体。
    return updated  # 返回可执行设计文档。

def _canonical(value: Any) -> str:  # 生成稳定 JSON 文本。
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))  # 使用稳定键序和紧凑分隔符。


def _stable_id(prefix: str, value: Any) -> str:  # 根据内容生成可复现 ID。
    digest = hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()[:14]  # 计算短 SHA-256 摘要。
    return f"{prefix}.{digest}"  # 返回带对象族前缀的 ID。


def _iteration_by_id(process: dict[str, Any], iteration_id: str | None) -> dict[str, Any] | None:  # 按稳定 ID 查找设计迭代。
    if not isinstance(iteration_id, str):  # 检查迭代引用是否有效。
        return None  # 无有效引用时返回空。
    return next((item for item in process.get("iterations", []) if isinstance(item, dict) and item.get("id") == iteration_id), None)  # 返回匹配迭代或空值。


def _stage_record(iteration: dict[str, Any], stage: str) -> dict[str, Any]:  # 读取并必要时补建指定生成式阶段记录。
    if stage not in GENERATION_LOOP:  # 检查阶段名称是否属于建模—计算—评价—反馈。
        raise ValueError(f"不允许的设计阶段：{stage}")  # 阻断 generation 等层级错误。
    records = iteration.setdefault("stageRecords", [empty_stage_record(item) for item in GENERATION_LOOP])  # 获取或创建四阶段记录。
    record = next((item for item in records if isinstance(item, dict) and item.get("stage") == stage), None)  # 查找目标阶段记录。
    if record is None:  # 检查旧迭代是否缺少目标阶段。
        record = empty_stage_record(stage)  # 构造缺失阶段记录。
        records.append(record)  # 把补建阶段加入迭代。
    records.sort(key=lambda item: GENERATION_LOOP.index(str(item.get("stage"))) if str(item.get("stage")) in GENERATION_LOOP else 999)  # 保持四阶段固定顺序。
    return record  # 返回阶段记录。


def _begin_design_iteration(process: dict[str, Any], brief: dict[str, Any], plan_ref: str | None, actor: str) -> dict[str, Any]:  # 为一次候选建模—计算—评价—反馈闭环创建迭代对象。
    existing_indices = [int(item.get("index", 0)) for item in process.get("iterations", []) if isinstance(item, dict) and item.get("briefRef") == brief.get("id")]  # 收集同一设计任务既有迭代编号。
    index = max(existing_indices, default=0) + 1  # 生成单调递增迭代编号。
    iteration_id = _stable_id("design.iteration", {"brief": brief.get("id"), "index": index})  # 生成稳定迭代 ID。
    stage_records = [empty_stage_record(stage) for stage in GENERATION_LOOP]  # 初始化建模、计算、评价和反馈四阶段。
    stage_records[0].update({"status": "active", "startedAt": utc_now(), "actorRef": actor, "methodNames": ["candidate_scheme_modeling"], "nextAction": "materialize_candidate_models"})  # 激活建模阶段并声明下一动作。
    iteration = {"id": iteration_id, "name": f"{brief.get('name', brief.get('id'))} 第 {index} 轮", "index": index, "briefRef": brief.get("id"), "planRef": plan_ref, "stageSequence": list(GENERATION_LOOP), "stageRecords": stage_records, "candidateRefs": [], "evaluationResultRefs": [], "selectedCandidateRef": None, "feedbackRefs": [], "status": "active", "startedAt": utc_now(), "completedAt": None, "nextAction": "materialize_candidate_models", "humanApprovalRequired": True}  # 构造可审计设计迭代对象。
    process.setdefault("iterations", []).append(iteration)  # 把新迭代写入设计过程。
    process["activeIterationRef"] = iteration_id  # 设置当前活动迭代。
    return iteration  # 返回新建迭代对象。


def refresh_design_iteration(process: dict[str, Any], iteration_id: str, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 根据候选模型、计算证据、评价和人工决策刷新迭代状态。
    iteration = _iteration_by_id(process, iteration_id)  # 查找目标迭代。
    if iteration is None:  # 检查迭代是否存在。
        raise KeyError(f"设计迭代不存在：{iteration_id}")  # 报告悬空迭代引用。
    candidate_refs = [ref for ref in iteration.get("candidateRefs", []) if isinstance(ref, str)]  # 读取本轮候选引用。
    candidates = [item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") in candidate_refs]  # 读取本轮候选对象。
    result_index = {item.get("id"): item for item in process.get("evaluationResults", []) if isinstance(item, dict)}  # 建立评价结果索引。
    modeled_count = sum(1 for item in candidates if bool(item.get("modelArtifactRefs")) or (isinstance(item.get("provenance"), dict) and bool(item.get("provenance", {}).get("materialization", {}).get("applied"))))  # 仅按真实模型产物或成功物化审计统计已建模候选，避免把代理初筛状态误算为建模完成。
    computed_count = sum(1 for item in candidates if item.get("resultArtifactRefs"))  # 统计已有求解结果产物的候选。
    engineering_count = 0  # 初始化非代理工程评价计数。
    for candidate in candidates:  # 遍历本轮候选。
        result_refs = candidate.get("evaluationResultRefs", []) if isinstance(candidate.get("evaluationResultRefs"), list) else []  # 读取候选评价引用。
        if any(isinstance(result_index.get(ref), dict) and result_index[ref].get("evidenceLevel") != "screening_surrogate" for ref in result_refs):  # 检查候选是否已有工程评价。
            engineering_count += 1  # 增加工程评价候选计数。
    candidate_count = len(candidates)  # 读取本轮候选总数。
    modeling = _stage_record(iteration, "modeling")  # 获取建模阶段记录。
    computation = _stage_record(iteration, "computation")  # 获取计算阶段记录。
    evaluation = _stage_record(iteration, "evaluation")  # 获取评价阶段记录。
    feedback = _stage_record(iteration, "feedback")  # 获取反馈阶段记录。
    modeling["metrics"].update({"candidateCount": candidate_count, "modeledCandidateCount": modeled_count})  # 更新建模覆盖指标。
    computation["metrics"].update({"candidateCount": candidate_count, "computedCandidateCount": computed_count})  # 更新计算覆盖指标。
    evaluation["metrics"].update({"candidateCount": candidate_count, "engineeringEvaluationCount": engineering_count})  # 更新工程评价覆盖指标。
    if candidate_count and modeled_count >= candidate_count:  # 检查候选建模是否全部完成。
        modeling.update({"status": "completed", "completedAt": modeling.get("completedAt") or utc_now(), "actorRef": actor, "nextAction": "run_candidate_computation"})  # 完成建模阶段。
        if computation.get("status") == "pending":  # 检查计算阶段是否尚未启动。
            computation.update({"status": "active", "startedAt": utc_now(), "actorRef": actor, "nextAction": "run_candidate_computation"})  # 激活计算阶段。
    if candidate_count and computed_count >= candidate_count:  # 检查候选计算是否全部完成。
        computation.update({"status": "completed", "completedAt": computation.get("completedAt") or utc_now(), "actorRef": actor, "nextAction": "evaluate_candidates"})  # 完成计算阶段。
        if evaluation.get("status") == "pending":  # 检查评价阶段是否尚未启动。
            evaluation.update({"status": "active", "startedAt": utc_now(), "actorRef": actor, "nextAction": "evaluate_candidates"})  # 激活评价阶段。
    if candidate_count and engineering_count >= candidate_count:  # 检查候选工程评价是否全部形成。
        evaluation.update({"status": "completed", "completedAt": evaluation.get("completedAt") or utc_now(), "actorRef": actor, "nextAction": "human_review_and_feedback"})  # 完成评价阶段。
        if feedback.get("status") in {"pending", "active"}:  # 检查反馈阶段是否尚未完成。
            feedback.update({"status": "requires_human", "startedAt": feedback.get("startedAt") or utc_now(), "actorRef": actor, "nextAction": "human_review_and_feedback"})  # 把反馈阶段交给责任工程师。
    decision = next((item for item in reversed(process.get("decisions", [])) if isinstance(item, dict) and item.get("iterationRef") == iteration_id and item.get("decision") in {"selected", "rejected", "revise"}), None)  # 查找本轮最近的明确人工决策。
    if decision is not None and bool(decision.get("humanApproval")):  # 检查是否形成经人工批准的反馈。
        feedback.update({"status": "completed", "completedAt": feedback.get("completedAt") or utc_now(), "actorRef": decision.get("createdBy") or actor, "evidenceRefs": list(dict.fromkeys([*feedback.get("evidenceRefs", []), *decision.get("evidenceRefs", [])])), "nextAction": "start_new_iteration" if decision.get("decision") == "revise" else None})  # 完成人机反馈阶段。
        iteration["selectedCandidateRef"] = decision.get("selectedCandidateRef")  # 保存本轮选定候选。
        iteration["status"] = "completed"  # 标记本轮设计迭代完成。
        iteration["completedAt"] = iteration.get("completedAt") or utc_now()  # 保存迭代完成时间。
        iteration["nextAction"] = "start_new_iteration" if decision.get("decision") == "revise" else None  # 保存修订或结束动作。
    elif engineering_count >= candidate_count and candidate_count:  # 处理已完成工程评价但仍待人工决策的状态。
        iteration["nextAction"] = "human_review_and_feedback"  # 明确下一步必须由人完成。
    elif computed_count < candidate_count and modeled_count >= candidate_count and candidate_count:  # 处理建模完成但计算未完成的状态。
        iteration["nextAction"] = "run_candidate_computation"  # 明确下一步为计算。
    else:  # 处理候选模型尚未全部建立的状态。
        iteration["nextAction"] = "materialize_candidate_models"  # 明确下一步为候选建模。
    return iteration  # 返回刷新后的迭代对象。


def _slug(text: str) -> str:  # 把名称压缩为安全标识片段。
    cleaned = re.sub(r"[^A-Za-z0-9]+", "_", text.strip()).strip("_").lower()  # 移除不安全字符并转为小写。
    return cleaned[:40] or "item"  # 返回非空且受限长度的片段。


def _clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:  # 把数值约束到闭区间。
    return max(lower, min(upper, float(value)))  # 返回裁剪结果。


def _normalise_weights(items: list[dict[str, Any]]) -> None:  # 把活动目标权重归一到一。
    active = [item for item in items if item.get("status") == "active"]  # 选择活动目标。
    total = sum(max(0.0, float(item.get("weight", 0.0))) for item in active)  # 计算非负权重和。
    fallback = 1.0 / len(active) if active else 0.0  # 计算无权重时的均分值。
    for item in active:  # 遍历活动目标。
        item["weight"] = max(0.0, float(item.get("weight", 0.0))) / total if total > 0.0 else fallback  # 写入归一权重。


def _find_number(text: str, patterns: list[str]) -> float | None:  # 从文本中提取第一个匹配数值。
    for pattern in patterns:  # 遍历候选正则。
        match = re.search(pattern, text, flags=re.IGNORECASE)  # 执行中英文不区分大小写匹配。
        if match is not None:  # 检查是否命中。
            try:  # 捕获异常数值格式。
                return float(match.group(1))  # 返回首个捕获组数值。
            except (TypeError, ValueError):  # 处理无法转换的匹配。
                continue  # 继续尝试下一正则。
    return None  # 未命中时返回空值。


def _bridge_type(text: str, structured: dict[str, Any]) -> tuple[str, float]:  # 识别桥型或桥塔设计对象。
    explicit = str(structured.get("bridgeType", "")).strip()  # 读取结构化桥型覆盖值。
    if explicit:  # 检查调用方是否明确给出桥型。
        return explicit, 1.0  # 返回明确桥型和最高置信度。
    mapping = [("pylon", ["桥塔", "pylon", "tower"]), ("cable_stayed", ["斜拉桥", "cable-stayed", "cable stayed"]), ("suspension", ["悬索桥", "suspension bridge"]), ("arch", ["拱桥", "arch bridge", "deck arch", "through arch"]), ("beam", ["梁桥", "girder bridge", "box girder"]), ("truss", ["桁架桥", "truss bridge"])]  # 定义桥型关键词。
    lowered = text.lower()  # 生成小写文本用于英文匹配。
    for bridge_type, words in mapping:  # 遍历桥型词典。
        if any(word.lower() in lowered for word in words):  # 检查任一关键词命中。
            return bridge_type, 0.92  # 返回识别桥型和较高置信度。
    return "generic_bridge", 0.45  # 无明确桥型时返回待审通用桥型。


def _objective_specs(text: str, structured: dict[str, Any]) -> list[dict[str, Any]]:  # 提取多目标设计目标。
    requested = structured.get("objectives")  # 读取结构化目标覆盖值。
    if isinstance(requested, list) and requested:  # 检查是否提供结构化目标。
        specs = []  # 初始化结构化目标列表。
        for position, item in enumerate(requested):  # 遍历结构化目标。
            if isinstance(item, str):  # 处理简写字符串目标。
                specs.append({"key": _slug(item), "name": item, "category": "other", "direction": "maximize", "weight": 1.0, "source": "structured_input"})  # 转换为目标规范。
            elif isinstance(item, dict):  # 处理完整目标对象。
                specs.append({"key": str(item.get("key") or item.get("name") or f"objective_{position + 1}"), "name": str(item.get("name") or item.get("key") or f"目标{position + 1}"), "category": str(item.get("category", "other")), "direction": str(item.get("direction", "maximize")), "weight": float(item.get("weight", 1.0)), "target": item.get("target"), "unit": item.get("unit"), "metric": str(item.get("metric") or item.get("key") or item.get("name") or f"objective_{position + 1}"), "analysisTaskRefs": list(item.get("analysisTaskRefs", [])), "codeCheckPlanRefs": list(item.get("codeCheckPlanRefs", [])), "source": str(item.get("source", "structured_input")), "status": str(item.get("status", "active"))})  # 规范化结构化目标及其计算和验算绑定。
        return specs  # 返回结构化目标规范。
    lowered = text.lower()  # 生成小写文本。
    catalogue = [("structural_performance", "结构性能", "safety", "maximize", ["结构", "力学", "安全", "刚度", "强度", "mechanical", "structural", "safety"]), ("aesthetic_quality", "造型质量", "aesthetic", "maximize", ["景观", "美学", "视觉", "造型", "文化", "aesthetic", "visual"]), ("cost_efficiency", "经济性", "cost", "maximize", ["造价", "预算", "经济", "成本", "cost", "budget"]), ("carbon_efficiency", "低碳性", "carbon", "maximize", ["碳", "环境", "绿色", "carbon", "environment"]), ("constructability", "可建造性", "constructability", "maximize", ["施工", "建造", "工业化", "manufactur", "construct"]), ("durability", "耐久性", "durability", "maximize", ["耐久", "寿命", "疲劳", "durability", "service life"])]  # 定义目标关键词和统一方向。
    specs = []  # 初始化识别目标列表。
    for key, name, category, direction, words in catalogue:  # 遍历目标词典。
        if any(word.lower() in lowered for word in words):  # 检查文本是否提到目标。
            specs.append({"key": key, "name": name, "category": category, "direction": direction, "weight": 1.0, "source": "natural_language"})  # 保存识别目标。
    if not any(item["key"] == "structural_performance" for item in specs):  # 检查桥梁设计是否缺少结构性能基线。
        specs.insert(0, {"key": "structural_performance", "name": "结构性能", "category": "safety", "direction": "maximize", "weight": 1.0, "source": "domain_default_needs_review"})  # 加入需要人工确认的领域安全基线。
    if len(specs) == 1:  # 检查文本是否完全没有第二目标。
        specs.append({"key": "constructability", "name": "可建造性", "category": "constructability", "direction": "maximize", "weight": 0.5, "source": "domain_default_needs_review"})  # 加入可建造性作为待审默认目标以形成最小多目标问题。
    return specs  # 返回目标规范。


def _make_context(text: str, actor: str, structured: dict[str, Any]) -> dict[str, Any]:  # 构造场地与任务上下文对象。
    context_payload = {"rawText": text, "location": structured.get("location"), "environment": structured.get("environment", {}), "traffic": structured.get("traffic", {}), "urban": structured.get("urban", {}), "visual": structured.get("visual", {}), "geotechnical": structured.get("geotechnical", {})}  # 汇总上下文输入。
    context_id = _stable_id("design.context", context_payload)  # 生成上下文稳定 ID。
    return {"id": context_id, "name": str(structured.get("contextName", "设计场景")), "location": structured.get("location"), "transportDemand": structured.get("traffic", {}), "environment": structured.get("environment", {}), "geotechnical": structured.get("geotechnical", {}), "urban": structured.get("urban", {}), "visual": structured.get("visual", {}), "cultural": structured.get("cultural", {}), "sourceRefs": list(structured.get("sourceRefs", [])), "status": "needs_review", "attributes": {"compiledBy": actor}}  # 返回标准化上下文。


def _dimension_specs(text: str, structured: dict[str, Any]) -> list[tuple[str, str, float, str]]:  # 提取关键几何和资源条件。
    values = []  # 初始化条件列表。
    patterns = [("span", "主跨", [r"(?:主跨|跨度|span)[^0-9]{0,12}(\d+(?:\.\d+)?)\s*(?:m|米)?"], "m"), ("height", "高度", [r"(?:桥塔高度|塔高|高度|height)[^0-9]{0,12}(\d+(?:\.\d+)?)\s*(?:m|米)?"], "m"), ("width", "宽度", [r"(?:桥宽|宽度|width)[^0-9]{0,12}(\d+(?:\.\d+)?)\s*(?:m|米)?"], "m"), ("volume_fraction", "材料体积分数", [r"(?:材料用量|体积分数|volume fraction)[^0-9]{0,12}(\d+(?:\.\d+)?)\s*%?"], "%"), ("vehicle_space", "通行净空", [r"(?:通行空间|净空|vehicle space)[^0-9]{0,12}(\d+(?:\.\d+)?)"], "m")]  # 定义数值条件。
    for key, name, regexes, unit in patterns:  # 遍历条件模板。
        value = structured.get(key)  # 读取结构化覆盖值。
        parsed = float(value) if isinstance(value, (int, float)) else _find_number(text, regexes)  # 选择结构化值或文本提取值。
        if parsed is not None:  # 检查是否得到条件。
            if key == "volume_fraction" and parsed > 1.0:  # 检查百分数形式。
                parsed = parsed / 100.0  # 转换为零到一比例。
            values.append((key, name, parsed, unit))  # 保存条件。
    return values  # 返回条件列表。


def compile_design_intent(document: dict[str, Any], raw_text: str, actor: str = "software.bridgemind.design", structured: dict[str, Any] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:  # 把自然语言编译为 BSDL 1.1 设计语义。
    if not str(raw_text).strip():  # 检查设计任务文本。
        raise ValueError("设计意图文本不能为空。")  # 阻止无任务编译。
    structured_input = dict(structured or {})  # 复制结构化补充输入。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    bridge_type, type_confidence = _bridge_type(raw_text, structured_input)  # 识别设计对象。
    context = _make_context(raw_text, actor, structured_input)  # 构造场景上下文。
    objective_specs = _objective_specs(raw_text, structured_input)  # 提取多目标规范。
    dimensions = _dimension_specs(raw_text, structured_input)  # 提取几何与资源条件。
    requirement_seed = {"bridgeType": bridge_type, "rawText": raw_text}  # 构造要求 ID 种子。
    bridge_requirement = {"id": _stable_id("design.requirement", requirement_seed), "name": "桥梁设计对象", "category": "functional", "statement": f"设计对象类型为 {bridge_type}。", "priority": 5, "mandatory": True, "source": "natural_language" if type_confidence > 0.5 else "inferred_needs_review", "sourceRef": None, "verificationMethod": "人工确认桥型与设计范围", "status": "active" if type_confidence > 0.5 else "needs_review"}  # 构造桥型要求。
    objectives = []  # 初始化目标对象列表。
    for spec in objective_specs:  # 遍历目标规范。
        objective_id = f"design.objective.{_slug(spec['key'])}"  # 生成可读目标 ID。
        objectives.append({"id": objective_id, "name": spec["name"], "category": spec["category"], "direction": spec["direction"], "weight": float(spec["weight"]), "target": spec.get("target"), "unit": spec.get("unit"), "metric": str(spec.get("metric", spec["key"])), "analysisTaskRefs": list(spec.get("analysisTaskRefs", [])), "codeCheckPlanRefs": list(spec.get("codeCheckPlanRefs", [])), "source": spec["source"], "status": str(spec.get("status", "active"))})  # 构造带计算和验算绑定的目标对象。
    _normalise_weights(objectives)  # 归一化目标权重。
    constraints = []  # 初始化约束对象列表。
    variables = []  # 初始化设计变量列表。
    for key, name, value, unit in dimensions:  # 遍历提取条件。
        variable_id = f"design.variable.{key}"  # 生成变量 ID。
        lower = 0.0 if key not in {"volume_fraction"} else 0.01  # 设置保守下界。
        upper = 1.0 if key == "volume_fraction" else max(value * 2.0, value + 1.0)  # 设置待审搜索上界。
        variables.append({"id": variable_id, "name": name, "category": "geometry" if key != "volume_fraction" else "resource", "dataType": "number", "unit": unit, "lower": lower, "upper": upper, "allowedValues": [], "defaultValue": value, "currentValue": value, "parameterPath": f"/extensions/bridgemind:designParameters/{key}", "dependencies": [], "active": True, "status": "needs_review"})  # 构造变量对象。
        operator = "==" if key in {"span", "height", "width", "vehicle_space"} else "<="  # 选择默认约束运算符。
        constraints.append({"id": f"design.constraint.{key}", "name": f"{name}约束", "category": "geometry" if key != "volume_fraction" else "resource", "expression": variable_id, "operator": operator, "limit": value, "unit": unit, "tolerance": max(abs(value) * 0.02, 1.0e-6), "hard": True, "verificationMethod": "候选变量检查；进入工程阶段后由几何或分析证据复核", "analysisTaskRefs": [], "codeCheckPlanRefs": [], "source": "natural_language", "status": "active"})  # 构造设计约束。
    for position, item in enumerate(structured_input.get("constraints", []) if isinstance(structured_input.get("constraints"), list) else []):  # 遍历结构化约束覆盖值。
        if not isinstance(item, dict):  # 跳过非法约束成员。
            continue  # 继续下一约束。
        key = str(item.get("key") or item.get("name") or f"constraint_{position + 1}")  # 读取约束稳定键。
        constraints.append({"id": str(item.get("id") or f"design.constraint.{_slug(key)}"), "name": str(item.get("name") or key), "category": str(item.get("category", "other")), "expression": str(item.get("expression") or item.get("variableRef") or key), "operator": str(item.get("operator", "<=")), "limit": item.get("limit"), "unit": item.get("unit"), "tolerance": max(0.0, _number(item.get("tolerance"), 0.0)), "hard": bool(item.get("hard", True)), "verificationMethod": str(item.get("verificationMethod", "由几何、分析、规范或人工证据验证")), "analysisTaskRefs": list(item.get("analysisTaskRefs", [])), "codeCheckPlanRefs": list(item.get("codeCheckPlanRefs", [])), "source": str(item.get("source", "structured_input")), "status": str(item.get("status", "active"))})  # 构造结构化约束对象。
    for position, item in enumerate(structured_input.get("variables", []) if isinstance(structured_input.get("variables"), list) else []):  # 遍历结构化设计变量覆盖值。
        if not isinstance(item, dict):  # 跳过非法变量成员。
            continue  # 继续下一变量。
        key = str(item.get("key") or item.get("name") or f"variable_{position + 1}")  # 读取变量稳定键。
        variable_id = str(item.get("id") or f"design.variable.{_slug(key)}")  # 生成或读取变量 ID。
        current = item.get("currentValue", item.get("defaultValue"))  # 读取当前或默认变量值。
        variables.append({"id": variable_id, "name": str(item.get("name") or key), "category": str(item.get("category", "other")), "dataType": str(item.get("dataType", "number")), "unit": item.get("unit"), "lower": item.get("lower"), "upper": item.get("upper"), "allowedValues": list(item.get("allowedValues", [])), "defaultValue": item.get("defaultValue", current), "currentValue": current, "parameterPath": str(item.get("parameterPath") or f"/extensions/bridgemind:designParameters/{_slug(key)}"), "dependencies": list(item.get("dependencies", [])), "active": bool(item.get("active", True)), "status": str(item.get("status", "needs_review"))})  # 构造可绑定实际模型字段的设计变量。
    base_variables = [("height", "桥塔高度", 180.0, 30.0, 350.0, "m"), ("bifurcation_ratio", "分叉高度比", 0.60, 0.20, 0.88, None), ("crossbeam_ratio", "横梁高度比", 0.28, 0.08, 0.78, None), ("slenderness", "整体高宽比", 4.50, 1.50, 12.00, None), ("member_scale", "构件尺度系数", 1.00, 0.45, 2.20, None)] if bridge_type in {"pylon", "cable_stayed", "suspension"} else [("structural_depth_ratio", "结构高度比", 0.08, 0.02, 0.30, None), ("support_ratio", "支承位置比", 0.15, 0.02, 0.45, None), ("member_scale", "构件尺度系数", 1.00, 0.45, 2.20, None)]  # 定义桥型缺省变量。
    for key, name, default, lower, upper, unit in base_variables:  # 遍历缺省变量。
        if not any(item["id"] == f"design.variable.{key}" for item in variables):  # 检查变量是否已由文本指定。
            variables.append({"id": f"design.variable.{key}", "name": name, "category": "geometry", "dataType": "number", "unit": unit, "lower": lower, "upper": upper, "allowedValues": [], "defaultValue": default, "currentValue": default, "parameterPath": f"/extensions/bridgemind:designParameters/{key}", "dependencies": [], "active": True, "status": "needs_review"})  # 加入待审缺省变量。
    preferences = []  # 初始化偏好列表。
    if any(item["category"] == "aesthetic" for item in objectives):  # 检查是否存在造型目标。
        preferences.append({"id": "design.preference.aesthetic", "name": "造型偏好", "category": "aesthetic", "statement": "造型应与场景、文化和工程逻辑协调；具体偏好需由工程师交互确认。", "weight": next(item["weight"] for item in objectives if item["category"] == "aesthetic"), "source": "natural_language", "status": "needs_review"})  # 构造造型偏好。
    for position, item in enumerate(structured_input.get("preferences", []) if isinstance(structured_input.get("preferences"), list) else []):  # 遍历结构化设计偏好。
        if not isinstance(item, dict):  # 跳过非法偏好成员。
            continue  # 继续下一偏好。
        key = str(item.get("key") or item.get("name") or f"preference_{position + 1}")  # 读取偏好稳定键。
        preferences.append({"id": str(item.get("id") or f"design.preference.{_slug(key)}"), "name": str(item.get("name") or key), "category": str(item.get("category", "other")), "statement": str(item.get("statement") or key), "weight": _clamp(_number(item.get("weight"), 0.5)), "source": str(item.get("source", "structured_input")), "status": str(item.get("status", "needs_review"))})  # 构造结构化偏好对象。
    context_ids = {item.get("id") for item in process.get("contexts", []) if isinstance(item, dict)}  # 收集已有上下文 ID。
    if context["id"] not in context_ids:  # 检查上下文是否已存在。
        process["contexts"].append(context)  # 写入新上下文。
    requirement_ids = {item.get("id") for item in process.get("requirements", []) if isinstance(item, dict)}  # 收集已有要求 ID。
    if bridge_requirement["id"] not in requirement_ids:  # 检查桥型要求是否已存在。
        process["requirements"].append(bridge_requirement)  # 写入桥型要求。
    extra_requirements = []  # 初始化结构化补充要求列表。
    for position, item in enumerate(structured_input.get("requirements", []) if isinstance(structured_input.get("requirements"), list) else []):  # 遍历结构化补充要求。
        if not isinstance(item, dict):  # 跳过非法要求成员。
            continue  # 继续下一要求。
        key = str(item.get("key") or item.get("name") or f"requirement_{position + 1}")  # 读取要求稳定键。
        extra_requirements.append({"id": str(item.get("id") or f"design.requirement.{_slug(key)}"), "name": str(item.get("name") or key), "category": str(item.get("category", "other")), "statement": str(item.get("statement") or key), "priority": int(max(1, min(5, int(item.get("priority", 3))))), "mandatory": bool(item.get("mandatory", True)), "source": str(item.get("source", "structured_input")), "sourceRef": item.get("sourceRef"), "verificationMethod": str(item.get("verificationMethod", "人工或工程证据确认")), "status": str(item.get("status", "needs_review"))})  # 构造结构化补充要求。
    for item in extra_requirements:  # 遍历补充要求。
        existing_requirement = next((value for value in process.get("requirements", []) if isinstance(value, dict) and value.get("id") == item["id"]), None)  # 查找同 ID 要求。
        if existing_requirement is None:  # 检查是否首次出现。
            process["requirements"].append(item)  # 添加新要求。
        else:  # 处理已有要求。
            existing_requirement.update(item)  # 更新要求内容。
    for collection_name, incoming in [("objectives", objectives), ("constraints", constraints), ("preferences", preferences), ("variables", variables)]:  # 遍历可覆盖设计对象集合。
        existing = {item.get("id"): item for item in process.get(collection_name, []) if isinstance(item, dict)}  # 建立已有对象索引。
        for item in incoming:  # 遍历新对象。
            if item["id"] in existing:  # 检查是否需要更新已有对象。
                existing[item["id"]].update(item)  # 用最新编译结果更新对象。
            else:  # 处理首次出现对象。
                process[collection_name].append(item)  # 添加新对象。
    brief_payload = {"text": raw_text, "bridgeType": bridge_type, "objectives": [item["id"] for item in objectives], "constraints": [item["id"] for item in constraints]}  # 构造设计任务 ID 种子。
    brief_id = _stable_id("design.brief", brief_payload)  # 生成设计任务稳定 ID。
    brief = {"id": brief_id, "name": str(structured_input.get("briefName", f"{bridge_type} 多目标设计任务")), "rawText": raw_text, "contextRefs": [context["id"]], "requirementRefs": [bridge_requirement["id"], *[item["id"] for item in extra_requirements]], "objectiveRefs": [item["id"] for item in objectives], "constraintRefs": [item["id"] for item in constraints], "preferenceRefs": [item["id"] for item in preferences], "variableRefs": [item["id"] for item in variables], "intendedUse": str(structured_input.get("intendedUse", "生成式建模—计算—评价闭环的概念筛选与人机协同")), "status": "needs_review", "createdAt": utc_now(), "createdBy": actor, "confidence": type_confidence, "unresolved": ["目标权重需人工确认", "未提供的场地与规范条件不得由系统猜测", "代理评价不能替代有限元与工程审查"]}  # 构造设计任务。
    existing_briefs = {item.get("id"): item for item in process.get("briefs", []) if isinstance(item, dict)}  # 建立已有任务索引。
    if brief_id in existing_briefs:  # 检查是否重复编译同一任务。
        existing_briefs[brief_id].update(brief)  # 更新已有任务。
    else:  # 处理新任务。
        process["briefs"].append(brief)  # 添加新设计任务。
    process["activeBriefRef"] = brief_id  # 设置当前活动设计任务。
    process["status"] = "active"  # 标记设计过程已启动。
    feedback_id = _stable_id("feedback.design_intent", {"brief": brief_id, "time": brief["createdAt"]})  # 生成意图编译反馈 ID。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": "agent", "kind": "design_intent", "createdAt": brief["createdAt"], "createdBy": actor, "targetRefs": [brief_id], "before": None, "after": {"bridgeType": bridge_type, "objectiveRefs": brief["objectiveRefs"], "constraintRefs": brief["constraintRefs"]}, "metrics": {"confidence": type_confidence, "objectiveCount": len(objectives), "constraintCount": len(constraints), "variableCount": len(variables)}, "comment": "自然语言设计任务已编译为 BSDL 1.1 的目标、约束、偏好和变量对象。", "status": "recorded"})  # 保存意图编译反馈。
    report = {"briefId": brief_id, "bridgeType": bridge_type, "confidence": type_confidence, "objectiveCount": len(objectives), "constraintCount": len(constraints), "variableCount": len(variables), "requiresReview": True, "unresolved": brief["unresolved"]}  # 构造意图编译报告。
    return updated, report  # 返回更新文档和编译报告。


def _archetypes(bridge_type: str) -> list[tuple[str, str, float, float, float]]:  # 返回桥型对应的候选原型及先验系数。
    catalogue = {"pylon": [("inverted_y", "倒Y型桥塔", 0.84, 0.90, 0.78), ("portal_truss", "门式桁架桥塔", 0.92, 0.76, 0.61), ("diamond", "钻石型桥塔", 0.82, 0.94, 0.72), ("h_frame", "H型桥塔", 0.95, 0.68, 0.88)], "cable_stayed": [("fan", "扇形索面斜拉桥", 0.90, 0.82, 0.75), ("harp", "竖琴形索面斜拉桥", 0.84, 0.88, 0.72), ("semi_fan", "半扇形斜拉桥", 0.88, 0.86, 0.76), ("single_pylon", "独塔斜拉桥", 0.76, 0.94, 0.60)], "suspension": [("portal_pylon", "门式桥塔悬索桥", 0.92, 0.78, 0.80), ("diamond_pylon", "钻石桥塔悬索桥", 0.84, 0.94, 0.68), ("h_pylon", "H型桥塔悬索桥", 0.95, 0.70, 0.88), ("split_pylon", "分离式桥塔悬索桥", 0.82, 0.90, 0.66)], "arch": [("deck_arch", "上承式拱桥", 0.90, 0.84, 0.78), ("through_arch", "下承式拱桥", 0.88, 0.88, 0.72), ("tied_arch", "系杆拱桥", 0.92, 0.80, 0.76), ("network_arch", "网状吊杆拱桥", 0.86, 0.94, 0.58)], "beam": [("box_girder", "箱梁桥", 0.94, 0.72, 0.90), ("twin_girder", "双主梁桥", 0.90, 0.70, 0.94), ("truss_girder", "桁架梁桥", 0.88, 0.86, 0.66), ("hybrid_girder", "组合梁桥", 0.91, 0.80, 0.78)], "truss": [("warren", "华伦式桁架桥", 0.90, 0.80, 0.82), ("pratt", "普拉特桁架桥", 0.92, 0.76, 0.86), ("network", "网格桁架桥", 0.86, 0.92, 0.60), ("variable_depth", "变高度桁架桥", 0.88, 0.90, 0.68)], "generic_bridge": [("scheme_a", "候选方案A", 0.86, 0.80, 0.80), ("scheme_b", "候选方案B", 0.90, 0.72, 0.88), ("scheme_c", "候选方案C", 0.82, 0.92, 0.68), ("scheme_d", "候选方案D", 0.88, 0.84, 0.76)]}  # 定义候选原型目录。
    return catalogue.get(bridge_type, catalogue["generic_bridge"])  # 返回桥型原型或通用原型。


def _brief_by_id(process: dict[str, Any], brief_id: str | None) -> dict[str, Any]:  # 读取指定或活动设计任务。
    target = brief_id or process.get("activeBriefRef")  # 选择目标任务 ID。
    for brief in process.get("briefs", []):  # 遍历设计任务。
        if isinstance(brief, dict) and brief.get("id") == target:  # 检查任务 ID。
            return brief  # 返回目标设计任务。
    raise KeyError(f"设计任务不存在：{target}")  # 报告任务缺失。


def _variable_map(process: dict[str, Any], brief: dict[str, Any]) -> dict[str, dict[str, Any]]:  # 建立当前任务设计变量索引。
    allowed = set(brief.get("variableRefs", []))  # 读取任务变量引用。
    return {item["id"]: item for item in process.get("variables", []) if isinstance(item, dict) and item.get("id") in allowed}  # 返回任务变量字典。


def _hard_constraint_values(process: dict[str, Any], brief: dict[str, Any]) -> dict[str, Any]:  # 读取必须由所有候选保持的硬等式变量值。
    constraint_refs = set(brief.get("constraintRefs", []))  # 读取当前设计任务约束引用。
    fixed: dict[str, Any] = {}  # 初始化硬等式变量映射。
    for constraint in process.get("constraints", []):  # 遍历设计过程约束。
        if not isinstance(constraint, dict) or constraint.get("id") not in constraint_refs:  # 跳过其他任务或非法约束。
            continue  # 继续检查下一约束。
        if not bool(constraint.get("hard", True)) or constraint.get("operator") != "==":  # 只处理硬等式条件。
            continue  # 软约束和不等式保留给候选搜索与评价。
        variable_ref = constraint.get("expression")  # 读取约束绑定的设计变量引用。
        if isinstance(variable_ref, str) and variable_ref.startswith("design.variable."):  # 检查是否直接绑定设计变量。
            fixed[variable_ref] = deep_copy(constraint.get("limit"))  # 保存必须保持的目标值。
    return fixed  # 返回硬等式变量映射。


def _variable_value(variable: dict[str, Any], factor: float, position: int) -> Any:  # 为候选原型生成受边界约束的变量值。
    current = variable.get("currentValue", variable.get("defaultValue"))  # 读取当前或默认值。
    if variable.get("dataType") not in {"number", "integer"} or not isinstance(current, (int, float)):  # 检查是否为数值变量。
        allowed = variable.get("allowedValues", [])  # 读取离散候选值。
        return allowed[position % len(allowed)] if allowed else current  # 返回离散值或原值。
    lower = float(variable.get("lower")) if isinstance(variable.get("lower"), (int, float)) else float(current) * 0.5  # 读取下界。
    upper = float(variable.get("upper")) if isinstance(variable.get("upper"), (int, float)) else float(current) * 1.5  # 读取上界。
    shifted = float(current) * (0.88 + 0.08 * position + 0.06 * (factor - 0.8))  # 依据候选位置和先验系数生成扰动值。
    bounded = max(lower, min(upper, shifted))  # 把生成值约束到变量边界。
    return int(round(bounded)) if variable.get("dataType") == "integer" else round(bounded, 6)  # 返回匹配数据类型的值。


def _bounded_variable_value(variable: dict[str, Any], proposed: Any, fallback: Any) -> Any:  # 把经验或人工建议约束到当前变量定义。
    if variable.get("dataType") == "category":  # 检查类别变量。
        allowed = list(variable.get("allowedValues", []))  # 读取允许类别。
        return proposed if proposed in allowed else fallback  # 仅接受当前允许类别。
    if variable.get("dataType") == "boolean":  # 检查布尔变量。
        return bool(proposed) if isinstance(proposed, bool) else fallback  # 仅接受显式布尔值。
    parsed = _number(proposed, _number(fallback, 0.0))  # 把数值建议安全转换为有限数。
    lower = float(variable["lower"]) if isinstance(variable.get("lower"), (int, float)) else parsed  # 读取可选下界。
    upper = float(variable["upper"]) if isinstance(variable.get("upper"), (int, float)) else parsed  # 读取可选上界。
    bounded = max(lower, min(upper, parsed))  # 把建议值限制到当前变量边界。
    return int(round(bounded)) if variable.get("dataType") == "integer" else round(bounded, 6)  # 返回匹配数据类型的值。


def _skill_archetype(skill: dict[str, Any]) -> dict[str, Any] | None:  # 把 design_skill 模板转换为候选原型来源。
    body = skill.get("body", {}) if isinstance(skill.get("body"), dict) else {}  # 读取技能正文。
    action = body.get("recommendedAction", {}) if isinstance(body.get("recommendedAction"), dict) else {}  # 读取技能推荐动作。
    archetype = action.get("archetype")  # 读取技能原型。
    if not isinstance(archetype, str) or not archetype.strip():  # 检查技能是否提供可用原型。
        return None  # 缺少原型时不把模板用于候选生成。
    template_ref = f"{skill.get('templateId')}@{skill.get('version')}"  # 生成带版本的技能引用。
    return {"archetype": archetype, "name": str(skill.get("name") or archetype), "structuralFactor": 0.88, "aestheticFactor": 0.86, "constructabilityFactor": 0.82, "skillRef": template_ref, "variableValues": action.get("variableValues", {}) if isinstance(action.get("variableValues"), dict) else {}, "analysisTaskRefs": action.get("analysisTaskRefs", []) if isinstance(action.get("analysisTaskRefs"), list) else []}  # 返回技能候选来源。


def _match_design_skills(brief: dict[str, Any], bridge_type: str, skills: list[dict[str, Any]]) -> list[dict[str, Any]]:  # 按桥型和任务上下文筛选可迁移设计技能。
    matched = []  # 初始化匹配技能列表。
    for skill in skills:  # 遍历仓库中的设计技能模板。
        if not isinstance(skill, dict) or skill.get("kind") != "design_skill":  # 跳过非设计技能对象。
            continue  # 继续检查下一模板。
        body = skill.get("body", {}) if isinstance(skill.get("body"), dict) else {}  # 读取技能正文。
        applies = body.get("appliesWhen", {}) if isinstance(body.get("appliesWhen"), dict) else {}  # 读取技能适用条件。
        skill_bridge_type = applies.get("bridgeType")  # 读取技能桥型条件。
        if skill_bridge_type not in {None, "", bridge_type, "generic_bridge"}:  # 检查桥型是否兼容。
            continue  # 跳过明显不适用的技能。
        matched.append(skill)  # 保存可迁移技能。
    return sorted(matched, key=lambda item: (not bool(item.get("isDefault")), -int(item.get("version", 0)), str(item.get("templateId", ""))))  # 优先返回默认和较新技能版本。


def _candidate_model_patch(variables: dict[str, dict[str, Any]], values: dict[str, Any], candidate_id: str) -> list[dict[str, Any]]:  # 根据设计变量的 parameterPath 构造受控模型补丁。
    patches = []  # 初始化模型补丁列表。
    for variable_id, value in values.items():  # 遍历候选变量值。
        variable = variables.get(variable_id, {})  # 读取变量定义。
        path = str(variable.get("parameterPath", "")).strip()  # 读取变量绑定路径。
        if not path.startswith("/"):  # 检查 JSON Pointer 形式。
            continue  # 跳过未绑定到模型的变量。
        patches.append({"op": "add", "path": path, "value": deep_copy(value), "variableRef": variable_id})  # 保存带变量来源的受控补丁。
    patches.append({"op": "add", "path": "/extensions/bridgemind:activeCandidate", "value": candidate_id})  # 保存当前候选身份。
    return patches  # 返回候选模型补丁。


def generate_design_candidates(document: dict[str, Any], brief_id: str | None = None, count: int = 4, actor: str = "software.bridgemind.design", design_skills: list[dict[str, Any]] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:  # 为设计任务生成可审计候选方案并可读回人工固化技能。
    if count < 2 or count > 12:  # 检查候选数量范围。
        raise ValueError("候选数量必须在 2 到 12 之间。")  # 阻止无效候选预算。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    brief = _brief_by_id(process, brief_id)  # 读取目标设计任务。
    requirement_index = {item.get("id"): item for item in process.get("requirements", []) if isinstance(item, dict)}  # 建立要求索引。
    bridge_type = "generic_bridge"  # 初始化桥型。
    for requirement_ref in brief.get("requirementRefs", []):  # 遍历任务要求引用。
        statement = str(requirement_index.get(requirement_ref, {}).get("statement", ""))  # 读取要求陈述。
        match = re.search(r"类型为\s+([A-Za-z0-9_\-]+)", statement)  # 提取标准桥型标识。
        if match is not None:  # 检查是否命中桥型。
            bridge_type = match.group(1)  # 保存桥型。
            break  # 停止继续查找。
    variables = _variable_map(process, brief)  # 获取任务变量。
    fixed_values = _hard_constraint_values(process, brief)  # 读取必须由所有候选满足的硬等式条件。
    objective_refs = list(brief.get("objectiveRefs", []))  # 读取任务目标引用。
    constraint_refs = list(brief.get("constraintRefs", []))  # 读取任务约束引用。
    plan_payload = {"brief": brief["id"], "objectives": objective_refs, "constraints": constraint_refs}  # 构造评价计划 ID 种子。
    plan_id = _stable_id("design.evaluation_plan", plan_payload)  # 生成评价计划 ID。
    plans = {item.get("id"): item for item in process.get("evaluationPlans", []) if isinstance(item, dict)}  # 建立评价计划索引。
    plan = {"id": plan_id, "name": f"{brief['name']} 多目标筛选计划", "briefRef": brief["id"], "objectiveRefs": objective_refs, "constraintRefs": constraint_refs, "method": "screening_surrogate_then_engineering_verification", "normalization": "higher_is_better_0_to_1", "decisionPolicy": "hard_constraints_first_then_pareto_then_human_approval", "status": "active"}  # 构造评价计划。
    if plan_id in plans:  # 检查评价计划是否已存在。
        plans[plan_id].update(plan)  # 更新评价计划。
    else:  # 处理新评价计划。
        process["evaluationPlans"].append(plan)  # 添加评价计划。
    iteration = _begin_design_iteration(process, brief, plan_id, actor)  # 创建本轮建模—计算—评价—反馈迭代。
    iteration_id = str(iteration["id"])  # 读取本轮迭代 ID。
    archetypes = _archetypes(bridge_type)  # 获取桥型候选原型。
    matched_skills = _match_design_skills(brief, bridge_type, design_skills or [])  # 检索与当前桥型和任务相符的人工固化技能。
    skill_archetypes = [_skill_archetype(skill) for skill in matched_skills]  # 把技能转换为候选原型。
    skill_archetypes = [item for item in skill_archetypes if item is not None]  # 移除缺少推荐原型的技能。
    candidate_sources = skill_archetypes + [{"archetype": item[0], "name": item[1], "structuralFactor": item[2], "aestheticFactor": item[3], "constructabilityFactor": item[4], "skillRef": None, "variableValues": {}} for item in archetypes]  # 把经验候选置于通用原型候选之前。
    if not candidate_sources:  # 检查桥型原型和技能是否均为空。
        raise RuntimeError(f"桥型 {bridge_type} 没有可用候选原型或设计技能。")  # 阻止无来源候选生成。
    selected_sources = [candidate_sources[index % len(candidate_sources)] for index in range(count)]  # 按候选预算选择原型和技能来源。
    existing_candidates = {item.get("id"): item for item in process.get("candidates", []) if isinstance(item, dict)}  # 建立已有候选索引。
    generated_ids: list[str] = []  # 初始化本次候选 ID 列表。
    used_skill_refs: list[str] = []  # 初始化本次使用的技能引用列表。
    for position, source in enumerate(selected_sources):  # 遍历候选来源。
        archetype = str(source["archetype"])  # 读取候选原型标识。
        name = str(source["name"])  # 读取候选显示名称。
        structural_factor = float(source["structuralFactor"])  # 读取结构性能先验系数。
        aesthetic_factor = float(source["aestheticFactor"])  # 读取造型质量先验系数。
        constructability_factor = float(source["constructabilityFactor"])  # 读取可建造性先验系数。
        variable_values = {variable_id: _variable_value(variable, structural_factor, position) for variable_id, variable in variables.items()}  # 生成受边界约束的变量值。
        skill_values = source.get("variableValues", {}) if isinstance(source.get("variableValues"), dict) else {}  # 读取人工固化技能中的变量建议。
        for variable_id, proposed_value in skill_values.items():  # 遍历技能变量建议。
            if variable_id in variables:  # 只接受当前设计任务已声明的变量。
                variable_values[variable_id] = _bounded_variable_value(variables[variable_id], proposed_value, variable_values[variable_id])  # 把技能值约束到当前变量边界。
        for variable_id, fixed_value in fixed_values.items():  # 遍历硬等式变量。
            if variable_id in variables:  # 检查当前任务是否声明该变量。
                variable_values[variable_id] = _bounded_variable_value(variables[variable_id], fixed_value, variable_values.get(variable_id))  # 让所有候选满足不可违反的明确条件。
        payload = {"brief": brief["id"], "iteration": iteration_id, "archetype": archetype, "position": position, "variables": variable_values, "skillRef": source.get("skillRef")}  # 构造候选 ID 种子并隔离不同设计迭代。
        candidate_id = _stable_id("design.candidate", payload)  # 生成候选稳定 ID。
        generated_ids.append(candidate_id)  # 记录候选 ID。
        model_patch = _candidate_model_patch(variables, variable_values, candidate_id)  # 根据变量绑定生成受控模型补丁。
        skill_ref = source.get("skillRef")  # 读取候选采用的技能引用。
        if isinstance(skill_ref, str) and skill_ref not in used_skill_refs:  # 检查技能引用是否有效且尚未记录。
            used_skill_refs.append(skill_ref)  # 保存本次实际使用的技能引用。
        candidate = {"id": candidate_id, "name": name, "briefRef": brief["id"], "iterationRef": iteration_id, "parentRef": None, "archetype": archetype, "generationMethod": "human_skill_guided_parameter_sweep" if skill_ref else "deterministic_archetype_parameter_sweep", "createdAt": utc_now(), "createdBy": actor, "variableValues": variable_values, "modelRevision": int(updated.get("revision", {}).get("number", 1)), "modelPatch": model_patch, "componentRefs": [], "analysisTaskRefs": list(source.get("analysisTaskRefs", [])) if isinstance(source.get("analysisTaskRefs"), list) else [], "evaluationResultRefs": [], "modelArtifactRefs": [], "resultArtifactRefs": [], "engineeringMetrics": {}, "status": "generated", "confidence": 0.82 if skill_ref else 0.75, "provenance": {"bridgeType": bridge_type, "structuralFactor": structural_factor, "aestheticFactor": aesthetic_factor, "constructabilityFactor": constructability_factor, "designSkillRef": skill_ref if isinstance(skill_ref, str) else None, "skillRefs": [skill_ref] if skill_ref else [], "skillTransferRequiresReview": bool(skill_ref), "generativeLoop": list(GENERATION_LOOP)}, "limitations": ["候选仅为概念筛选对象", "尚未经过真实三维几何生成、网格、有限元或规范验算", "跨项目技能迁移默认需要人工确认"]}  # 构造绑定本轮迭代的候选方案。
        if candidate_id in existing_candidates:  # 检查候选是否已存在。
            existing_candidates[candidate_id].update(candidate)  # 更新已有候选。
        else:  # 处理新候选。
            process["candidates"].append(candidate)  # 添加候选方案。
    iteration["candidateRefs"] = list(generated_ids)  # 把本轮候选引用写入设计迭代。
    modeling_stage = _stage_record(iteration, "modeling")  # 读取本轮建模阶段记录。
    modeling_stage["metrics"].update({"candidateCount": len(generated_ids), "skillReadbackCount": len(used_skill_refs)})  # 保存候选和技能读回规模。
    modeling_stage["methodNames"] = list(dict.fromkeys([*modeling_stage.get("methodNames", []), "deterministic_candidate_modeling", *(["design_skill_readback"] if used_skill_refs else [])]))  # 记录本轮建模方法。
    iteration["nextAction"] = "materialize_candidate_models"  # 明确下一步为候选模型物化。
    process["status"] = "active"  # 保持设计过程活动状态。
    feedback_id = _stable_id("feedback.candidate_generation", {"brief": brief["id"], "iteration": iteration_id, "candidates": generated_ids})  # 生成候选生成反馈 ID。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": "agent", "kind": "candidate_generation", "createdAt": utc_now(), "createdBy": actor, "targetRefs": generated_ids, "before": None, "after": {"candidateIds": generated_ids, "evaluationPlanId": plan_id, "iterationId": iteration_id}, "metrics": {"candidateCount": len(generated_ids), "designSkillCount": len(used_skill_refs)}, "comment": "基于设计任务、变量边界、桥型原型和可用人工技能生成概念候选；尚未宣称工程可行。", "status": "recorded"})  # 保存候选生成反馈。
    iteration["feedbackRefs"] = list(dict.fromkeys([*iteration.get("feedbackRefs", []), feedback_id]))  # 把候选生成反馈绑定到本轮迭代。
    return updated, {"briefId": brief["id"], "bridgeType": bridge_type, "iterationId": iteration_id, "candidateIds": generated_ids, "evaluationPlanId": plan_id, "candidateCount": len(generated_ids), "designSkillRefs": used_skill_refs, "skillGuided": bool(used_skill_refs)}  # 返回更新文档、技能读回和生成报告。

def _number(value: Any, default: float) -> float:  # 把候选变量安全转换为有限浮点数。
    try:  # 捕获非法数值。
        parsed = float(value)  # 转换数值。
        return parsed if math.isfinite(parsed) else default  # 返回有限值或回退值。
    except (TypeError, ValueError):  # 处理无法转换值。
        return default  # 返回默认值。


def _candidate_scores(candidate: dict[str, Any]) -> dict[str, float]:  # 计算透明且非权威的概念筛选指标。
    values = candidate.get("variableValues", {}) if isinstance(candidate.get("variableValues"), dict) else {}  # 读取候选变量。
    provenance = candidate.get("provenance", {}) if isinstance(candidate.get("provenance"), dict) else {}  # 读取原型先验。
    volume = _number(values.get("design.variable.volume_fraction"), 0.30)  # 读取材料体积分数。
    slenderness = _number(values.get("design.variable.slenderness"), 4.00)  # 读取整体高宽比。
    bifurcation = _number(values.get("design.variable.bifurcation_ratio"), 0.60)  # 读取分叉高度比。
    crossbeam = _number(values.get("design.variable.crossbeam_ratio"), 0.25)  # 读取横梁高度比。
    depth_ratio = _number(values.get("design.variable.structural_depth_ratio"), 0.08)  # 读取结构高度比。
    structural_prior = _number(provenance.get("structuralFactor"), 0.85)  # 读取结构先验系数。
    aesthetic_prior = _number(provenance.get("aestheticFactor"), 0.80)  # 读取造型先验系数。
    construct_prior = _number(provenance.get("constructabilityFactor"), 0.75)  # 读取建造先验系数。
    material_efficiency = _clamp(1.0 - abs(volume - 0.28) / 0.35)  # 计算材料用量合理性代理分数。
    proportion_score = _clamp(1.0 - abs(slenderness - 4.5) / 7.0)  # 计算整体比例代理分数。
    bifurcation_score = _clamp(1.0 - abs(bifurcation - 0.60) / 0.55)  # 计算分叉比例代理分数。
    crossbeam_score = _clamp(1.0 - abs(crossbeam - 0.28) / 0.45)  # 计算横梁位置代理分数。
    depth_score = _clamp(1.0 - abs(depth_ratio - 0.09) / 0.20)  # 计算梁桥结构高度代理分数。
    structural = _clamp(0.50 * structural_prior + 0.25 * material_efficiency + 0.15 * proportion_score + 0.10 * max(bifurcation_score, depth_score))  # 计算结构性能筛选分数。
    aesthetic = _clamp(0.55 * aesthetic_prior + 0.20 * proportion_score + 0.15 * bifurcation_score + 0.10 * crossbeam_score)  # 计算造型质量筛选分数。
    cost = _clamp(0.45 * material_efficiency + 0.35 * construct_prior + 0.20 * (1.0 - abs(crossbeam - 0.25)))  # 计算经济性筛选分数。
    carbon = _clamp(0.70 * material_efficiency + 0.30 * construct_prior)  # 计算低碳筛选分数。
    constructability = _clamp(0.75 * construct_prior + 0.25 * crossbeam_score)  # 计算可建造性筛选分数。
    durability = _clamp(0.55 * structural + 0.45 * constructability)  # 计算耐久性筛选分数。
    return {"structural_performance": structural, "aesthetic_quality": aesthetic, "cost_efficiency": cost, "carbon_efficiency": carbon, "constructability": constructability, "durability": durability}  # 返回统一高值优指标。


def _constraint_pass(constraint: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:  # 对候选执行显式硬约束检查。
    expression = str(constraint.get("expression", ""))  # 读取约束变量引用。
    values = candidate.get("variableValues", {}) if isinstance(candidate.get("variableValues"), dict) else {}  # 读取候选变量值。
    actual = values.get(expression)  # 获取约束变量值。
    limit = constraint.get("limit")  # 读取约束限值。
    operator = str(constraint.get("operator", "=="))  # 读取约束运算符。
    tolerance = abs(_number(constraint.get("tolerance"), 0.0))  # 读取容差。
    passed = False  # 初始化约束结果。
    margin = None  # 初始化约束裕度。
    if isinstance(actual, (int, float)) and isinstance(limit, (int, float)):  # 检查数值约束。
        actual_number = float(actual)  # 转换实际值。
        limit_number = float(limit)  # 转换限值。
        if operator == "<=":  # 处理上限约束。
            passed = actual_number <= limit_number + tolerance  # 计算上限通过状态。
            margin = limit_number - actual_number  # 计算上限裕度。
        elif operator == ">=":  # 处理下限约束。
            passed = actual_number >= limit_number - tolerance  # 计算下限通过状态。
            margin = actual_number - limit_number  # 计算下限裕度。
        elif operator == "==":  # 处理等值约束。
            passed = abs(actual_number - limit_number) <= tolerance  # 计算等值通过状态。
            margin = tolerance - abs(actual_number - limit_number)  # 计算等值裕度。
        elif operator == "!=":  # 处理不等约束。
            passed = abs(actual_number - limit_number) > tolerance  # 计算不等通过状态。
            margin = abs(actual_number - limit_number) - tolerance  # 计算不等裕度。
    elif operator == "in" and isinstance(limit, list):  # 处理集合约束。
        passed = actual in limit  # 检查实际值是否在允许集合。
    return {"constraintRef": constraint.get("id"), "passed": bool(passed), "value": actual, "limit": limit, "unit": constraint.get("unit"), "margin": margin, "source": "candidate_variable_check", "evidenceRefs": [], "verificationStatus": "screening", "message": "概念候选变量检查；进入工程阶段后仍需几何、有限元或规范证据。"}  # 返回仅用于代理筛选的约束检查对象。


def _dominates(left: dict[str, Any], right: dict[str, Any]) -> bool:  # 判断一个可行候选是否 Pareto 支配另一个候选。
    left_values = [float(item.get("normalizedValue", 0.0)) for item in left.get("objectiveValues", [])]  # 读取左候选归一目标。
    right_values = [float(item.get("normalizedValue", 0.0)) for item in right.get("objectiveValues", [])]  # 读取右候选归一目标。
    return len(left_values) == len(right_values) and all(a >= b - 1.0e-12 for a, b in zip(left_values, right_values)) and any(a > b + 1.0e-12 for a, b in zip(left_values, right_values))  # 返回支配判定。


def _assign_pareto_ranks(results: list[dict[str, Any]]) -> None:  # 对评价结果执行确定性非支配分层。
    remaining = [item for item in results if item.get("feasible")]  # 选择可行候选。
    rank = 1  # 初始化 Pareto 层级。
    while remaining:  # 循环处理尚未分层候选。
        front = [item for item in remaining if not any(_dominates(other, item) for other in remaining if other is not item)]  # 找到当前非支配前沿。
        if not front:  # 防止异常浮点关系导致空前沿。
            front = [remaining[0]]  # 强制取一个候选保证终止。
        for item in front:  # 遍历当前前沿。
            item["paretoRank"] = rank  # 写入 Pareto 层级。
        remaining = [item for item in remaining if item not in front]  # 移除已分层候选。
        rank += 1  # 进入下一层。
    for item in results:  # 遍历全部结果。
        if not item.get("feasible"):  # 检查不可行候选。
            item["paretoRank"] = 999  # 把不可行候选置于最后层。


def evaluate_design_candidates(document: dict[str, Any], brief_id: str | None = None, candidate_ids: list[str] | None = None, actor: str = "software.bridgemind.design") -> tuple[dict[str, Any], dict[str, Any]]:  # 对候选执行透明多目标筛选与 Pareto 排序。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    brief = _brief_by_id(process, brief_id)  # 读取目标设计任务。
    objectives = {item.get("id"): item for item in process.get("objectives", []) if isinstance(item, dict)}  # 建立目标索引。
    constraints = {item.get("id"): item for item in process.get("constraints", []) if isinstance(item, dict)}  # 建立约束索引。
    plan = next((item for item in process.get("evaluationPlans", []) if isinstance(item, dict) and item.get("briefRef") == brief["id"] and item.get("status") == "active"), None)  # 查找活动评价计划。
    if plan is None:  # 检查评价计划是否存在。
        raise RuntimeError("当前设计任务缺少活动 evaluationPlan；请先生成候选。")  # 阻止无评价契约运行。
    selected_ids = set(candidate_ids or [item.get("id") for item in process.get("candidates", []) if isinstance(item, dict) and item.get("briefRef") == brief["id"]])  # 确定待评价候选集合。
    candidates = [item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") in selected_ids]  # 读取候选对象。
    if not candidates:  # 检查是否有候选。
        raise RuntimeError("当前设计任务没有可评价候选。")  # 阻止空评价。
    new_results = []  # 初始化新评价结果列表。
    for candidate in candidates:  # 遍历候选方案。
        score_map = _candidate_scores(candidate)  # 计算概念筛选指标。
        objective_values = []  # 初始化目标值列表。
        weighted_score = 0.0  # 初始化加权总分。
        for objective_ref in plan.get("objectiveRefs", []):  # 遍历评价目标。
            objective = objectives.get(objective_ref)  # 读取目标对象。
            if objective is None:  # 跳过非法引用且交由验证器报告。
                continue  # 继续下一目标。
            metric = str(objective.get("metric", objective_ref.split(".")[-1]))  # 读取目标指标键。
            raw = _clamp(score_map.get(metric, 0.50))  # 读取统一高值优筛选分数。
            normalised = raw if objective.get("direction") != "minimize" else 1.0 - raw  # 转换为统一高值优值。
            weight = max(0.0, float(objective.get("weight", 0.0)))  # 读取目标权重。
            weighted_score += weight * normalised  # 累加加权得分。
            objective_values.append({"objectiveRef": objective_ref, "rawValue": round(raw, 6), "normalizedValue": round(normalised, 6), "unit": objective.get("unit"), "direction": objective.get("direction"), "source": "deterministic_screening_surrogate", "evidenceRefs": [], "confidence": 0.55, "verificationStatus": "screening"})  # 保存明确标注为代理筛选的目标评价值。
        checks = [_constraint_pass(constraints[constraint_ref], candidate) for constraint_ref in plan.get("constraintRefs", []) if constraint_ref in constraints]  # 执行全部约束检查。
        feasible = all(item["passed"] for item in checks if constraints.get(item["constraintRef"], {}).get("hard", True))  # 判断硬约束可行性。
        result_payload = {"candidate": candidate["id"], "plan": plan["id"], "values": objective_values, "checks": checks}  # 构造评价结果 ID 种子。
        result_id = _stable_id("design.evaluation", result_payload)  # 生成评价结果 ID。
        result = {"id": result_id, "name": f"{candidate['name']} 概念筛选评价", "candidateRef": candidate["id"], "iterationRef": candidate["iterationRef"], "planRef": plan["id"], "createdAt": utc_now(), "createdBy": actor, "objectiveValues": objective_values, "constraintChecks": checks, "feasible": feasible, "aggregateScore": round(weighted_score, 6), "paretoRank": None, "evidenceLevel": "screening_surrogate", "evidenceRefs": [], "status": "needs_engineering_verification", "verificationCoverage": 0.0, "verifiedObjectiveRefs": [], "unverifiedObjectiveRefs": list(plan.get("objectiveRefs", [])), "verifiedConstraintRefs": [], "unverifiedConstraintRefs": list(plan.get("constraintRefs", [])), "limitations": ["本结果为透明确定性代理筛选，不是有限元结果", "造型分数不是公众或专家审美真值", "进入方案决策前必须补充几何、FEA、规范与人工评审证据"]}  # 构造零工程验证覆盖率的筛选评价结果。
        new_results.append(result)  # 添加新评价结果。
    _assign_pareto_ranks(new_results)  # 计算 Pareto 层级。
    result_index = {item.get("id"): item for item in process.get("evaluationResults", []) if isinstance(item, dict)}  # 建立已有评价索引。
    candidate_index = {item.get("id"): item for item in process.get("candidates", []) if isinstance(item, dict)}  # 建立候选索引。
    for result in new_results:  # 遍历新评价结果。
        if result["id"] in result_index:  # 检查结果是否已存在。
            result_index[result["id"]].update(result)  # 更新已有结果。
        else:  # 处理新结果。
            process["evaluationResults"].append(result)  # 添加评价结果。
        candidate = candidate_index[result["candidateRef"]]  # 读取对应候选。
        refs = list(candidate.get("evaluationResultRefs", []))  # 复制候选评价引用。
        if result["id"] not in refs:  # 检查引用是否重复。
            refs.append(result["id"])  # 添加评价结果引用。
        candidate["evaluationResultRefs"] = refs  # 写回评价引用。
        candidate["status"] = "evaluated" if result["feasible"] else "infeasible"  # 更新候选状态。
        iteration = _iteration_by_id(process, candidate.get("iterationRef"))  # 查找候选所属设计迭代。
        if iteration is not None and result["id"] not in iteration.get("evaluationResultRefs", []):  # 检查筛选评价是否尚未绑定到迭代。
            iteration.setdefault("evaluationResultRefs", []).append(result["id"])  # 把筛选评价绑定到本轮迭代。
    best = sorted(new_results, key=lambda item: (item["paretoRank"], -float(item["aggregateScore"]), item["candidateRef"]))[0]  # 选出仅供提示的当前最优筛选结果。
    feedback_id = _stable_id("feedback.candidate_evaluation", {"brief": brief["id"], "results": [item["id"] for item in new_results]})  # 生成评价反馈 ID。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": "agent", "kind": "candidate_evaluation", "createdAt": utc_now(), "createdBy": actor, "targetRefs": [item["candidateRef"] for item in new_results], "before": None, "after": {"evaluationResultRefs": [item["id"] for item in new_results], "screeningBestCandidateRef": best["candidateRef"]}, "metrics": {"evaluatedCount": len(new_results), "feasibleCount": sum(1 for item in new_results if item["feasible"]), "paretoFrontCount": sum(1 for item in new_results if item["paretoRank"] == 1)}, "comment": "完成概念候选的代理筛选和 Pareto 排序；结果必须由工程计算与人工评审升级证据等级。", "status": "recorded"})  # 保存评价反馈。
    summary = [{"candidateRef": item["candidateRef"], "feasible": item["feasible"], "aggregateScore": item["aggregateScore"], "paretoRank": item["paretoRank"]} for item in sorted(new_results, key=lambda value: (value["paretoRank"], -float(value["aggregateScore"])))]  # 构造排序摘要。
    return updated, {"briefId": brief["id"], "evaluationPlanId": plan["id"], "results": summary, "screeningBestCandidateRef": best["candidateRef"], "requiresEngineeringVerification": True}  # 返回更新文档和评价报告。


def _decode_pointer_token(token: str) -> str:  # 解码 RFC 6901 JSON Pointer 标记。
    return token.replace("~1", "/").replace("~0", "~")  # 按标准顺序恢复斜杠和波浪号。


def _safe_patch_prefix(path: str) -> bool:  # 判断设计补丁是否只修改允许的工程对象或扩展字段。
    allowed = ("/extensions/", "/components/", "/materials/", "/sections/", "/shellSections/", "/solidSections/", "/connections/", "/loads/", "/loadCases/", "/analysisTasks/", "/constructionStages/")  # 定义允许的模型状态前缀。
    denied = ("/revision", "/project", "/agents", "/feedback", "/designProcess", "/artifacts", "/resultSets", "/conversionReports")  # 定义禁止候选补丁修改的治理和证据对象。
    return path.startswith(allowed) and not path.startswith(denied)  # 返回安全前缀判定。


def _apply_json_pointer_patch(document: dict[str, Any], operation: dict[str, Any]) -> tuple[bool, str]:  # 对工作文档执行一个受控 add 或 replace 补丁。
    op = str(operation.get("op", ""))  # 读取补丁操作。
    path = str(operation.get("path", ""))  # 读取补丁路径。
    if op not in {"add", "replace"}:  # 检查允许的补丁操作。
        return False, f"不允许的补丁操作：{op}"  # 拒绝删除、移动、复制和测试等操作。
    if not path.startswith("/") or not _safe_patch_prefix(path):  # 检查路径形式和安全范围。
        return False, f"不允许的补丁路径：{path}"  # 拒绝越过模型状态边界的补丁。
    tokens = [_decode_pointer_token(token) for token in path.split("/")[1:]]  # 解析 JSON Pointer 路径段。
    if not tokens:  # 检查是否尝试替换根文档。
        return False, "不允许替换根文档。"  # 拒绝根级补丁。
    current: Any = document  # 从根文档开始定位父对象。
    for token in tokens[:-1]:  # 遍历目标父路径。
        if isinstance(current, dict):  # 处理对象节点。
            if token not in current:  # 检查中间对象是否缺失。
                if op == "add":  # 允许 add 操作创建字典父节点。
                    current[token] = {}  # 创建缺失的对象父节点。
                else:  # 处理 replace 操作缺失父节点。
                    return False, f"replace 路径不存在：{path}"  # 拒绝替换不存在路径。
            current = current[token]  # 进入下一对象节点。
        elif isinstance(current, list):  # 处理数组节点。
            if not token.isdigit() or int(token) >= len(current):  # 检查数组索引合法性。
                return False, f"数组索引不存在：{path}"  # 拒绝非法数组路径。
            current = current[int(token)]  # 进入数组成员。
        else:  # 处理标量中间节点。
            return False, f"补丁父路径不是容器：{path}"  # 拒绝穿越标量值。
    final = tokens[-1]  # 读取目标末段。
    value = deep_copy(operation.get("value"))  # 深复制补丁值避免共享引用。
    if isinstance(current, dict):  # 处理对象目标。
        if op == "replace" and final not in current:  # 检查 replace 目标是否存在。
            return False, f"replace 目标不存在：{path}"  # 拒绝不存在目标。
        current[final] = value  # 写入对象字段。
        return True, "applied"  # 返回应用成功。
    if isinstance(current, list):  # 处理数组目标。
        if final == "-" and op == "add":  # 检查数组尾部追加语法。
            current.append(value)  # 追加数组成员。
            return True, "applied"  # 返回应用成功。
        if not final.isdigit():  # 检查数组索引格式。
            return False, f"数组目标索引非法：{path}"  # 拒绝非整数索引。
        index = int(final)  # 转换数组索引。
        if op == "add" and index == len(current):  # 支持在数组尾部按索引添加。
            current.append(value)  # 追加数组成员。
            return True, "applied"  # 返回应用成功。
        if index >= len(current):  # 检查已有数组目标范围。
            return False, f"数组目标不存在：{path}"  # 拒绝越界索引。
        current[index] = value  # 替换数组成员。
        return True, "applied"  # 返回应用成功。
    return False, f"补丁目标父节点不是容器：{path}"  # 拒绝标量父节点。


def materialize_design_candidate(document: dict[str, Any], candidate_id: str, actor: str = "software.bridgemind.design", human_approval: bool = False) -> tuple[dict[str, Any], dict[str, Any]]:  # 把候选变量、参数化几何和预览分析契约写入实际 BSDL 模型状态。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    candidate = next((item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 查找目标候选。
    if candidate is None:  # 检查候选是否存在。
        raise KeyError(f"候选方案不存在：{candidate_id}")  # 报告候选缺失。
    updated, generation_report = materialize_candidate_geometry(updated, candidate, actor)  # 通过确定性参数化生成器建立真实结构语义和可求解预览模型。
    process = ensure_design_process(updated)  # 重新获取生成后的设计过程容器。
    candidate = next((item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 重新绑定生成后的候选对象。
    if candidate is None:  # 检查生成过程是否意外丢失候选。
        raise RuntimeError(f"参数化生成后候选方案丢失：{candidate_id}")  # 阻止不一致状态继续执行。
    applied = []  # 初始化成功补丁列表。
    blocked = []  # 初始化阻断补丁列表。
    component_refs = set(generation_report.get("componentRefs", []))  # 读取参数化生成器产生的构件引用。
    components = updated.get("components", []) if isinstance(updated.get("components"), list) else []  # 读取构件集合。
    for operation in candidate.get("modelPatch", []):  # 遍历候选模型补丁。
        if not isinstance(operation, dict):  # 跳过非法补丁成员。
            blocked.append({"operation": operation, "reason": "补丁必须为对象"})  # 记录非法补丁。
            continue  # 继续下一补丁。
        success, reason = _apply_json_pointer_patch(updated, operation)  # 执行受控模型补丁。
        record = {"op": operation.get("op"), "path": operation.get("path"), "variableRef": operation.get("variableRef"), "reason": reason}  # 构造补丁审计记录。
        if success:  # 检查补丁是否成功。
            applied.append(record)  # 保存成功补丁。
            match = re.match(r"^/components/(\d+)/", str(operation.get("path", "")))  # 检查补丁是否作用于构件。
            if match is not None and int(match.group(1)) < len(components):  # 检查构件索引有效性。
                component = components[int(match.group(1))]  # 读取被修改构件。
                if isinstance(component, dict) and isinstance(component.get("id"), str):  # 检查构件身份。
                    component_refs.add(component["id"])  # 保存被修改构件引用。
        else:  # 处理被阻断补丁。
            blocked.append(record)  # 保存阻断补丁。
    if not applied and not component_refs:  # 检查参数与几何是否均未进入模型状态。
        raise RuntimeError({"message": "候选没有任何可安全物化的参数补丁或结构构件。", "blocked": blocked})  # 阻止伪造物化成功。
    candidate["componentRefs"] = sorted(component_refs)  # 更新候选影响构件引用。
    task_refs = list(candidate.get("analysisTaskRefs", []))  # 复制已有分析任务引用。
    generated_task_ref = generation_report.get("analysisTaskRef")  # 读取生成器创建的预览任务。
    if isinstance(generated_task_ref, str) and generated_task_ref not in task_refs:  # 检查预览任务引用是否尚未写入。
        task_refs.append(generated_task_ref)  # 绑定候选与预览分析任务。
    candidate["analysisTaskRefs"] = task_refs  # 写回分析任务引用。
    model_artifact_id = _stable_id("artifact.design_model", {"candidate": candidate_id, "modelHash": generation_report.get("modelHash")})  # 生成候选模型产物 ID。
    model_artifact = {"id": model_artifact_id, "kind": "design_model", "uri": f"bridgemind://design/{candidate_id}/model", "format": "BSDL-1.1-semantic-model", "hash": generation_report.get("modelHash"), "createdAt": utc_now()}  # 构造可追溯候选模型产物。
    artifact_index = {item.get("id"): item for item in updated.setdefault("artifacts", []) if isinstance(item, dict)}  # 建立现有产物索引。
    if model_artifact_id in artifact_index:  # 检查相同模型产物是否已存在。
        artifact_index[model_artifact_id].update(model_artifact)  # 更新已有模型产物。
    else:  # 处理首次物化的模型产物。
        updated["artifacts"].append(model_artifact)  # 保存候选模型产物。
    model_artifact_refs = list(candidate.get("modelArtifactRefs", []))  # 复制候选模型产物引用。
    if model_artifact_id not in model_artifact_refs:  # 检查模型产物引用是否重复。
        model_artifact_refs.append(model_artifact_id)  # 添加候选模型产物引用。
    candidate["modelArtifactRefs"] = model_artifact_refs  # 写回候选模型产物引用。
    candidate["engineeringMetrics"] = deep_copy(generation_report.get("engineeringMetrics", {}))  # 保存透明几何和资源代理指标。
    candidate["status"] = "materialized"  # 标记候选已进入当前工作模型。
    candidate.setdefault("provenance", {})["materialization"] = {"revision": int(updated.get("revision", {}).get("number", 1)), "actor": actor, "humanApproval": bool(human_approval), "applied": deep_copy(applied), "blocked": deep_copy(blocked), "semanticOnly": False, "modelArtifactRef": model_artifact_id, "generator": deep_copy(generation_report)}  # 保存候选物化来源、生成器与适用边界。
    candidate["limitations"] = [item for item in candidate.get("limitations", []) if item != "尚未经过真实三维几何生成、网格、有限元或规范验算"] + ["当前参数化结构与内置线弹性求解仅用于生成式闭环预览，不构成工程放行", "高保真几何、工业网格、规范与试验仍需独立验证"]  # 更新候选能力边界。
    feedback_id = _stable_id("feedback.candidate_materialization", {"candidate": candidate_id, "generated": generation_report, "applied": applied, "time": utc_now()})  # 生成候选物化反馈 ID。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": "human" if human_approval else "agent", "kind": "design_modeling", "createdAt": utc_now(), "createdBy": actor, "targetRefs": [candidate.get("iterationRef"), candidate_id, model_artifact_id, *sorted(component_refs)], "before": None, "after": {"candidateStatus": "materialized", "modelArtifactRef": model_artifact_id, "generatedKind": generation_report.get("generatedKind"), "analysisTaskRef": generated_task_ref, "appliedPatches": applied}, "metrics": {"appliedPatchCount": len(applied), "blockedPatchCount": len(blocked), "affectedComponentCount": len(component_refs), "humanApproval": bool(human_approval)}, "comment": "候选已完成确定性建模并进入 BSDL 结构语义，下一步由真实数值计算生成性能证据；当前预览不构成工程放行。", "status": "accepted" if human_approval else "recorded"})  # 保存候选建模反馈事件。
    iteration = refresh_design_iteration(process, str(candidate.get("iterationRef")), actor)  # 根据本轮候选建模覆盖刷新设计迭代。
    modeling_stage = _stage_record(iteration, "modeling")  # 读取建模阶段记录。
    modeling_stage["artifactRefs"] = list(dict.fromkeys([*modeling_stage.get("artifactRefs", []), model_artifact_id]))  # 把候选模型产物加入建模阶段。
    modeling_stage["methodNames"] = list(dict.fromkeys([*modeling_stage.get("methodNames", []), str(generation_report.get("generatedKind", "deterministic_parametric_modeling"))]))  # 记录实际候选建模方法。
    return updated, {"candidateId": candidate_id, "iterationId": candidate.get("iterationRef"), "modelArtifactId": model_artifact_id, "applied": applied, "blocked": blocked, "componentRefs": sorted(component_refs), "engineeringMetrics": candidate.get("engineeringMetrics", {}), "semanticOnly": False, "generation": generation_report, "iterationStatus": iteration.get("status"), "nextAction": iteration.get("nextAction"), "requiresEngineeringVerification": True}  # 返回物化文档和审计报告。


def _known_evidence_refs(document: dict[str, Any]) -> set[str]:  # 收集文档内可追溯的工程证据对象和运行引用。
    refs: set[str] = set()  # 初始化证据引用集合。
    for key in ("artifacts", "resultSets", "codeCheckResults", "feedback", "finiteElementModels", "conversionReports"):  # 遍历允许作为证据来源的对象族。
        for item in document.get(key, []):  # 遍历当前对象族成员。
            if isinstance(item, dict) and isinstance(item.get("id"), str):  # 检查对象是否具有稳定 ID。
                refs.add(item["id"])  # 保存对象稳定 ID。
            if key == "resultSets" and isinstance(item, dict) and isinstance(item.get("runRef"), str):  # 检查结果集是否绑定求解运行。
                refs.add(item["runRef"])  # 允许以真实运行记录作为证据引用。
    return refs  # 返回可验证证据引用集合。


def record_design_evidence(document: dict[str, Any], candidate_id: str, objective_values: list[dict[str, Any]], constraint_checks: list[dict[str, Any]], evidence_level: str, evidence_refs: list[str], actor: str = "software.bridgemind.design") -> tuple[dict[str, Any], dict[str, Any]]:  # 把真实计算、规范、试验或人工证据写入候选评价并量化验证覆盖率。
    allowed_levels = {"analytical", "finite_element", "code_check", "experimental", "monitoring", "human_review", "combined"}  # 定义可升级工程证据等级。
    allowed_verification_statuses = {"screening", "verified", "unresolved"}  # 定义单目标和单约束的证据覆盖状态。
    if evidence_level not in allowed_levels:  # 检查证据等级。
        raise ValueError(f"evidenceLevel 必须属于 {sorted(allowed_levels)}。")  # 阻止代理筛选冒充工程证据。
    if not evidence_refs:  # 检查总证据引用是否存在。
        raise ValueError("工程证据评价必须提供至少一个 evidenceRef。")  # 阻止无来源评价升级。
    known_evidence_refs = _known_evidence_refs(document)  # 收集当前文档内全部可追溯证据对象。
    unknown_evidence_refs = sorted(set(evidence_refs) - known_evidence_refs)  # 检查总证据引用是否指向现有对象。
    if unknown_evidence_refs:  # 检查是否存在悬空总证据引用。
        raise ValueError({"message": "工程证据引用必须指向现有 artifact、resultSet、codeCheckResult、feedback、FE model、conversionReport 或 runRef。", "unknownEvidenceRefs": unknown_evidence_refs})  # 阻止无实体来源的证据升级。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    candidate = next((item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 查找目标候选。
    if candidate is None:  # 检查候选是否存在。
        raise KeyError(f"候选方案不存在：{candidate_id}")  # 报告候选缺失。
    plan = next((item for item in process.get("evaluationPlans", []) if isinstance(item, dict) and item.get("briefRef") == candidate.get("briefRef") and item.get("status") == "active"), None)  # 查找候选活动评价计划。
    if plan is None:  # 检查评价计划是否存在。
        raise RuntimeError("候选缺少活动 evaluationPlan。")  # 阻止无评价契约写入证据。
    objectives = {item.get("id"): item for item in process.get("objectives", []) if isinstance(item, dict)}  # 建立目标索引。
    constraints = {item.get("id"): item for item in process.get("constraints", []) if isinstance(item, dict)}  # 建立约束索引。
    provided_objective_refs = [item.get("objectiveRef") for item in objective_values if isinstance(item, dict)]  # 收集调用方提供的目标引用。
    required_objective_refs = list(plan.get("objectiveRefs", []))  # 读取评价计划要求的全部目标。
    missing_objective_refs = sorted(set(required_objective_refs) - set(provided_objective_refs))  # 查找未评价目标。
    if missing_objective_refs or len(provided_objective_refs) != len(set(provided_objective_refs)):  # 检查目标覆盖和重复情况。
        raise ValueError({"message": "工程证据必须且只能对每个活动目标提供一条 objectiveValue。", "missingObjectiveRefs": missing_objective_refs, "providedObjectiveRefs": provided_objective_refs})  # 阻止不完整多目标评价。
    required_constraint_refs = [constraint_ref for constraint_ref in plan.get("constraintRefs", []) if constraints.get(constraint_ref, {}).get("hard", True)]  # 读取必须由工程证据覆盖的硬约束。
    provided_constraint_refs = [item.get("constraintRef") for item in constraint_checks if isinstance(item, dict)]  # 收集调用方提供的约束引用。
    missing_constraint_refs = sorted(set(required_constraint_refs) - set(provided_constraint_refs))  # 查找未检查硬约束。
    if missing_constraint_refs or len(provided_constraint_refs) != len(set(provided_constraint_refs)):  # 检查硬约束覆盖和重复情况。
        raise ValueError({"message": "工程证据必须且只能对每个硬约束提供一条 constraintCheck。", "missingConstraintRefs": missing_constraint_refs, "providedConstraintRefs": provided_constraint_refs})  # 阻止缺失硬约束的伪可行结论。
    normalized_objectives: list[dict[str, Any]] = []  # 初始化规范化目标值。
    verified_objective_refs: list[str] = []  # 初始化已有真实工程证据的目标引用。
    unverified_objective_refs: list[str] = []  # 初始化仍为筛选或未解决的目标引用。
    aggregate = 0.0  # 初始化全部目标加权总分。
    verified_weight = 0.0  # 初始化获得工程验证的目标权重。
    total_weight = sum(max(0.0, float(objectives.get(reference, {}).get("weight", 0.0))) for reference in required_objective_refs)  # 计算活动目标总权重。
    for value in objective_values:  # 遍历调用方提供的目标值。
        if not isinstance(value, dict) or value.get("objectiveRef") not in objectives:  # 检查目标引用。
            raise ValueError(f"未知 objectiveRef：{value.get('objectiveRef') if isinstance(value, dict) else value}")  # 阻止悬空目标证据。
        objective = objectives[value["objectiveRef"]]  # 读取目标定义。
        if not isinstance(value.get("rawValue"), (int, float)) or not isinstance(value.get("normalizedValue"), (int, float)):  # 检查目标值是否显式提供数值。
            raise ValueError(f"objectiveValue {value['objectiveRef']} 必须显式提供 rawValue 和 normalizedValue 数值。")  # 阻止空模板冒充评价结果。
        verification_status = str(value.get("verificationStatus", "verified"))  # 读取单目标证据覆盖状态并让显式外部证据默认已验证。
        if verification_status not in allowed_verification_statuses:  # 检查单目标证据状态枚举。
            raise ValueError(f"objectiveValue {value['objectiveRef']} 的 verificationStatus 必须属于 {sorted(allowed_verification_statuses)}。")  # 阻止未知覆盖状态。
        item_evidence_refs = list(value.get("evidenceRefs", evidence_refs if verification_status == "verified" else []))  # 读取单目标证据引用并仅为已验证值回退到总证据。
        unknown_item_refs = sorted(set(item_evidence_refs) - known_evidence_refs)  # 检查单目标证据引用。
        if unknown_item_refs:  # 检查是否存在悬空单目标证据引用。
            raise ValueError({"message": f"objectiveValue {value['objectiveRef']} 含悬空 evidenceRefs。", "unknownEvidenceRefs": unknown_item_refs})  # 阻止单目标无实体证据。
        if verification_status == "verified" and not item_evidence_refs:  # 检查已验证目标是否有直接证据。
            raise ValueError(f"objectiveValue {value['objectiveRef']} 标记 verified 时必须提供 evidenceRefs。")  # 阻止只靠标签升级目标。
        source_text = str(value.get("source", evidence_level))  # 读取目标值来源用于证据等级守门。
        source_lower = source_text.lower()  # 生成小写来源以执行稳定关键字检查。
        if verification_status == "verified" and any(token in source_lower for token in ("screening_surrogate", "unresolved", "placeholder", "proxy_only")):  # 检查代理筛选或占位值是否被伪装为已验证目标。
            raise ValueError(f"objectiveValue {value['objectiveRef']} 的 verified 状态不能使用筛选、未解决或占位来源：{source_text}")  # 阻止代理分数冒充工程证据。
        normalized = _clamp(_number(value.get("normalizedValue"), 0.0))  # 读取统一高值优归一值。
        confidence_default = 0.90 if verification_status == "verified" else (0.55 if verification_status == "screening" else 0.20)  # 根据证据覆盖状态设置透明置信度默认值。
        item = {"objectiveRef": value["objectiveRef"], "rawValue": _number(value.get("rawValue"), normalized), "normalizedValue": normalized, "unit": value.get("unit", objective.get("unit")), "direction": value.get("direction", objective.get("direction")), "source": source_text, "evidenceRefs": item_evidence_refs, "confidence": _clamp(_number(value.get("confidence"), confidence_default)), "verificationStatus": verification_status}  # 构造规范化目标证据。
        normalized_objectives.append(item)  # 保存目标证据。
        weight = max(0.0, float(objective.get("weight", 0.0)))  # 读取目标权重。
        aggregate += weight * normalized  # 累加目标权重分数。
        if verification_status == "verified":  # 检查当前目标是否获得真实工程证据。
            verified_objective_refs.append(value["objectiveRef"])  # 记录已验证目标。
            verified_weight += weight  # 累加已验证目标权重。
        else:  # 处理筛选或未解决目标。
            unverified_objective_refs.append(value["objectiveRef"])  # 记录未完整验证目标。
    normalized_checks: list[dict[str, Any]] = []  # 初始化规范化约束检查。
    verified_constraint_refs: list[str] = []  # 初始化已有真实工程证据的约束引用。
    unverified_constraint_refs: list[str] = []  # 初始化仍为筛选或未解决的约束引用。
    for check in constraint_checks:  # 遍历调用方提供的约束证据。
        if not isinstance(check, dict) or check.get("constraintRef") not in constraints:  # 检查约束引用。
            raise ValueError(f"未知 constraintRef：{check.get('constraintRef') if isinstance(check, dict) else check}")  # 阻止悬空约束证据。
        constraint = constraints[check["constraintRef"]]  # 读取约束定义。
        if not isinstance(check.get("passed"), bool):  # 检查约束结论是否由调用方明确给出。
            raise ValueError(f"constraintCheck {check['constraintRef']} 必须显式提供布尔 passed。")  # 阻止空模板被隐式转换为失败或通过。
        verification_status = str(check.get("verificationStatus", "verified"))  # 读取单约束证据覆盖状态并让显式外部证据默认已验证。
        if verification_status not in allowed_verification_statuses:  # 检查单约束证据状态枚举。
            raise ValueError(f"constraintCheck {check['constraintRef']} 的 verificationStatus 必须属于 {sorted(allowed_verification_statuses)}。")  # 阻止未知覆盖状态。
        item_evidence_refs = list(check.get("evidenceRefs", evidence_refs if verification_status == "verified" else []))  # 读取单约束证据引用并仅为已验证值回退到总证据。
        unknown_item_refs = sorted(set(item_evidence_refs) - known_evidence_refs)  # 检查单约束证据引用。
        if unknown_item_refs:  # 检查是否存在悬空单约束证据引用。
            raise ValueError({"message": f"constraintCheck {check['constraintRef']} 含悬空 evidenceRefs。", "unknownEvidenceRefs": unknown_item_refs})  # 阻止单约束无实体证据。
        if verification_status == "verified" and not item_evidence_refs:  # 检查已验证约束是否有直接证据。
            raise ValueError(f"constraintCheck {check['constraintRef']} 标记 verified 时必须提供 evidenceRefs。")  # 阻止只靠标签升级约束。
        source_text = str(check.get("source", evidence_level))  # 读取约束检查来源用于证据等级守门。
        source_lower = source_text.lower()  # 生成小写来源以执行稳定关键字检查。
        if verification_status == "verified" and any(token in source_lower for token in ("screening_surrogate", "unresolved", "placeholder", "proxy_only")):  # 检查筛选或占位约束是否被伪装为已验证。
            raise ValueError(f"constraintCheck {check['constraintRef']} 的 verified 状态不能使用筛选、未解决或占位来源：{source_text}")  # 阻止代理约束结论冒充工程证据。
        normalized_checks.append({"constraintRef": check["constraintRef"], "passed": check["passed"], "value": check.get("value"), "limit": check.get("limit", constraint.get("limit")), "unit": check.get("unit", constraint.get("unit")), "margin": check.get("margin"), "source": source_text, "evidenceRefs": item_evidence_refs, "verificationStatus": verification_status, "message": str(check.get("message", "由外部工程证据写入。"))})  # 保存约束证据和覆盖状态。
        if verification_status == "verified":  # 检查当前约束是否获得真实工程证据。
            verified_constraint_refs.append(check["constraintRef"])  # 记录已验证约束。
        else:  # 处理筛选或未解决约束。
            unverified_constraint_refs.append(check["constraintRef"])  # 记录未完整验证约束。
    objective_coverage = verified_weight / total_weight if total_weight > 0.0 else 1.0  # 按目标权重计算工程验证覆盖率。
    hard_constraint_coverage = len(set(verified_constraint_refs) & set(required_constraint_refs)) / len(required_constraint_refs) if required_constraint_refs else 1.0  # 计算硬约束工程验证覆盖率。
    verification_coverage = (objective_coverage + hard_constraint_coverage) * 0.5 if required_constraint_refs else objective_coverage  # 合成目标和硬约束验证覆盖率。
    fully_verified = not unverified_objective_refs and not (set(required_constraint_refs) - set(verified_constraint_refs))  # 判断全部活动目标和硬约束是否获得工程证据。
    feasible = all(item["passed"] for item in normalized_checks if constraints[item["constraintRef"]].get("hard", True))  # 根据当前全部硬约束结论计算暂定可行性。
    result_status = "verified" if fully_verified else "partially_verified"  # 根据覆盖率区分完整与部分工程评价。
    payload = {"candidate": candidate_id, "plan": plan["id"], "level": evidence_level, "objectiveValues": normalized_objectives, "constraintChecks": normalized_checks, "evidenceRefs": evidence_refs, "status": result_status}  # 构造证据评价 ID 种子。
    result_id = _stable_id("design.evaluation", payload)  # 生成工程评价结果 ID。
    limitations = ["证据适用范围由其原始任务、工况、网格、规范或试验条件限定", "最终工程批准仍属于责任工程师"]  # 初始化工程评价通用边界。
    if not fully_verified:  # 检查是否存在尚未工程验证的目标或约束。
        limitations.append("部分目标或约束仍来自代理筛选或待补证据，当前结果只能用于候选比较，不能用于最终选定")  # 明确部分验证结果不能放行。
    result = {"id": result_id, "name": f"{candidate.get('name', candidate_id)} 工程证据评价", "candidateRef": candidate_id, "iterationRef": candidate["iterationRef"], "planRef": plan["id"], "createdAt": utc_now(), "createdBy": actor, "objectiveValues": normalized_objectives, "constraintChecks": normalized_checks, "feasible": feasible, "aggregateScore": round(aggregate, 6), "paretoRank": 1, "evidenceLevel": evidence_level, "evidenceRefs": list(evidence_refs), "status": result_status, "verificationCoverage": round(_clamp(verification_coverage), 6), "verifiedObjectiveRefs": sorted(verified_objective_refs), "unverifiedObjectiveRefs": sorted(unverified_objective_refs), "verifiedConstraintRefs": sorted(verified_constraint_refs), "unverifiedConstraintRefs": sorted(set(required_constraint_refs) - set(verified_constraint_refs)), "limitations": limitations}  # 构造带验证覆盖率的工程证据评价结果。
    existing = {item.get("id"): item for item in process.get("evaluationResults", []) if isinstance(item, dict)}  # 建立已有评价结果索引。
    if result_id in existing:  # 检查结果是否已存在。
        existing[result_id].update(result)  # 更新重复结果。
    else:  # 处理新证据结果。
        process["evaluationResults"].append(result)  # 添加工程证据评价。
    refs = list(candidate.get("evaluationResultRefs", []))  # 复制候选评价引用。
    if result_id not in refs:  # 检查结果引用是否重复。
        refs.append(result_id)  # 添加工程评价引用。
    candidate["evaluationResultRefs"] = refs  # 写回候选评价引用。
    artifact_ids = {item.get("id") for item in updated.get("artifacts", []) if isinstance(item, dict) and isinstance(item.get("id"), str)}  # 收集真实文件产物 ID。
    result_artifact_refs = list(candidate.get("resultArtifactRefs", []))  # 复制候选结果产物引用。
    for evidence_ref in evidence_refs:  # 遍历工程评价证据引用。
        if evidence_ref in artifact_ids and evidence_ref not in result_artifact_refs:  # 检查证据是否为尚未绑定的文件产物。
            result_artifact_refs.append(evidence_ref)  # 把真实结果文件绑定到候选。
    candidate["resultArtifactRefs"] = result_artifact_refs  # 写回候选结果产物引用。
    candidate["status"] = "evaluated" if result_status == "verified" and feasible else ("partially_evaluated" if feasible else "infeasible")  # 根据工程覆盖率和硬约束更新候选状态。
    peer_results = [item for item in process.get("evaluationResults", []) if isinstance(item, dict) and item.get("planRef") == plan["id"] and item.get("status") in {"verified", "partially_verified"}]  # 收集同计划的完整或部分工程结果。
    _assign_pareto_ranks(peer_results)  # 更新同计划工程候选的 Pareto 层级。
    feedback_id = _stable_id("feedback.engineering_evidence", {"result": result_id, "time": result["createdAt"]})  # 生成工程证据反馈 ID。
    feedback_source = "fea" if evidence_level in {"finite_element", "combined"} else "validator"  # 根据证据等级选择反馈来源主体。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": feedback_source, "kind": "design_computation" if evidence_level in {"finite_element", "analytical", "combined"} else "engineering_evidence", "createdAt": result["createdAt"], "createdBy": actor, "targetRefs": [candidate.get("iterationRef"), candidate_id, result_id, *evidence_refs], "before": None, "after": {"evaluationResultRef": result_id, "feasible": feasible, "aggregateScore": result["aggregateScore"], "verificationCoverage": result["verificationCoverage"], "status": result_status}, "metrics": {"objectiveCount": len(normalized_objectives), "constraintCount": len(normalized_checks), "evidenceCount": len(evidence_refs), "verifiedObjectiveCount": len(verified_objective_refs), "verifiedConstraintCount": len(verified_constraint_refs)}, "comment": "候选计算与评价已绑定外部工程证据；只有全部活动目标和硬约束完成验证后才能进入人工最终选定。", "status": "recorded"})  # 保存计算和评价证据反馈事件。
    iteration = _iteration_by_id(process, candidate.get("iterationRef"))  # 查找候选所属设计迭代。
    if iteration is not None:  # 检查迭代是否存在。
        if result_id not in iteration.get("evaluationResultRefs", []):  # 检查工程评价是否尚未绑定本轮。
            iteration.setdefault("evaluationResultRefs", []).append(result_id)  # 把工程评价绑定到设计迭代。
        computation_stage = _stage_record(iteration, "computation")  # 读取计算阶段记录。
        computation_stage["evidenceRefs"] = list(dict.fromkeys([*computation_stage.get("evidenceRefs", []), *evidence_refs]))  # 保存计算证据引用。
        computation_stage["artifactRefs"] = list(dict.fromkeys([*computation_stage.get("artifactRefs", []), *result_artifact_refs]))  # 保存求解结果文件引用。
        computation_stage["methodNames"] = list(dict.fromkeys([*computation_stage.get("methodNames", []), evidence_level]))  # 记录实际计算或验证方法。
        evaluation_stage = _stage_record(iteration, "evaluation")  # 读取评价阶段记录。
        evaluation_stage["evidenceRefs"] = list(dict.fromkeys([*evaluation_stage.get("evidenceRefs", []), result_id, *evidence_refs]))  # 保存多目标评价及其证据。
        refresh_design_iteration(process, str(candidate.get("iterationRef")), actor)  # 刷新本轮建模、计算和评价覆盖状态。
    return updated, {"candidateId": candidate_id, "iterationId": candidate.get("iterationRef"), "evaluationResultId": result_id, "evidenceLevel": evidence_level, "status": result_status, "feasible": feasible, "aggregateScore": result["aggregateScore"], "paretoRank": result["paretoRank"], "verificationCoverage": result["verificationCoverage"], "verifiedObjectiveRefs": result["verifiedObjectiveRefs"], "unverifiedObjectiveRefs": result["unverifiedObjectiveRefs"], "verifiedConstraintRefs": result["verifiedConstraintRefs"], "unverifiedConstraintRefs": result["unverifiedConstraintRefs"], "resultArtifactRefs": result_artifact_refs, "evidenceRefs": evidence_refs}  # 返回工程证据写入和覆盖率报告。




def apply_design_feedback(document: dict[str, Any], candidate_id: str, decision: str, comment: str, actor: str = "human.web", variable_changes: dict[str, Any] | None = None, evidence_refs: list[str] | None = None, human_approval: bool = True) -> tuple[dict[str, Any], dict[str, Any]]:  # 把人工选择或修订写回设计过程。
    if decision not in {"selected", "rejected", "revise", "pending"}:  # 检查决策枚举。
        raise ValueError("decision 必须为 selected、rejected、revise 或 pending。")  # 阻止非法决策。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    candidate = next((item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 查找候选方案。
    if candidate is None:  # 检查候选存在性。
        raise KeyError(f"候选方案不存在：{candidate_id}")  # 报告候选缺失。
    before = deep_copy(candidate)  # 保存修改前候选状态。
    iteration_ref = str(candidate.get("iterationRef"))  # 读取候选所属设计迭代。
    iteration = _iteration_by_id(process, iteration_ref)  # 查找候选所属设计迭代对象。
    if iteration is None:  # 检查候选是否具有有效迭代引用。
        raise RuntimeError(f"候选 {candidate_id} 缺少有效 designIteration。")  # 阻断无法追踪的人机反馈。
    if decision == "selected":  # 检查最终选择的工程证据门槛。
        result_index = {item.get("id"): item for item in process.get("evaluationResults", []) if isinstance(item, dict)}  # 建立候选评价结果索引。
        verified = [result_index.get(ref) for ref in candidate.get("evaluationResultRefs", []) if isinstance(result_index.get(ref), dict) and result_index[ref].get("status") == "verified" and result_index[ref].get("evidenceLevel") != "screening_surrogate" and result_index[ref].get("evidenceRefs")]  # 筛选完整且可追溯的工程评价。
        if not verified:  # 检查是否达到最终选择证据门槛。
            raise RuntimeError("selected 候选必须先具有 verified 非代理工程评价和可追溯 evidenceRefs。")  # 阻止概念筛选或局部预览直接放行。
    if isinstance(variable_changes, dict):  # 检查是否提交变量修改。
        candidate.setdefault("variableValues", {}).update(variable_changes)  # 写入人工变量修改。
    candidate["status"] = decision  # 更新候选状态。
    brief_ref = str(candidate.get("briefRef"))  # 读取设计任务引用。
    peer_ids = [item.get("id") for item in process.get("candidates", []) if isinstance(item, dict) and item.get("iterationRef") == iteration_ref]  # 收集同一设计迭代候选 ID。
    decision_payload = {"brief": brief_ref, "candidate": candidate_id, "decision": decision, "comment": comment, "revision": updated.get("revision", {}).get("number")}  # 构造决策 ID 种子。
    decision_id = _stable_id("design.decision", decision_payload)  # 生成决策记录 ID。
    decision_record = {"id": decision_id, "name": f"{candidate.get('name', candidate_id)} 人工决策", "briefRef": brief_ref, "iterationRef": iteration_ref, "candidateRefs": peer_ids, "selectedCandidateRef": candidate_id if decision == "selected" else None, "decision": decision, "reason": comment, "createdAt": utc_now(), "createdBy": actor, "evidenceRefs": list(evidence_refs or []), "humanApproval": bool(human_approval), "status": "approved" if human_approval and decision in {"selected", "rejected", "revise"} else "working"}  # 构造绑定本轮迭代的人工决策记录。
    process["decisions"].append(decision_record)  # 保存决策记录。
    if decision == "selected":  # 检查是否选定候选。
        for peer in process.get("candidates", []):  # 遍历同任务候选。
            if isinstance(peer, dict) and peer.get("iterationRef") == iteration_ref and peer.get("id") != candidate_id and peer.get("status") not in {"rejected", "infeasible"}:  # 选择本轮尚未明确拒绝的其他候选。
                peer["status"] = "not_selected"  # 标记其他候选未被选择。
    feedback_id = _stable_id("feedback.candidate_selection", {"decision": decision_id, "time": decision_record["createdAt"]})  # 生成反馈 ID。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": "human", "kind": "design_feedback", "createdAt": decision_record["createdAt"], "createdBy": actor, "targetRefs": [iteration_ref, candidate_id, decision_id], "before": before, "after": deep_copy(candidate), "metrics": {"humanApproval": bool(human_approval), "changedVariableCount": len(variable_changes or {})}, "comment": comment, "status": "accepted" if human_approval else "recorded"})  # 保存本轮人机设计反馈事件。
    if feedback_id not in iteration.get("feedbackRefs", []):  # 检查反馈事件是否尚未绑定到迭代。
        iteration.setdefault("feedbackRefs", []).append(feedback_id)  # 把人工反馈绑定到本轮迭代。
    feedback_stage = _stage_record(iteration, "feedback")  # 读取反馈阶段记录。
    feedback_stage["evidenceRefs"] = list(dict.fromkeys([*feedback_stage.get("evidenceRefs", []), *list(evidence_refs or [])]))  # 保存人工决策证据。
    feedback_stage["methodNames"] = list(dict.fromkeys([*feedback_stage.get("methodNames", []), "human_review", "design_feedback"]))  # 记录人机反馈方法。
    refreshed = refresh_design_iteration(process, iteration_ref, actor)  # 根据人工决策刷新本轮完成状态。
    return updated, {"decisionId": decision_id, "iterationId": iteration_ref, "candidateId": candidate_id, "decision": decision, "humanApproval": bool(human_approval), "iterationStatus": refreshed.get("status"), "nextAction": refreshed.get("nextAction")}  # 返回更新文档和反馈报告。


def build_design_skill(document: dict[str, Any], decision_id: str, actor: str = "software.bridgemind.design") -> tuple[dict[str, Any], dict[str, Any]]:  # 从人工批准决策提炼可版本化设计技能。
    updated = _prepare_document(document, actor)  # 升级文档并登记设计操作主体。
    process = ensure_design_process(updated)  # 获取设计过程容器。
    decision = next((item for item in process.get("decisions", []) if isinstance(item, dict) and item.get("id") == decision_id), None)  # 查找决策记录。
    if decision is None:  # 检查决策存在性。
        raise KeyError(f"设计决策不存在：{decision_id}")  # 报告决策缺失。
    if not decision.get("humanApproval"):  # 检查是否经过人工批准。
        raise RuntimeError("只有经过人工批准的设计决策才能固化为技能。")  # 阻止自动结果直接进入默认知识。
    candidate_id = decision.get("selectedCandidateRef")  # 读取选定候选 ID。
    if not candidate_id:  # 检查是否存在选定候选。
        raise RuntimeError("当前决策没有 selectedCandidateRef，不能固化为设计技能。")  # 阻止无动作技能。
    candidate = next((item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 查找选定候选。
    if candidate is None:  # 检查候选存在性。
        raise KeyError(f"选定候选不存在：{candidate_id}")  # 报告候选缺失。
    brief = _brief_by_id(process, str(decision.get("briefRef")))  # 读取关联设计任务。
    evaluation_refs = list(candidate.get("evaluationResultRefs", []))  # 读取候选评价证据引用。
    evaluation_index = {item.get("id"): item for item in process.get("evaluationResults", []) if isinstance(item, dict)}  # 建立评价结果索引。
    verified_refs = [ref for ref in evaluation_refs if isinstance(evaluation_index.get(ref), dict) and evaluation_index[ref].get("status") == "verified" and evaluation_index[ref].get("evidenceLevel") != "screening_surrogate" and evaluation_index[ref].get("evidenceRefs")]  # 筛选具有可追溯工程证据的评价。
    if not verified_refs:  # 检查是否存在可固化工程证据。
        raise RuntimeError("只有关联 verified 工程评价的人工批准候选才能固化为设计技能。")  # 阻止把代理筛选或无来源判断写入动态知识库。
    skill_payload = {"brief": brief["id"], "archetype": candidate.get("archetype"), "variables": candidate.get("variableValues", {}), "decision": decision_id, "verifiedEvaluationRefs": verified_refs}  # 构造技能 ID 种子。
    template_id = _stable_id("template.design_skill", skill_payload)  # 生成技能模板 ID。
    iteration_ref = str(candidate.get("iterationRef"))  # 读取产生该技能的设计迭代引用。
    iteration = _iteration_by_id(process, iteration_ref)  # 读取产生该技能的完整建模—计算—评价—反馈迭代。
    body = {"kind": "design_skill", "semanticVersion": "2.0.0", "generativeLoop": list(GENERATION_LOOP), "appliesWhen": {"briefName": brief.get("name"), "requirementRefs": brief.get("requirementRefs", []), "objectiveRefs": brief.get("objectiveRefs", []), "constraintRefs": brief.get("constraintRefs", []), "contextRefs": brief.get("contextRefs", []), "bridgeType": candidate.get("provenance", {}).get("bridgeType")}, "recommendedAction": {"archetype": candidate.get("archetype"), "variableValues": candidate.get("variableValues", {}), "modelPatch": candidate.get("modelPatch", []), "engineeringMetrics": candidate.get("engineeringMetrics", {})}, "evidence": {"iterationRef": iteration_ref, "iterationStatus": iteration.get("status") if isinstance(iteration, dict) else None, "decisionRef": decision_id, "evaluationResultRefs": evaluation_refs, "verifiedEvaluationResultRefs": verified_refs, "modelArtifactRefs": candidate.get("modelArtifactRefs", []), "resultArtifactRefs": candidate.get("resultArtifactRefs", []), "humanApproval": True}, "guardrails": ["仅在上下文、桥型、目标和约束相近时检索", "Skill 只能引导下一轮 modeling，不能替代 computation 与 evaluation", "代理筛选必须升级为工程计算、规范、试验或人工证据", "任何跨项目迁移默认 needs_review", "最终方案仍需责任工程师批准"], "createdBy": actor, "createdAt": utc_now()}  # 构造携带设计目标、完整迭代和证据链的设计技能正文。
    if template_id not in updated.setdefault("experienceRefs", []):  # 检查经验引用是否已存在。
        updated["experienceRefs"].append(template_id)  # 写入技能引用。
    feedback_id = _stable_id("feedback.skill_solidification", {"template": template_id, "decision": decision_id})  # 生成技能固化反馈 ID。
    updated.setdefault("feedback", []).append({"id": feedback_id, "source": "agent", "kind": "skill_solidification", "createdAt": body["createdAt"], "createdBy": actor, "targetRefs": [decision_id, candidate_id], "before": None, "after": {"templateId": template_id}, "metrics": {"evaluationEvidenceCount": len(evaluation_refs)}, "comment": "把人工批准候选、变量和评价引用提炼为待版本化 design_skill；默认不得绕过人工审查。", "status": "recorded"})  # 保存技能固化反馈。
    return updated, {"templateId": template_id, "name": f"{candidate.get('name', candidate_id)} 设计技能", "kind": "design_skill", "body": body, "makeDefault": False}  # 返回更新文档和可保存模板。


def run_design_loop(document: dict[str, Any], raw_text: str, candidate_count: int = 4, actor: str = "software.bridgemind.design", structured: dict[str, Any] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:  # 一次运行意图编译、候选生成和代理筛选闭环。
    compiled, intent_report = compile_design_intent(document, raw_text, actor, structured)  # 编译设计意图。
    generated, generation_report = generate_design_candidates(compiled, intent_report["briefId"], candidate_count, actor, None)  # 生成候选方案。
    evaluated, evaluation_report = evaluate_design_candidates(generated, intent_report["briefId"], generation_report["candidateIds"], actor)  # 执行多目标代理筛选。
    process = ensure_design_process(evaluated)  # 读取已生成候选的设计过程。
    iteration = _iteration_by_id(process, generation_report.get("iterationId"))  # 读取本轮生成式设计迭代。
    return evaluated, {"intent": intent_report, "generation": generation_report, "evaluation": evaluation_report, "iterationId": generation_report.get("iterationId"), "generativeLoop": list(GENERATION_LOOP), "stageRecords": deep_copy(iteration.get("stageRecords", [])) if isinstance(iteration, dict) else [], "authoritative": False, "nextRequiredAction": "依次物化所有候选、运行真实计算与工程评价，然后由责任工程师反馈并决定是否进入下一轮建模。"}  # 返回闭环文档、阶段状态和总报告。
