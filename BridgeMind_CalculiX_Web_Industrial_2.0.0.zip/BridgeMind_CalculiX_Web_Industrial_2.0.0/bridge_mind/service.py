"""BridgeMind CalculiX Web 的项目、版本、导出、执行、反馈与经验编排。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
import shutil  # 提供文件复制与阶段包归档能力。
import zipfile  # 提供 CalculiX 阶段包 ZIP 归档。
from pathlib import Path  # 提供项目和输出路径处理。
from typing import Any  # 提供通用 JSON 类型注解。
from .adapters.calculix import detect_calculix, export_calculix, run_calculix  # 导入 CalculiX 专用链路。
from .adapters.gmsh import export_gmsh  # 导入 Gmsh GEO 导出器。
from .cognition.orchestrator import propose_strategy  # 导入多专家策略编排器。
from .code_checks.engine import run_code_check_plan  # 导入可审计规范验算引擎。
from .design.engine import apply_design_feedback, build_design_skill, compile_design_intent, evaluate_design_candidates, generate_design_candidates, materialize_design_candidate, record_design_evidence, run_design_loop  # 导入 BridgeMind 2.0 生成式设计、模型物化、工程证据与反馈闭环。
from .design.model import GENERATION_LOOP  # 复用唯一合法的建模—计算—评价—反馈阶段定义。
from .experience import extract_experiences  # 导入修订经验提取器。
from .memory import apply_memory  # 导入跨项目经验读回与策略投影器。
from .fea.frame3d import FrameSolveError, solve_document  # 导入非权威空间梁预览求解器。
from .importers.ifc import import_ifc  # 导入 IFC 4.3 映射器。
from .importers.point_cloud import build_bsdl_from_point_cloud  # 导入点云到 BSDL 转换器。
from .repository import Repository  # 导入 SQLite 持久化仓库。
from .utils import content_hash, deep_copy, load_json, save_json, utc_now  # 复用哈希、文档和时间工具。
from .validator import validate_document  # 导入完整 BSDL 验证器。


class BridgeMindService:  # 封装项目、策略、求解、反馈、审计和经验业务流程。
    def __init__(self, root: str | Path, database_path: str | Path | None = None, runs_directory: str | Path | None = None) -> None:  # 初始化服务和可配置持久化目录。
        self.root = Path(root).resolve()  # 规范化项目根目录。
        self.runs_directory = Path(runs_directory).expanduser().resolve() if runs_directory is not None else self.root / "runs"  # 解析部署环境或本地默认运行目录。
        self.runs_directory.mkdir(parents=True, exist_ok=True)  # 确保运行目录存在。
        self.repository = Repository(database_path or self.root / "data" / "bridgemind.sqlite3")  # 初始化 SQLite 仓库。

    def seed_examples(self) -> list[dict[str, Any]]:  # 把基础和工业示例装入数据库但不覆盖用户修订。
        seeded: list[dict[str, Any]] = []  # 初始化示例载入结果。
        filenames = ["two_girder_bridge.bsdl.json", "cantilever_3d.bsdl.json", "calculix_industrial_bridge_segment.bsdl.json", "bridge_pylon_design_2.0.bsdl.json"]  # 定义默认示例文件。
        for filename in filenames:  # 遍历默认示例文件。
            path = self.root / "examples" / filename  # 构造示例路径。
            if not path.exists():  # 跳过缺失示例。
                continue  # 继续检查下一示例。
            document = load_json(path)  # 读取示例 BSDL 文档。
            seeded.append(self.repository.ensure_project(document))  # 确保示例项目存在。
        return seeded  # 返回示例载入状态。

    def seed_templates(self) -> list[dict[str, Any]]:  # 首次启动或升级时确保每类内置模板至少存在一个版本。
        existing_ids = {str(item.get("templateId")) for item in self.repository.list_templates()}  # 收集数据库中已有模板稳定 ID。
        templates = [  # 定义与人机闭环对应的初始模板。
            {"templateId": "template.structure_questionnaire", "name": "结构标准问卷 V1", "kind": "structure_questionnaire", "body": {"purpose": "把三维分割对象整理为 BSDL", "requiredSections": ["identity", "geometry", "material", "section", "nodes", "connections", "constraints", "loads", "task", "uncertainty"], "output": "BSDL JSON", "rules": ["未知信息显式标记 unknown", "不得虚构材料与约束", "保留点云或 BIM 源对象 ID"]}},  # 定义结构问卷模板。
            {"templateId": "template.mesh_strategy", "name": "区域网格策略 V1", "kind": "mesh_strategy", "body": {"globalAllocator": ["计算预算", "结构尺度", "任务精度"], "experts": ["support_joint", "discontinuity", "smooth", "fea_hotspot", "human_override"], "actions": ["add_region", "reject_region", "set_mesh_level", "set_target_size"], "approval": "人工修改形成新修订"}},  # 定义多专家策略模板。
            {"templateId": "template.experience_summary", "name": "交互经验摘要 V1", "kind": "experience_summary", "body": {"input": ["before_revision", "after_revision", "fea_metrics"], "outputFields": ["feature_signature", "human_action", "agent_action", "calculation_feedback", "outcome", "applicability", "failure_boundary"], "reuse": "按局部结构特征检索"}},  # 定义经验提炼模板。
            {"templateId": "template.memory_policy", "name": "BSDL 经验读回策略 V1", "kind": "memory_policy", "body": {"enabled": True, "minScore": 0.72, "maxExperiences": 500, "maxPerRegion": 3, "includeSameProject": False, "requireReview": True, "transfer": ["targetSizeRatio", "meshLevel", "maxIterations"], "guardrails": ["不复制项目本地 targetRefs", "不复制绝对坐标和绝对 targetSize", "人工和 FEA 区域不被历史经验覆盖", "经验迁移后默认 needs_review"]}},  # 定义跨项目经验读回策略模板。
            {"templateId": "template.design_intent", "name": "设计意图编译契约 V1", "kind": "design_intent", "body": {"input": ["rawText", "siteContext", "structuredOverrides"], "output": ["requirements", "objectives", "constraints", "preferences", "variables", "brief"], "guardrails": ["未知条件进入 unresolved", "领域默认必须 needs_review", "不得把自然语言解析等同工程批准"]}},  # 定义设计意图编译模板。
            {"templateId": "template.design_evaluation", "name": "多目标候选评价契约 V2", "kind": "design_evaluation", "body": {"generativeLoop": ["modeling", "computation", "evaluation", "feedback"], "evaluationSequence": ["hard_constraints", "objective_normalization", "pareto_rank", "engineering_evidence", "human_review"], "evidenceLevels": ["screening_surrogate", "analytical", "finite_element", "code_check", "experimental", "monitoring", "human_review", "combined"], "guardrails": ["generation 不是独立阶段", "代理筛选不得冒充工程证据", "局部预览不得伪装为完整多目标验证", "selected 必须 humanApproval"]}},  # 定义 BridgeMind 2.0 多目标评价模板。
        ]  # 完成初始模板定义。
        missing = [item for item in templates if item["templateId"] not in existing_ids]  # 只选择旧数据库中尚未出现的内置模板。
        return [self.repository.save_template(item["templateId"], item["name"], item["kind"], item["body"], True) for item in missing]  # 保存缺失模板并把该类别首版设为默认。

    def _audit(self, action: str, actor: str, source: str, status: str, details: dict[str, Any] | None = None, project_id: str | None = None, revision: int | None = None) -> dict[str, Any]:  # 统一写入审计事件。
        return self.repository.record_audit_event(action, actor, source, status, details, project_id, revision)  # 委托仓库保存不可变事件。

    def _memory_settings(self) -> dict[str, Any]:  # 从默认模板读取经验读回策略并提供安全回退值。
        template = self.repository.get_default_template("memory_policy")  # 读取当前默认经验策略模板。
        body = template.get("body", {}) if isinstance(template, dict) and isinstance(template.get("body"), dict) else {}  # 提取模板主体。
        return {"enabled": bool(body.get("enabled", True)), "minScore": float(body.get("minScore", 0.72)), "maxExperiences": int(body.get("maxExperiences", 500)), "maxPerRegion": int(body.get("maxPerRegion", 3)), "includeSameProject": bool(body.get("includeSameProject", False)), "requireReview": bool(body.get("requireReview", True)), "template": template}  # 返回规范化经验读回设置。

    def _apply_memory_readback(self, document: dict[str, Any], project_id: str, actor: str, enabled: bool | None = None, min_score: float | None = None, limit: int | None = None, max_per_region: int | None = None, include_same_project: bool | None = None) -> tuple[dict[str, Any], dict[str, Any]]:  # 使用数据库经验和默认模板执行一次读回。
        settings = self._memory_settings()  # 读取默认经验读回设置。
        memory_enabled = settings["enabled"] if enabled is None else bool(enabled)  # 合并调用参数和默认启用状态。
        if not memory_enabled:  # 检查是否关闭经验读回。
            return deep_copy(document), {"enabled": False, "candidateExperienceCount": 0, "matchedRegionCount": 0, "appliedRegionCount": 0, "experienceRefs": [], "perRegion": [], "template": settings.get("template")}  # 返回明确的关闭报告。
        memory_limit = max(1, min(5000, int(limit if limit is not None else settings["maxExperiences"])))  # 规范化经验查询上限。
        experiences = self.repository.list_experiences(None, None, memory_limit)  # 从全局经验库读取最近经验。
        updated, report = apply_memory(document, experiences, project_id, float(min_score if min_score is not None else settings["minScore"]), int(max_per_region if max_per_region is not None else settings["maxPerRegion"]), bool(include_same_project if include_same_project is not None else settings["includeSameProject"]), actor, bool(settings["requireReview"]))  # 把历史经验投影到当前 BSDL 策略。
        report["template"] = settings.get("template")  # 记录本次读回采用的模板版本。
        return updated, report  # 返回经验增强文档和读回报告。

    def _artifact_relative_path(self, path: str | Path) -> str:  # 把运行产物转换为安全相对下载路径。
        candidate = Path(path).resolve()  # 规范化产物路径。
        root = self.runs_directory.resolve()  # 规范化运行目录。
        if candidate != root and root not in candidate.parents:  # 检查产物是否位于隔离目录。
            raise ValueError(f"产物不在 runs 目录中：{candidate}")  # 阻止路径逃逸。
        return candidate.relative_to(root).as_posix()  # 返回跨平台相对路径。

    def _zip_directory(self, directory: str | Path) -> Path:  # 把阶段输出目录归档为可下载 ZIP。
        source = Path(directory).resolve()  # 规范化阶段目录。
        archive = source.with_suffix(".zip")  # 构造归档路径。
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:  # 创建压缩归档。
            for path in sorted(source.rglob("*")):  # 遍历阶段目录中的全部文件。
                if path.is_file():  # 只归档普通文件。
                    bundle.write(path, path.relative_to(source).as_posix())  # 保存稳定相对路径。
        return archive  # 返回 ZIP 路径。

    def create_project(self, document: dict[str, Any], author: str = "human.web", source: str = "manual", summary: str = "创建项目") -> dict[str, Any]:  # 验证并创建新项目。
        report = validate_document(document)  # 对输入文档执行完整验证。
        if not report["valid"]:  # 检查是否存在阻断问题。
            raise ValueError({"message": "BSDL 文档验证失败。", "validation": report})  # 阻止保存非法项目。
        created = self.repository.create_project(document, author, source, summary)  # 保存首个不可变修订。
        self._audit("project.create", author, source, "succeeded", {"summary": summary, "contentHash": created["contentHash"]}, created["projectId"], 1)  # 保存项目创建审计。
        return {"project": created, "validation": report}  # 返回项目创建结果和验证报告。

    def validate_project(self, project_id: str, revision: int | None = None) -> dict[str, Any]:  # 验证数据库中的指定修订。
        document = self.repository.get_document(project_id, revision)  # 读取目标修订文档。
        return validate_document(document)  # 返回完整验证报告。

    def save_revision(self, project_id: str, document: dict[str, Any], author: str, source: str, summary: str, status: str = "working", expected_revision: int | None = None) -> dict[str, Any]:  # 验证并保存带并发保护的新修订。
        report = validate_document(document)  # 执行保存前验证。
        if not report["valid"]:  # 检查是否存在阻断问题。
            raise ValueError({"message": "新修订验证失败，未写入数据库。", "validation": report})  # 阻止非法修订进入版本链。
        saved = self.repository.save_revision(project_id, document, author, source, summary, status, expected_revision)  # 保存不可变修订。
        self._audit("revision.save", author, source, "succeeded", {"summary": summary, "status": status, "parentRevision": saved["parentRevision"], "contentHash": saved["contentHash"]}, project_id, saved["revision"])  # 保存版本审计。
        return {"revision": saved, "validation": report}  # 返回保存结果和验证报告。

    def propose_project_strategy(self, project_id: str, revision: int | None = None, commit: bool = True, author: str = "software.bridgemind", summary: str = "多专家生成区域网格策略", use_memory: bool | None = None, memory_min_score: float | None = None, memory_limit: int | None = None, memory_max_per_region: int | None = None, include_same_project_memory: bool | None = None) -> dict[str, Any]:  # 对项目运行多专家策略并自动读回历史经验。
        document = self.repository.get_document(project_id, revision)  # 读取目标修订文档。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取策略输入修订。
        updated, report = propose_strategy(document, None, replace_generated=True, actor_id=author)  # 先用当前结构和规则专家生成基础策略。
        updated, memory_report = self._apply_memory_readback(updated, project_id, author, use_memory, memory_min_score, memory_limit, memory_max_per_region, include_same_project_memory)  # 再把跨项目历史经验读回基础策略。
        validation = validate_document(updated)  # 验证经验增强后的文档。
        if not validation["valid"]:  # 检查生成策略是否合法。
            raise RuntimeError({"message": "策略生成或经验读回结果未通过 BSDL 验证。", "validation": validation, "strategy": report, "memory": memory_report})  # 阻止非法自动结果。
        saved = self.repository.save_revision(project_id, updated, author, "agent", summary, "working", input_revision) if commit else None  # 根据请求保存带并发保护的 Agent 修订。
        if saved is not None:  # 检查是否写入版本链。
            updated = saved["document"]  # 使用数据库规范化后的修订元数据。
        self._audit("strategy.propose", author, "agent", "succeeded", {"commit": commit, "generatedRegionCount": report.get("generatedRegionCount"), "memoryEnabled": memory_report.get("enabled"), "memoryAppliedRegionCount": memory_report.get("appliedRegionCount"), "memoryExperienceRefs": memory_report.get("experienceRefs", [])}, project_id, saved.get("revision") if saved else input_revision)  # 保存策略与经验读回审计。
        return {"document": updated, "strategy": report, "memory": memory_report, "validation": validation, "savedRevision": saved}  # 返回策略、经验读回、文档和可选修订。

    def preview_project_memory(self, project_id: str, revision: int | None = None, min_score: float | None = None, limit: int | None = None, max_per_region: int | None = None, include_same_project: bool | None = None, actor: str = "software.bridgemind") -> dict[str, Any]:  # 在不保存修订的情况下预览经验读回效果。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        proposed, strategy_report = propose_strategy(document, None, replace_generated=True, actor_id=actor)  # 先生成可比较的基础区域策略。
        enhanced, memory_report = self._apply_memory_readback(proposed, project_id, actor, True, min_score, limit, max_per_region, include_same_project)  # 执行只读经验匹配和策略投影。
        validation = validate_document(enhanced)  # 验证预览结果仍满足 BSDL 规则。
        return {"document": enhanced, "strategy": strategy_report, "memory": memory_report, "validation": validation}  # 返回不落库的读回预览。

    def solve_project(self, project_id: str, revision: int | None = None, mesh_policy_id: str | None = None, load_case_id: str | None = None, commit_feedback: bool = True, author: str = "software.bridgemind") -> dict[str, Any]:  # 执行非权威快速预览并可把结果反馈写入新修订。
        document = self.repository.get_document(project_id, revision)  # 读取目标修订文档。
        actual_revision = int(document.get("revision", {}).get("number", revision or 1))  # 获取实际修订号。
        validation = validate_document(document)  # 执行求解前验证。
        if not validation["valid"]:  # 检查求解前阻断问题。
            raise ValueError({"message": "求解前 BSDL 验证失败。", "validation": validation})  # 阻止非法模型进入求解器。
        input_payload = {"meshPolicyRef": mesh_policy_id, "loadCaseRef": load_case_id, "documentId": document.get("documentId"), "authoritative": False}  # 构造运行输入摘要。
        run_id = self.repository.start_run(project_id, actual_revision, "builtin_frame3d_preview", input_payload)  # 创建运行记录。
        try:  # 捕获确定性求解失败。
            result = solve_document(document, mesh_policy_id, load_case_id)  # 执行空间梁快速预览。
            result["runId"] = run_id  # 把数据库运行 ID 写入结果。
            result["authoritative"] = False  # 明确该结果只用于交互预览。
            self.repository.finish_run(run_id, result=result)  # 保存成功运行结果。
        except FrameSolveError as error:  # 处理结构或数值求解失败。
            error_payload = {"type": "FrameSolveError", "message": str(error), "details": error.details}  # 构造结构化错误对象。
            self.repository.finish_run(run_id, error=error_payload)  # 保存失败运行状态。
            self._audit("preview.solve", author, "builtin_frame3d", "failed", error_payload, project_id, actual_revision)  # 保存失败审计。
            raise RuntimeError(error_payload) from error  # 向 API 或 CLI 返回明确失败。
        feedback_revision = None  # 初始化可选 FEA 反馈修订。
        feedback_document = None  # 初始化可选反馈文档。
        strategy_report = None  # 初始化可选热点策略报告。
        if commit_feedback:  # 检查是否把计算结果写回版本链。
            feedback_document = deep_copy(document)  # 深复制求解输入文档。
            feedback_id = f"feedback.fea.{run_id.split('.')[-1][:12]}"  # 生成 FEA 反馈 ID。
            feedback_document.setdefault("feedback", []).append({"id": feedback_id, "source": "fea", "kind": "fea_result", "createdAt": utc_now(), "createdBy": author, "targetRefs": [str(item.get("componentRef")) for item in result.get("elementResults", [])[:20]], "before": None, "after": {"runId": run_id, "loadCaseRef": result.get("loadCaseRef")}, "metrics": dict(result.get("globalMetrics", {})), "comment": "内置空间梁非权威快速预览结果与反力平衡反馈。", "status": "recorded"})  # 保存计算反馈对象。
            feedback_document, strategy_report = propose_strategy(feedback_document, result, replace_generated=True, actor_id=author)  # 根据预览结果重建 Agent 区域并加入热点区。
            feedback_document, memory_report = self._apply_memory_readback(feedback_document, project_id, author)  # 在 FEA 热点形成后重新读回跨项目经验并保留 FEA 高优先级区域。
            strategy_report["memory"] = memory_report  # 把读回报告挂到本次 FEA 策略报告中。
            feedback_validation = validate_document(feedback_document)  # 验证反馈文档。
            if not feedback_validation["valid"]:  # 检查反馈闭环是否合法。
                raise RuntimeError({"message": "FEA 反馈文档未通过验证。", "validation": feedback_validation})  # 阻止非法反馈修订。
            feedback_revision = self.repository.save_revision(project_id, feedback_document, author, "fea_preview", f"快速预览反馈 {run_id}", "working", actual_revision)  # 保存新的反馈修订。
            feedback_document = feedback_revision["document"]  # 使用数据库规范化后的修订元数据。
        self._audit("preview.solve", author, "builtin_frame3d", "succeeded", {"runId": run_id, "commitFeedback": commit_feedback, "authoritative": False}, project_id, actual_revision)  # 保存成功审计。
        return {"runId": run_id, "result": result, "inputRevision": actual_revision, "feedbackRevision": feedback_revision, "feedbackDocument": feedback_document, "strategy": strategy_report}  # 返回运行和可选反馈修订。

    def extract_and_save_experiences(self, project_id: str, revision_from: int, revision_to: int, run_id: str | None = None) -> dict[str, Any]:  # 从两个修订提取经验并写入经验库。
        before = self.repository.get_document(project_id, revision_from)  # 读取旧修订。
        after = self.repository.get_document(project_id, revision_to)  # 读取新修订。
        metrics: dict[str, Any] = {}  # 初始化可选运行指标。
        if run_id is not None:  # 检查是否关联一次 FEA 运行。
            run = self.repository.get_run(run_id)  # 读取运行记录。
            if isinstance(run.get("result"), dict):  # 检查运行结果存在。
                metrics = dict(run["result"].get("globalMetrics", run["result"].get("summary", {})))  # 提取预览或 CalculiX 指标。
        records = extract_experiences(project_id, revision_from, revision_to, before, after, metrics)  # 生成结构化经验记录。
        saved = [self.repository.save_experience(record) for record in records]  # 把所有经验写入数据库。
        self._audit("experience.extract", "software.bridgemind", "experience", "succeeded", {"revisionFrom": revision_from, "revisionTo": revision_to, "recordCount": len(records), "runId": run_id}, project_id, revision_to)  # 保存经验提取审计。
        return {"recordCount": len(records), "records": records, "saved": saved}  # 返回经验提取结果。

    def import_point_cloud(self, path: str | Path, eps: float = 0.6, min_samples: int = 6, voxel_size: float = 0.2, author: str = "software.pointcloud_importer") -> dict[str, Any]:  # 导入点云并创建新 BSDL 项目。
        document, report = build_bsdl_from_point_cloud(path, eps, min_samples, voxel_size)  # 执行点云分割和语言生成。
        validation = validate_document(document)  # 验证生成文档。
        if not validation["valid"]:  # 检查生成文档合法性。
            raise RuntimeError({"message": "点云生成的 BSDL 未通过验证。", "validation": validation})  # 阻止非法导入项目。
        created = self.repository.create_project(document, author, "point_cloud", "点云分割生成初始 BSDL 项目")  # 创建点云项目。
        self._audit("import.point_cloud", author, "point_cloud", "succeeded", report, created["projectId"], created["revision"])  # 保存导入审计。
        return {"project": created, "import": report, "validation": validation}  # 返回导入结果。

    def import_ifc_file(self, path: str | Path, mvd_profile_path: str | Path | None = None, project_id: str | None = None, author: str = "software.ifc43_importer") -> dict[str, Any]:  # 导入 IFC 4.3 文件并创建 BSDL 项目。
        imported = import_ifc(path, mvd_profile_path, project_id)  # 执行 IFC 4.3、MVD 和身份映射。
        document = imported["document"]  # 读取转换后的 BSDL 文档。
        validation = validate_document(document)  # 执行 BSDL 工业验证。
        if not validation["valid"]:  # 检查导入结果是否可保存。
            raise RuntimeError({"message": "IFC 转换结果未通过 BSDL 验证。", "validation": validation, "conversion": imported["conversionReport"]})  # 阻止非法项目进入数据库。
        created = self.repository.create_project(document, author, "ifc43", "IFC 4.3/MVD 导入初始 BSDL 项目")  # 创建 IFC 项目。
        self._audit("import.ifc43", author, "ifc43", "succeeded", {"mvd": imported["mvd"], "conversionReport": imported["conversionReport"]}, created["projectId"], created["revision"])  # 保存 IFC 导入审计。
        return {**imported, "project": created, "validation": validation}  # 返回项目、MVD 和转换报告。

    def export_project(self, project_id: str, adapter: str, revision: int | None = None, mesh_policy_id: str | None = None, load_case_id: str | None = None, solver_plan_id: str | None = None, finite_element_model_id: str | None = None, strict: bool | None = None, actor: str = "human.web") -> dict[str, Any]:  # 导出当前项目到外部工具输入格式。
        document = self.repository.get_document(project_id, revision)  # 读取目标修订文档。
        actual_revision = int(document.get("revision", {}).get("number", revision or 1))  # 获取实际修订号。
        safe_project = project_id.replace(":", "_").replace("/", "_")  # 构造安全输出文件名前缀。
        if adapter == "calculix":  # 处理 CalculiX 导出。
            requested_output = self.runs_directory / f"{safe_project}_V{actual_revision}.inp"  # 构造 CalculiX 输入路径。
            report = export_calculix(document, requested_output, mesh_policy_id, load_case_id, solver_plan_id, finite_element_model_id, strict)  # 执行 CalculiX 转换。
            raw_output = Path(str(report.get("output", requested_output))).resolve()  # 读取单 deck 或阶段目录。
            output = self._zip_directory(raw_output) if raw_output.is_dir() else raw_output  # 把阶段目录归档为 ZIP。
        elif adapter == "gmsh":  # 处理 Gmsh 导出。
            output = self.runs_directory / f"{safe_project}_V{actual_revision}.geo"  # 构造 Gmsh 脚本路径。
            report = export_gmsh(document, output, mesh_policy_id)  # 执行 Gmsh 转换。
        elif adapter == "bsdl":  # 处理规范化 BSDL 导出。
            output = self.runs_directory / f"{safe_project}_V{actual_revision}.bsdl.json"  # 构造 BSDL 输出路径。
            save_json(output, document)  # 写入完整 BSDL 文档。
            report = {"adapter": "bsdl", "output": str(output), "losses": [], "warnings": [], "blocked": False}  # 构造无损导出报告。
        else:  # 处理未知 Adapter。
            raise ValueError(f"未知导出 Adapter：{adapter}")  # 返回明确错误。
        download_path = self._artifact_relative_path(output)  # 构造安全下载路径。
        self._audit("adapter.export", actor, adapter, "blocked" if report.get("blocked") else "succeeded", {"downloadPath": download_path, "reportId": report.get("id"), "lossCount": len(report.get("losses", []))}, project_id, actual_revision)  # 保存导出审计。
        return {"projectId": project_id, "revision": actual_revision, "report": report, "output": str(output), "downloadPath": download_path}  # 返回导出结果。

    def run_code_check_project(self, project_id: str, plan_id: str, revision: int | None, result_context: dict[str, Any], commit: bool = True, actor: str = "human.web") -> dict[str, Any]:  # 执行项目规则包验算并可保存为新修订。
        document = self.repository.get_document(project_id, revision)  # 读取指定或当前 BSDL 修订。
        actual_revision = int(document.get("revision", {}).get("number", revision or 1))  # 获取验算所基于的实际修订号。
        report = run_code_check_plan(document, plan_id, result_context, self.root)  # 执行受限表达式规则包。
        saved: dict[str, Any] | None = None  # 初始化可选修订保存结果。
        if commit:  # 检查是否需要把验算结果写回项目。
            updated = deep_copy(document)  # 深复制文档避免修改历史快照。
            retained = [item for item in updated.get("codeCheckResults", []) if isinstance(item, dict) and item.get("planRef") != plan_id]  # 保留其他验算计划的结果。
            updated["codeCheckResults"] = retained + list(report.get("results", []))  # 写入当前计划的最新可审计结果。
            for plan in updated.get("codeCheckPlans", []):  # 遍历验算计划更新执行状态。
                if isinstance(plan, dict) and plan.get("id") == plan_id:  # 查找当前验算计划。
                    plan["status"] = "blocked" if report.get("status") == "blocked" else "executed"  # 保存计划最终执行状态。
            validation = validate_document(updated)  # 验证验算结果写回后的完整文档。
            if not validation["valid"]:  # 检查写回文档是否合法。
                raise RuntimeError({"message": "规范验算结果写回后未通过 BSDL 验证。", "validation": validation, "report": report})  # 阻止非法修订进入数据库。
            saved = self.repository.save_revision(project_id, updated, actor, "code_check", f"执行验算计划 {plan_id}", "working", actual_revision)  # 使用乐观并发保护保存新修订。
        audit_revision = int(saved["revision"]) if saved else actual_revision  # 选择审计关联修订号。
        self._audit("code_check.run", actor, "code_check", str(report.get("status", "completed")), {"planId": plan_id, "summary": report.get("summary"), "committed": bool(saved)}, project_id, audit_revision)  # 保存规范验算审计。
        return {"projectId": project_id, "baseRevision": actual_revision, "resultRevision": saved.get("revision") if saved else None, "report": report, "saved": saved}  # 返回验算报告和可选修订结果。

    def calculix_status(self, executable: str | None = None) -> dict[str, Any]:  # 返回当前服务器 CalculiX 可用状态。
        return detect_calculix(executable)  # 委托 CalculiX 探测器。

    def _commit_calculix_results(self, project_id: str, base_revision: int, run_id: str, jobs: list[dict[str, Any]], actor: str) -> dict[str, Any] | None:  # 把成功求解产物和 ResultSet 写入新 BSDL 修订。
        successful = [job for job in jobs if isinstance(job.get("execution"), dict) and job["execution"].get("status") == "succeeded" and isinstance(job["execution"].get("resultSet"), dict)]  # 筛选包含可导入结果集的成功作业。
        if not successful:  # 检查是否存在可提交的求解结果。
            return None  # 没有结果时不创建空修订。
        document = self.repository.get_document(project_id, base_revision)  # 读取运行所基于的不可变文档快照。
        updated = deep_copy(document)  # 深复制文档用于结果回写。
        existing_artifact_ids = {str(item.get("id")) for item in updated.get("artifacts", []) if isinstance(item, dict)}  # 收集已有产物 ID。
        existing_result_ids = {str(item.get("id")) for item in updated.get("resultSets", []) if isinstance(item, dict)}  # 收集已有结果集 ID。
        added_artifacts: list[str] = []  # 初始化新增产物 ID 列表。
        added_results: list[str] = []  # 初始化新增结果集 ID 列表。
        for job in successful:  # 遍历每个成功 CalculiX 作业。
            execution = job["execution"]  # 读取作业执行对象。
            artifact_ids: list[str] = []  # 初始化当前作业产物引用。
            dat_artifact_id: str | None = None  # 初始化 DAT 结果产物引用。
            for artifact in execution.get("artifacts", []):  # 遍历真实文件产物清单。
                if not isinstance(artifact, dict) or not artifact.get("path") or not artifact.get("sha256"):  # 检查产物清单基本字段。
                    continue  # 跳过不完整产物记录。
                artifact_path = Path(str(artifact["path"]))  # 解析产物文件路径。
                relative = self._artifact_relative_path(artifact_path)  # 转换为 runs 目录内的安全相对路径。
                suffix = artifact_path.suffix.lower()  # 读取产物扩展名。
                kind = "solver_input" if suffix == ".inp" else ("solver_output" if suffix in {".dat", ".frd", ".sta", ".cvg", ".12d", ".eig"} else ("log" if suffix in {".out", ".log"} else "other"))  # 根据扩展名确定产物类型。
                artifact_id = f"artifact.ccx.{content_hash({'sha': artifact['sha256'], 'name': artifact_path.name})[:20]}"  # 构造稳定且避免空日志哈希冲突的产物 ID。
                artifact_ids.append(artifact_id)  # 保存当前作业产物引用。
                if suffix == ".dat":  # 检查当前产物是否为 DAT 结果文件。
                    dat_artifact_id = artifact_id  # 保存结果字段首选产物引用。
                if artifact_id in existing_artifact_ids:  # 检查产物是否已经写入文档。
                    continue  # 跳过重复产物实体。
                updated.setdefault("artifacts", []).append({"id": artifact_id, "kind": kind, "uri": relative, "format": suffix.lstrip(".") or "binary", "hash": str(artifact["sha256"]), "createdAt": utc_now()})  # 写入 Schema 兼容产物实体。
                existing_artifact_ids.add(artifact_id)  # 更新产物 ID 索引。
                added_artifacts.append(artifact_id)  # 记录本次新增产物。
            result_set = deep_copy(execution["resultSet"])  # 复制 Adapter 生成的结果集摘要。
            result_set["id"] = f"result.calculix.{content_hash({'run': run_id, 'deck': job.get('deck')})[:20]}"  # 使用数据库运行和 deck 构造稳定结果 ID。
            result_set["runRef"] = run_id  # 关联数据库中的真实运行记录。
            result_set["artifactRefs"] = list(dict.fromkeys(artifact_ids))  # 关联当前作业全部产物。
            for field in result_set.get("fields", []):  # 遍历结果字段。
                if isinstance(field, dict):  # 检查字段对象。
                    field["artifactRef"] = dat_artifact_id  # 把字段关联到可解析 DAT 产物。
            if result_set["id"] in existing_result_ids:  # 检查结果集是否已经存在。
                continue  # 跳过重复结果集实体。
            updated.setdefault("resultSets", []).append(result_set)  # 写入结果集实体。
            existing_result_ids.add(result_set["id"])  # 更新结果 ID 索引。
            added_results.append(result_set["id"])  # 记录本次新增结果集。
        if not added_results:  # 检查是否实际新增结果集。
            return None  # 不创建无变化修订。
        validation = validate_document(updated)  # 验证结果和产物回写后的完整 BSDL 文档。
        if not validation["valid"]:  # 检查结果修订合法性。
            raise RuntimeError({"message": "CalculiX 结果回写后未通过 BSDL 验证。", "validation": validation})  # 阻止非法结果修订。
        saved = self.repository.save_revision(project_id, updated, actor, "calculix_result_import", f"导入 CalculiX 运行 {run_id} 的结果与产物", "working", base_revision)  # 使用乐观并发保护保存结果修订。
        return {"revision": saved["revision"], "artifactIds": added_artifacts, "resultSetIds": added_results, "validationLevel": validation.get("level")}  # 返回结果回写摘要。

    def run_calculix_project(self, project_id: str, revision: int | None = None, mesh_policy_id: str | None = None, load_case_id: str | None = None, solver_plan_id: str | None = None, finite_element_model_id: str | None = None, strict: bool | None = True, executable: str | None = None, timeout: float = 3600.0, threads: int = 1, actor: str = "human.web", commit_result: bool = True) -> dict[str, Any]:  # 导出并受控执行 CalculiX 单 deck 或阶段包。
        exported = self.export_project(project_id, "calculix", revision, mesh_policy_id, load_case_id, solver_plan_id, finite_element_model_id, strict, actor)  # 先生成并静态检查 CalculiX 输入。
        actual_revision = int(exported["revision"])  # 读取实际修订号。
        report = exported["report"]  # 读取转换报告。
        raw_output = Path(str(report.get("output", exported["output"]))).resolve()  # 定位单 deck 或阶段目录。
        decks = sorted(raw_output.glob("*.inp")) if raw_output.is_dir() else [raw_output]  # 收集待运行 deck。
        input_payload = {"decks": [str(path) for path in decks], "solverPlanId": solver_plan_id, "finiteElementModelId": finite_element_model_id, "timeout": timeout, "threads": threads, "conversionReportId": report.get("id")}  # 构造运行输入摘要。
        run_id = self.repository.start_run(project_id, actual_revision, "calculix_2.23", input_payload)  # 创建 CalculiX 运行记录。
        if report.get("blocked") or not decks:  # 检查转换阻断或无输入文件。
            error = {"type": "CalculiXExportBlocked", "message": "CalculiX 输入生成被阻断。", "conversion": report}  # 构造阻断错误。
            self.repository.finish_run(run_id, error=error, status_override="blocked")  # 保存阻断运行状态。
            self._audit("calculix.run", actor, "calculix", "blocked", error, project_id, actual_revision)  # 保存阻断审计。
            return {"runId": run_id, "status": "blocked", "export": exported, "jobs": [], "summary": {"message": error["message"]}}  # 返回阻断结果。
        jobs: list[dict[str, Any]] = []  # 初始化阶段或单作业结果。
        for deck in decks:  # 遍历待执行输入文件。
            execution = run_calculix(deck, executable, timeout, threads)  # 受控执行 ccx 或返回 unavailable。
            parsed = execution.get("parsedResults") if execution.get("status") == "succeeded" else None  # 复用 Adapter 已完成的 DAT 结果回读。
            jobs.append({"deck": str(deck), "execution": execution, "results": parsed})  # 保存作业结果。
        statuses = [str(job["execution"].get("status")) for job in jobs]  # 收集作业状态。
        if statuses and all(status == "succeeded" for status in statuses):  # 检查全部作业成功。
            overall_status = "succeeded"  # 设置成功状态。
        elif statuses and all(status == "unavailable" for status in statuses):  # 检查服务器未安装 ccx。
            overall_status = "unavailable"  # 设置不可用状态。
        elif "timeout" in statuses:  # 检查是否存在超时。
            overall_status = "timeout"  # 设置超时状态。
        elif "blocked" in statuses:  # 检查静态阻断。
            overall_status = "blocked"  # 设置阻断状态。
        else:  # 处理部分或全部求解失败。
            overall_status = "failed"  # 设置失败状态。
        summary = {"jobCount": len(jobs), "statuses": statuses, "resultSummaries": [job["results"].get("summaries", {}) for job in jobs if isinstance(job.get("results"), dict)], "authoritative": True, "realSolverExecuted": any(status not in {"unavailable", "blocked"} for status in statuses)}  # 组装运行摘要。
        result_commit = self._commit_calculix_results(project_id, actual_revision, run_id, jobs, actor) if commit_result and overall_status == "succeeded" else None  # 在成功时可选保存结果和产物修订。
        result = {"status": overall_status, "export": exported, "jobs": jobs, "summary": summary, "resultCommit": result_commit}  # 组装数据库结果对象。
        error_payload = None if overall_status in {"succeeded", "unavailable"} else {"type": "CalculiXRunFailure", "message": f"CalculiX 作业状态：{overall_status}", "statuses": statuses}  # 构造可选错误对象。
        self.repository.finish_run(run_id, result=result, error=error_payload, status_override=overall_status)  # 保存最终运行状态和产物。
        self._audit("calculix.run", actor, "calculix", overall_status, {"runId": run_id, "resultCommit": result_commit, **summary}, project_id, int(result_commit["revision"]) if result_commit else actual_revision)  # 保存运行和结果回写审计。
        return {"runId": run_id, **result}  # 返回 CalculiX 运行结果。

    def _save_design_revision(self, project_id: str, updated: dict[str, Any], actor: str, source: str, summary: str, input_revision: int, commit: bool) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any]]:  # 验证并可选保存 BridgeMind 2.0 设计修订。
        validation = validate_document(updated)  # 对设计语义和既有工业语义执行完整验证。
        if not validation["valid"]:  # 检查设计操作是否产生阻断问题。
            raise RuntimeError({"message": "BridgeMind 2.0 设计文档未通过 BSDL 验证。", "validation": validation})  # 阻止非法设计状态进入版本链。
        saved = self.repository.save_revision(project_id, updated, actor, source, summary, "working", input_revision) if commit else None  # 按请求保存带并发保护的新修订。
        document = saved["document"] if saved is not None else updated  # 选择数据库规范化文档或内存文档。
        return document, saved, validation  # 返回文档、可选修订和验证报告。

    def get_project_design_summary(self, project_id: str, revision: int | None = None) -> dict[str, Any]:  # 返回不修改项目的 BridgeMind 2.0 设计闭环摘要。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        process = document.get("designProcess", {}) if isinstance(document.get("designProcess"), dict) else {}  # 读取设计过程对象。
        active_brief_ref = process.get("activeBriefRef")  # 读取活动设计任务引用。
        active_iteration_ref = process.get("activeIterationRef")  # 读取活动设计迭代引用。
        brief = next((item for item in process.get("briefs", []) if isinstance(item, dict) and item.get("id") == active_brief_ref), None)  # 查找活动设计任务。
        iteration = next((item for item in process.get("iterations", []) if isinstance(item, dict) and item.get("id") == active_iteration_ref), None)  # 查找活动设计迭代。
        stage_records = list(iteration.get("stageRecords", [])) if isinstance(iteration, dict) else []  # 读取四阶段执行记录。
        active_stage_record = next((item for item in stage_records if isinstance(item, dict) and item.get("status") in {"active", "requires_human", "blocked"}), None)  # 查找当前活动、人工门或阻断阶段。
        iteration_candidate_refs = set(iteration.get("candidateRefs", [])) if isinstance(iteration, dict) else set()  # 读取本轮候选引用集合。
        candidates = [item for item in process.get("candidates", []) if isinstance(item, dict) and (not iteration_candidate_refs or item.get("id") in iteration_candidate_refs)]  # 读取本轮候选或全部活动任务候选。
        evaluations = [item for item in process.get("evaluationResults", []) if isinstance(item, dict) and item.get("candidateRef") in {candidate.get("id") for candidate in candidates}]  # 读取本轮候选评价。
        summary = {"semanticVersion": str(process.get("version", "2.0.0")), "generativeLoop": list(process.get("generativeLoop", GENERATION_LOOP)), "activeBriefRef": active_brief_ref, "activeBriefName": brief.get("name") if isinstance(brief, dict) else None, "activeIterationRef": active_iteration_ref, "activeIterationStatus": iteration.get("status") if isinstance(iteration, dict) else None, "activeStage": active_stage_record.get("stage") if isinstance(active_stage_record, dict) else None, "activeStageStatus": active_stage_record.get("status") if isinstance(active_stage_record, dict) else None, "nextAction": iteration.get("nextAction") if isinstance(iteration, dict) else "compile_design_intent", "humanApprovalRequired": bool(iteration.get("humanApprovalRequired", True)) if isinstance(iteration, dict) else True, "stageRecords": deep_copy(stage_records), "counts": {"briefs": len(process.get("briefs", [])), "iterations": len(process.get("iterations", [])), "candidates": len(candidates), "modeledCandidates": sum(1 for item in candidates if item.get("modelArtifactRefs")), "computedCandidates": sum(1 for item in candidates if item.get("resultArtifactRefs")), "screeningEvaluations": sum(1 for item in evaluations if item.get("evidenceLevel") == "screening_surrogate"), "partialEngineeringEvaluations": sum(1 for item in evaluations if item.get("status") == "partially_verified"), "verifiedEngineeringEvaluations": sum(1 for item in evaluations if item.get("status") == "verified" and item.get("evidenceLevel") != "screening_surrogate"), "decisions": sum(1 for item in process.get("decisions", []) if isinstance(item, dict) and (not active_iteration_ref or item.get("iterationRef") == active_iteration_ref))}, "candidateSummaries": [{"id": item.get("id"), "name": item.get("name"), "archetype": item.get("archetype"), "status": item.get("status"), "modelArtifactRefs": list(item.get("modelArtifactRefs", [])), "resultArtifactRefs": list(item.get("resultArtifactRefs", [])), "engineeringMetrics": deep_copy(item.get("engineeringMetrics", {})), "evaluationResultRefs": list(item.get("evaluationResultRefs", []))} for item in candidates], "authoritative": False, "boundary": "BridgeMind 2.0 组织候选建模—计算—评价—反馈；最终工程放行仍需完整证据与责任工程师批准。"}  # 构造设计闭环摘要。
        validation = validate_document(document)  # 读取当前修订的完整 BSDL 验证状态。
        return {"projectId": project_id, "revision": int(document.get("revision", {}).get("number", revision or 1)), "summary": summary, "validation": validation}  # 返回只读设计摘要。

    def compile_project_design_intent(self, project_id: str, raw_text: str, structured: dict[str, Any] | None = None, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 把项目自然语言需求编译为 BSDL 1.1 设计语义。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        updated, report = compile_design_intent(document, raw_text, actor, structured)  # 执行设计意图编译。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_intent", "BridgeMind 2.0 编译设计意图", input_revision, commit)  # 验证并可选保存设计任务。
        self._audit("design.intent.compile", actor, "design_agent", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存设计意图编译审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回编译结果。

    def generate_project_design_candidates(self, project_id: str, brief_id: str | None = None, count: int = 4, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design", use_skills: bool = True) -> dict[str, Any]:  # 为项目设计任务生成候选方案并可读回人工固化技能。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        design_skills = self.repository.list_templates("design_skill") if use_skills else []  # 按请求读取全部版本化设计技能。
        updated, report = generate_design_candidates(document, brief_id, count, actor, design_skills)  # 执行候选方案生成和动态技能嵌入。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_generation", "BridgeMind 2.0 生成设计候选", input_revision, commit)  # 验证并可选保存候选。
        self._audit("design.candidates.generate", actor, "design_agent", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存候选生成审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回候选生成结果。

    def materialize_project_design_candidate(self, project_id: str, candidate_id: str, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design", human_approval: bool = False) -> dict[str, Any]:  # 把候选模型补丁写入当前 BSDL 工作模型。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        updated, report = materialize_design_candidate(document, candidate_id, actor, human_approval)  # 执行受控候选物化。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_materialization", "BridgeMind 2.0 物化设计候选", input_revision, commit)  # 验证并可选保存工作模型。
        self._audit("design.candidate.materialize", actor, "design_agent", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存候选物化审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回候选物化结果。

    def preview_project_design_candidate(self, project_id: str, candidate_id: str, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 物化候选、执行真实内置 FEA 并把结果写回多目标评价证据。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        materialized, materialization_report = materialize_design_candidate(document, candidate_id, actor, False)  # 通过确定性生成器物化候选结构与预览契约。
        candidate = next((item for item in materialized.get("designProcess", {}).get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 读取物化后的候选对象。
        if candidate is None:  # 检查候选是否仍然存在。
            raise KeyError(f"候选方案不存在：{candidate_id}")  # 返回候选缺失错误。
        evaluated, screening_report = evaluate_design_candidates(materialized, str(candidate.get("briefRef")), [candidate_id], actor)  # 确保候选具有可追踪的代理筛选基线。
        generation = materialization_report.get("generation", {}) if isinstance(materialization_report.get("generation"), dict) else {}  # 读取参数化生成报告。
        mesh_policy_ref = generation.get("meshPolicyRef")  # 读取预览网格策略引用。
        load_case_ref = generation.get("loadCaseRef")  # 读取预览荷载工况引用。
        if not isinstance(mesh_policy_ref, str) or not isinstance(load_case_ref, str):  # 检查预览契约完整性。
            raise RuntimeError({"message": "候选物化没有生成可执行预览契约。", "generation": generation})  # 阻止无任务求解。
        run_input = {"candidateId": candidate_id, "meshPolicyRef": mesh_policy_ref, "loadCaseRef": load_case_ref, "authoritative": False, "purpose": "generative_design_evaluation"}  # 构造设计候选预览输入摘要。
        run_id = self.repository.start_run(project_id, input_revision, "design_candidate_frame3d_preview", run_input)  # 创建数据库运行记录。
        try:  # 捕获确定性求解失败。
            result = solve_document(evaluated, mesh_policy_ref, load_case_ref)  # 执行空间梁真实数值预览。
            result["runId"] = run_id  # 把数据库运行 ID 写入结果。
            result["authoritative"] = False  # 明确内置求解只承担生成式闭环预览。
        except FrameSolveError as error:  # 处理结构或数值求解失败。
            error_payload = {"type": "FrameSolveError", "message": str(error), "details": error.details, "candidateId": candidate_id}  # 构造结构化求解错误。
            self.repository.finish_run(run_id, error=error_payload)  # 保存失败运行状态。
            self._audit("design.candidate.preview", actor, "builtin_frame3d", "failed", error_payload, project_id, input_revision)  # 保存失败审计。
            raise RuntimeError(error_payload) from error  # 向 API 返回明确失败。
        run_directory = self.runs_directory / "design_preview" / content_hash(project_id)[:12]  # 构造隔离的设计预览目录。
        run_directory.mkdir(parents=True, exist_ok=True)  # 确保设计预览目录存在。
        result_path = run_directory / f"{content_hash({'candidate': candidate_id, 'run': run_id})[:20]}.json"  # 构造稳定预览结果文件名。
        save_json(result_path, result)  # 保存完整数值预览结果。
        artifact_id = f"artifact.design_preview.{content_hash({'candidate': candidate_id, 'run': run_id, 'result': result.get('globalMetrics')})[:20]}"  # 构造预览证据产物 ID。
        evidence_document = deep_copy(evaluated)  # 深复制评价文档用于写入证据产物。
        if not any(isinstance(item, dict) and item.get("id") == artifact_id for item in evidence_document.get("artifacts", [])):  # 检查产物是否已存在。
            evidence_document.setdefault("artifacts", []).append({"id": artifact_id, "kind": "solver_output", "uri": self._artifact_relative_path(result_path), "format": "json", "hash": content_hash(result), "createdAt": utc_now()})  # 写入可下载且带哈希的求解证据产物。
        process = evidence_document.get("designProcess", {}) if isinstance(evidence_document.get("designProcess"), dict) else {}  # 读取设计过程对象。
        candidate = next((item for item in process.get("candidates", []) if isinstance(item, dict) and item.get("id") == candidate_id), None)  # 重新读取当前候选。
        plan = next((item for item in process.get("evaluationPlans", []) if isinstance(item, dict) and item.get("briefRef") == candidate.get("briefRef") and item.get("status") == "active"), None) if isinstance(candidate, dict) else None  # 查找活动多目标评价计划。
        if candidate is None or plan is None:  # 检查候选和评价计划完整性。
            raise RuntimeError("设计候选或活动评价计划在 FEA 预览后丢失。")  # 阻止无评价契约写回。
        objective_index = {item.get("id"): item for item in process.get("objectives", []) if isinstance(item, dict)}  # 建立设计目标索引。
        screening_results = [item for item in process.get("evaluationResults", []) if isinstance(item, dict) and item.get("candidateRef") == candidate_id and item.get("evidenceLevel") == "screening_surrogate"]  # 收集候选代理筛选结果。
        screening_result = screening_results[-1] if screening_results else {}  # 选择最近代理筛选结果。
        height = float(candidate.get("variableValues", {}).get("design.variable.height", 100.0)) if isinstance(candidate.get("variableValues"), dict) else 100.0  # 读取候选特征高度用于位移尺度化。
        displacement_limit = max(abs(height) / 400.0, 0.01)  # 采用透明的 H/400 预览位移尺度。
        max_translation = float(result.get("globalMetrics", {}).get("maxTranslation", 0.0))  # 读取最大平移。
        structural_score = 1.0 / (1.0 + max_translation / displacement_limit)  # 把位移响应转换为零到一高值优预览分数。
        screening_values = {item.get("objectiveRef"): item for item in screening_result.get("objectiveValues", []) if isinstance(item, dict)} if isinstance(screening_result, dict) else {}  # 建立代理筛选目标值索引以保留未被当前 FEA 覆盖的目标。
        objective_values: list[dict[str, Any]] = []  # 初始化覆盖全部活动目标的混合证据值。
        for objective_ref in plan.get("objectiveRefs", []):  # 遍历活动评价计划中的每个目标。
            objective = objective_index.get(objective_ref, {})  # 读取当前目标定义。
            screening_value = screening_values.get(objective_ref)  # 读取当前目标的代理筛选值。
            if objective.get("category") == "safety":  # 仅把当前内置 FEA 能直接支持的结构安全目标标记为已验证。
                objective_values.append({"objectiveRef": objective_ref, "rawValue": structural_score, "normalizedValue": structural_score, "unit": None, "direction": objective.get("direction", "maximize"), "source": "builtin_frame3d_fea_preview", "evidenceRefs": [artifact_id], "confidence": 0.78, "verificationStatus": "verified"})  # 保存由真实数值求解产物支持的结构目标。
            elif isinstance(screening_value, dict):  # 检查是否存在透明代理筛选值。
                objective_values.append({"objectiveRef": objective_ref, "rawValue": float(screening_value.get("rawValue", screening_value.get("normalizedValue", 0.0))), "normalizedValue": float(screening_value.get("normalizedValue", 0.0)), "unit": screening_value.get("unit", objective.get("unit")), "direction": screening_value.get("direction", objective.get("direction", "maximize")), "source": "screening_surrogate_carried_with_partial_fea", "evidenceRefs": [], "confidence": min(0.55, float(screening_value.get("confidence", 0.55))), "verificationStatus": "screening"})  # 保留未验证目标的筛选分数但禁止其升级为工程证据。
            else:  # 处理既无当前 FEA 指标也无代理筛选值的目标。
                objective_values.append({"objectiveRef": objective_ref, "rawValue": 0.0, "normalizedValue": 0.0, "unit": objective.get("unit"), "direction": objective.get("direction", "maximize"), "source": "unresolved_objective_placeholder", "evidenceRefs": [], "confidence": 0.0, "verificationStatus": "unresolved"})  # 显式记录目标证据缺口而不是静默省略。
        constraint_checks: list[dict[str, Any]] = []  # 初始化覆盖全部硬约束的透明检查列表。
        for check in screening_result.get("constraintChecks", []) if isinstance(screening_result, dict) else []:  # 复用候选变量与参数化几何的筛选级约束检查。
            if isinstance(check, dict):  # 检查约束记录类型。
                constraint_checks.append({**deep_copy(check), "source": "materialized_geometry_and_variable_contract_screening", "evidenceRefs": [], "verificationStatus": "screening", "message": "参数化物化已复核变量契约，但当前 FEA 产物未独立验证该硬约束；规范、高保真几何与试验边界仍需补证。"})  # 保留约束结论并明确其仍为筛选级证据。
        evidenced, evidence_report = record_design_evidence(evidence_document, candidate_id, objective_values, constraint_checks, "finite_element", [artifact_id], actor)  # 写入带逐目标覆盖状态的部分 FEA 工程评价。
        evidence_report["completeForSelection"] = evidence_report.get("status") == "verified"  # 明确只有完整 verified 评价才能进入最终选择。
        evidence_report["unresolvedObjectiveRefs"] = list(evidence_report.get("unverifiedObjectiveRefs", []))  # 提供兼容字段并显式列出未完成工程验证的目标。
        preview_summary = {"candidateId": candidate_id, "artifactId": artifact_id, "runId": run_id, "meshPolicyRef": mesh_policy_ref, "loadCaseRef": load_case_ref, "globalMetrics": result.get("globalMetrics", {}), "structuralScore": structural_score, "displacementLimit": displacement_limit, "screening": screening_report, "materialization": materialization_report, "evidence": evidence_report, "authoritative": False}  # 构造设计候选预览摘要。
        self.repository.finish_run(run_id, result={"preview": preview_summary, "result": result})  # 保存成功运行结果和设计评价摘要。
        document_out, saved, validation = self._save_design_revision(project_id, evidenced, actor, "design_fea_preview", "BridgeMind 2.0 候选建模—计算—评价预览", input_revision, commit)  # 验证并可选保存完整生成式闭环状态。
        self._audit("design.candidate.preview", actor, "builtin_frame3d", "succeeded", preview_summary, project_id, saved.get("revision") if saved else input_revision)  # 保存候选预览成功审计。
        return {"document": document_out, "report": preview_summary, "validation": validation, "savedRevision": saved, "result": result, "downloadPath": self._artifact_relative_path(result_path)}  # 返回物化、计算、评价和证据结果。

    def record_project_design_evidence(self, project_id: str, candidate_id: str, objective_values: list[dict[str, Any]], constraint_checks: list[dict[str, Any]], evidence_level: str, evidence_refs: list[str], revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 把有限元、规范、试验或人工证据绑定到候选评价。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        updated, report = record_design_evidence(document, candidate_id, objective_values, constraint_checks, evidence_level, evidence_refs, actor)  # 写入工程证据评价。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_evidence", "BridgeMind 2.0 写入工程评价证据", input_revision, commit)  # 验证并可选保存工程证据。
        self._audit("design.evidence.record", actor, evidence_level, "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存工程证据审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回工程证据写入结果。

    def evaluate_project_design_candidates(self, project_id: str, brief_id: str | None = None, candidate_ids: list[str] | None = None, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 对项目候选执行多目标代理筛选。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        updated, report = evaluate_design_candidates(document, brief_id, candidate_ids, actor)  # 执行候选评价和 Pareto 排序。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_evaluation", "BridgeMind 2.0 评价设计候选", input_revision, commit)  # 验证并可选保存评价结果。
        self._audit("design.candidates.evaluate", actor, "design_agent", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存候选评价审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回候选评价结果。

    def record_project_design_feedback(self, project_id: str, candidate_id: str, decision: str, comment: str, variable_changes: dict[str, Any] | None = None, evidence_refs: list[str] | None = None, human_approval: bool = True, revision: int | None = None, commit: bool = True, actor: str = "human.web") -> dict[str, Any]:  # 保存人工候选选择、拒绝或修订反馈。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        updated, report = apply_design_feedback(document, candidate_id, decision, comment, actor, variable_changes, evidence_refs, human_approval)  # 执行人工反馈写回。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_feedback", "BridgeMind 2.0 保存人工设计反馈", input_revision, commit)  # 验证并可选保存反馈。
        self._audit("design.feedback.record", actor, "human", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存人工设计决策审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回人工反馈结果。

    def solidify_project_design_skill(self, project_id: str, decision_id: str, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 把人工批准设计决策固化为版本化 Skill 模板。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        updated, template = build_design_skill(document, decision_id, actor)  # 提炼设计技能模板和文档引用。
        saved_template = self.repository.save_template(template["templateId"], template["name"], template["kind"], template["body"], template["makeDefault"])  # 保存技能模板版本。
        template_summary = {**saved_template, "name": template["name"], "kind": template["kind"], "body": deep_copy(template["body"]), "makeDefault": bool(template["makeDefault"])}  # 合并仓库版本元数据与完整技能语义供审计和界面使用。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_skill", "BridgeMind 2.0 固化设计 Skill", input_revision, commit)  # 验证并可选保存技能引用。
        report = {"decisionId": decision_id, "template": template_summary, "commit": commit}  # 构造包含完整技能语义的固化报告。
        self._audit("design.skill.solidify", actor, "design_agent", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存技能固化审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回技能固化结果。

    def run_project_design_cycle(self, project_id: str, raw_text: str, candidate_count: int = 4, structured: dict[str, Any] | None = None, revision: int | None = None, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 执行意图—候选建模—数值计算—多目标评价闭环，并在人工最终决策前停止。
        loop = self.run_project_design_loop(project_id, raw_text, candidate_count, structured, revision, True, actor)  # 首先保存设计意图、候选和透明代理筛选。
        current_revision = int(loop["savedRevision"]["revision"])  # 读取设计候选修订号。
        candidate_ids = list(loop.get("report", {}).get("generation", {}).get("candidateIds", []))  # 读取本轮候选 ID。
        preview_reports = []  # 初始化逐候选建模—计算—评价记录。
        for candidate_id in candidate_ids:  # 依次对每个候选运行确定性几何和真实数值预览。
            preview = self.preview_project_design_candidate(project_id, candidate_id, current_revision, True, actor)  # 执行单候选闭环并保存审计修订。
            current_revision = int(preview["savedRevision"]["revision"])  # 推进到本次候选预览修订。
            preview_reports.append({"candidateId": candidate_id, "revision": current_revision, "runId": preview["report"]["runId"], "artifactId": preview["report"]["artifactId"], "globalMetrics": preview["report"]["globalMetrics"], "structuralScore": preview["report"]["structuralScore"], "downloadPath": preview["downloadPath"]})  # 保存候选计算摘要。
        final_document = self.repository.get_document(project_id, current_revision)  # 读取包含全部候选工程评价的最终比较文档。
        process = final_document.get("designProcess", {}) if isinstance(final_document.get("designProcess"), dict) else {}  # 读取设计过程对象。
        verified_results = [item for item in process.get("evaluationResults", []) if isinstance(item, dict) and item.get("candidateRef") in candidate_ids and item.get("status") == "verified" and item.get("evidenceLevel") != "screening_surrogate"]  # 收集本轮候选真正完成全部目标和硬约束验证的工程评价。
        verified_results.sort(key=lambda item: (not bool(item.get("feasible")), int(item.get("paretoRank") or 999999), -float(item.get("aggregateScore", 0.0)), str(item.get("candidateRef", ""))))  # 按可行性、Pareto 层级和加权分排序。
        screening_candidate = str(loop.get("report", {}).get("evaluation", {}).get("screeningBestCandidateRef") or (candidate_ids[0] if candidate_ids else ""))  # 读取透明代理筛选给出的展示候选。
        engineering_candidate = str(verified_results[0]["candidateRef"]) if verified_results else ""  # 只有完整 verified 结果存在时才形成工程推荐。
        display_candidate = engineering_candidate or screening_candidate  # 选择工程推荐或明确标注的代理筛选候选用于界面展示。
        recommendation_revision = current_revision  # 初始化展示候选物化修订。
        recommendation = None  # 初始化展示候选物化结果。
        if display_candidate:  # 检查是否存在可展示候选。
            recommendation = self.materialize_project_design_candidate(project_id, display_candidate, current_revision, True, actor, False)  # 把展示候选重新物化为当前可视和可分析模型。
            recommendation_revision = int(recommendation["savedRevision"]["revision"])  # 读取展示候选物化修订。
        report = {"mode": "intent-model-calculate-evaluate-stop-before-human-decision", "loop": loop["report"], "candidatePreviews": preview_reports, "engineeringRecommendationAvailable": bool(engineering_candidate), "engineeringRecommendedCandidateId": engineering_candidate or None, "screeningRecommendationCandidateId": screening_candidate or None, "displayCandidateId": display_candidate or None, "recommendationBasis": "verified_full_engineering_evaluation" if engineering_candidate else "screening_surrogate_plus_partial_fea_preview", "recommendedEvaluationResultId": verified_results[0].get("id") if verified_results else None, "comparisonRevision": current_revision, "finalRevision": recommendation_revision, "humanDecisionRequired": True, "authoritative": False, "limitations": ["内置空间梁 FEA 为真实数值计算但仅覆盖结构目标的窄域预览", "美学、经济、耐久和可建造性等未配置专用评价器的目标仍保持 screening 或 unresolved", "没有完整 verified 多目标工程评价时不得把代理筛选候选称为工程最优", "展示候选不能代替责任工程师选择、规范验算、高保真 FEA 与试验"]}  # 构造在人工决策门前停止的完整生成式设计闭环报告。
        self._audit("design.cycle.run", actor, "design_agent", "succeeded", report, project_id, recommendation_revision)  # 保存完整设计循环审计。
        return {"projectId": project_id, "report": report, "document": recommendation["document"] if recommendation is not None else final_document, "validation": recommendation["validation"] if recommendation is not None else validate_document(final_document), "savedRevision": recommendation["savedRevision"] if recommendation is not None else {"revision": current_revision}, "candidatePreviews": preview_reports}  # 返回完整建模—计算—评价闭环结果。

    def run_project_design_loop(self, project_id: str, raw_text: str, candidate_count: int = 4, structured: dict[str, Any] | None = None, revision: int | None = None, commit: bool = True, actor: str = "software.bridgemind.design") -> dict[str, Any]:  # 一次执行意图编译、候选生成和代理筛选。
        document = self.repository.get_document(project_id, revision)  # 读取目标项目修订。
        input_revision = int(document.get("revision", {}).get("number", revision or 1))  # 读取输入修订号。
        compiled, intent_report = compile_design_intent(document, raw_text, actor, structured)  # 编译设计意图。
        design_skills = self.repository.list_templates("design_skill")  # 读取人工固化设计技能用于动态知识嵌入。
        generated, generation_report = generate_design_candidates(compiled, intent_report["briefId"], candidate_count, actor, design_skills)  # 生成技能增强候选。
        updated, evaluation_report = evaluate_design_candidates(generated, intent_report["briefId"], generation_report["candidateIds"], actor)  # 执行透明代理筛选。
        report = {"intent": intent_report, "generation": generation_report, "evaluation": evaluation_report, "authoritative": False, "nextRequiredAction": "工程师确认设计目标和候选，物化候选并运行真实建模、FEA、规范检查或试验，再写入工程证据。"}  # 构造完整设计闭环报告。
        document_out, saved, validation = self._save_design_revision(project_id, updated, actor, "design_loop", "BridgeMind 2.0 运行生成式设计闭环", input_revision, commit)  # 验证并可选保存闭环状态。
        self._audit("design.loop.run", actor, "design_agent", "succeeded", report, project_id, saved.get("revision") if saved else input_revision)  # 保存完整设计闭环审计。
        return {"document": document_out, "report": report, "validation": validation, "savedRevision": saved}  # 返回完整设计闭环结果。

