# BSDL Industrial 1.1.0 语言规范增量

## 1. 定位

BSDL Industrial 1.1.0 保留 Industrial 1.0 的桥梁物理对象、分析对象、显式有限元、CalculiX、结果、规范验算、转换报告、版本与经验语义，并增加 BridgeMind 2.0 的设计意图、多目标候选和人机决策对象。

规范 Schema 为 `schema/bsdl-industrial.schema.json`。应用版本与语言版本分离：BridgeMind 为 `2.0.0`，BSDL Industrial 为 `1.1.0`。

## 2. 新增顶层对象

`designProcess` 是 BSDL 1.1 的上游设计过程容器，包含：

- `contexts`；
- `requirements`；
- `objectives`；
- `constraints`；
- `preferences`；
- `variables`；
- `briefs`；
- `candidates`；
- `evaluationPlans`；
- `evaluationResults`；
- `iterations`；
- `decisions`。

`designProcess.generativeLoop` 固定为：

```jsonc
[  // 固定生成式设计阶段顺序。
  "modeling",  // 生成并物化候选模型。
  "computation",  // 调用工程计算方法。
  "evaluation",  // 按目标与约束评价候选。
  "feedback"  // 将证据和人工决策反馈到下一轮建模。
]  // 结束固定阶段数组。
```

正式 BSDL 为 JSON，不允许注释；上例仅用于解释。

## 3. 设计语义与分析语义分层

- `DesignBrief` 说明为什么设计、优化什么、不能违反什么；
- `DesignCandidate` 说明本轮提出了什么方案；
- `Component` 等物理对象说明方案被物化成什么结构；
- `AnalysisTask` 说明怎样分析该结构；
- `MeshPolicy` 和 `SolverPlan` 说明怎样离散与执行；
- `EvaluationResult` 说明结果如何支持设计判断；
- `DesignDecision` 说明谁依据什么证据作出最终决定。

同一个设计候选可以对应多个任务化分析模型，不能把候选 ID、物理构件 ID 和有限元单元 ID 合并为一个身份。

## 4. 证据状态

目标值与约束检查使用 `verificationStatus`：

- `screening`；
- `verified`；
- `unresolved`。

候选评价结果使用：

- `needs_engineering_verification`；
- `partially_verified`；
- `verified`；
- `rejected`。

`verified` 必须覆盖评价计划中全部活动目标和硬约束，且每项引用现有工程证据。部分证据只能形成 `partially_verified`。

## 5. 人工责任

最终 `selected` 设计决策必须由 `kind=person` 的责任主体或明确的人类操作主体批准。批准记录必须绑定候选、完整评价结果、证据、时间、评论和修订。没有人类批准的 Agent 结果只能是提案、筛选或待审状态。

## 6. 与 Industrial 1.0 的兼容

`upgrade_document` 会：

1. 把语言版本升级为 `1.1.0`；
2. 保留既有稳定 ID 和工业对象；
3. 补建空 `designProcess`；
4. 固定四阶段生成式闭环；
5. 保留 CalculiX 2.23 工业主线；
6. 允许受严格限制的非权威 `builtin_frame3d` 候选预览。

原 Industrial 1.0 对象与实现边界仍可参考 `docs/BSDL_Industrial_1.0_语言规范.md`。
