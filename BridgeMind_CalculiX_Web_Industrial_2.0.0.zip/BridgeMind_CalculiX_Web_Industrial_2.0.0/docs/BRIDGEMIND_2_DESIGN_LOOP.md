# BridgeMind 2.0：代理驱动的生成式桥梁设计闭环

## 1. 设计原则

BridgeMind 2.0 不把“生成”定义为桥梁设计中的一个独立环节。生成式设计是由候选建模、性能计算、综合评价和反馈修订构成的循环方法：


a) `modeling`：构造候选桥梁方案，并将参数转化为实际 BSDL 对象；

b) `computation`：调用确定性网格、有限元、规范、试验或其他工程技能；

c) `evaluation`：依据活动目标、硬约束和证据进行评价；

d) `feedback`：由工程师或系统决定选择、拒绝、修订或发起下一轮候选建模。

Agent 位于闭环上层，负责理解意图、规划任务、选择方法、调用工具、读取反馈和推进下一轮设计。

## 2. 上游设计语义

BridgeMind 2.0 在 BSDL Industrial 1.1.0 中增加以下对象：

- `DesignContext`：场地、环境、使用功能和任务来源；
- `Requirement`：必须满足或需要审查的需求；
- `Objective`：安全、经济、造型、可建造性、耐久等优化目标；
- `Constraint`：设计变量或工程量的硬/软边界；
- `Preference`：工程师或业主偏好；
- `DesignVariable`：可被候选生成器修改的参数及其允许范围；
- `DesignBrief`：把上下文、需求、目标、约束、偏好和变量绑定为一次任务；
- `DesignCandidate`：一个可物化、可计算和可评价的候选；
- `EvaluationPlan`：规定本轮必须评价的目标和约束；
- `EvaluationResult`：保存代理筛选或工程证据评价；
- `DesignIteration`：固定记录四阶段闭环；
- `DesignDecision`：保存人类最终决策和证据；
- `DesignSkill` 引用：保存由批准决策提炼的可复用经验。

## 3. 语义连续性

BridgeMind 2.0 把以下关系显式保存：

```text
DesignBrief  # 说明设计目的、目标和边界。
→ DesignCandidate  # 说明候选由哪些变量和技能产生。
→ Component / Connection / Load  # 说明候选物化后的结构对象。
→ AnalysisTask / MeshPolicy / SolverPlan  # 说明怎样计算候选。
→ Artifact / ResultSet / EvaluationResult  # 说明计算结果和评价来源。
→ DesignDecision  # 说明谁依据哪些证据作出决定。
→ DesignSkill  # 说明哪类条件下可以复用什么动作及其失败边界。
```

稳定 ID、修订号、对象引用、文件哈希和转换报告用于保持跨模型、跨网格和跨版本追溯。

## 4. 候选生成

候选生成器接受 `DesignBrief` 和当前可用的 Design Skill。所有硬等式约束必须在候选变量中保持，不允许用代理模型自行改变。候选的 `provenance` 记录：

- 生成原型；
- 使用的设计技能；
- 生成主体；
- 变量来源；
- 受控模型补丁；
- 所属设计迭代。

当前确定性生成器支持桥塔、拱桥和最小梁系的窄域参数化线框，用于打通语义与计算链，不代表完整桥型库。

## 5. 建模与计算

候选物化后，系统生成真实 BSDL 节点、构件、连接、材料、截面、荷载、分析任务、网格策略和求解计划。内置 `builtin_frame3d` 执行真实空间梁数值计算，但必须满足：

- `authoritative=false`；
- `previewOnly=true`；
- 用途为候选筛选或生成式设计预览；
- 不能绑定 CalculiX 工业能力档案；
- 结果只能覆盖它实际计算到的目标。

高保真评价可由 CalculiX、规范验算、试验、监测或人工审查证据补充。

## 6. 评价与证据闸门

每个目标值和约束检查必须带有：

- `objectiveRef` 或 `constraintRef`；
- 原始值与归一值；
- 来源；
- 证据引用；
- 验证状态；
- 置信度或说明。

状态含义：

- `screening`：代理或启发式结果；
- `verified`：目标或约束已由可追溯工程证据支持；
- `unresolved`：当前没有足够证据。

候选级状态：

- `screening_only`：只有代理筛选；
- `partially_verified`：至少一项已验证，但仍有未验证目标或硬约束；
- `verified`：评价计划全部活动目标和硬约束均已验证。

系统拒绝以下行为：

- 把 `screening_surrogate`、`proxy_only`、`placeholder` 或 `unresolved` 来源标记为 `verified`；
- 使用不存在的证据引用；
- 用部分预览结果宣布完整多目标最优；
- 在没有人类批准时将候选标记为最终选择。

## 7. 人机反馈与技能固化

人工反馈支持 `selected`、`rejected`、`revise` 和 `pending`。`selected` 必须满足：

1. 候选存在非代理 `verified` 评价；
2. 评价引用真实证据对象；
3. 评价覆盖全部活动目标和硬约束；
4. `humanApproval=true`；
5. 决策记录操作者、时间、评论、变量修改和证据。

Design Skill 只能从上述批准决策中提炼，内容包括适用条件、推荐原型、变量动作、证据、适用边界和守门规则。后续候选生成可检索这些 Skill，并把 `skillRefs` 写入来源链。

## 8. 当前完成范围

已完成：

- BSDL 1.1 上游设计语义；
- 自然语言到结构化设计意图的规则化编译；
- 多目标候选生成；
- 参数化候选物化；
- 透明代理筛选；
- 真实空间梁预览；
- 工程证据写入；
- 人类最终选择闸门；
- Design Skill 固化与读回；
- Web、API、CLI 和自动化测试。

尚未声称完成：

- 通用自然语言理解；
- 全桥型参数化几何；
- 自动高保真壳/实体建模；
- 自动规范放行；
- 美学、耐久、经济和施工性的通用权威评价器；
- 无人审查工程决策。
