# BridgeMind CalculiX Web + BSDL Industrial 1.1 自检报告

结果：8 项通过，0 项失败。

## PASS · JSON Schema 元验证

```json
{
  "definitionCount": 27,
  "schemaId": "https://example.org/bridgemind/bsdl/0.1.0/bsdl.schema.json"
}
```

## PASS · 正式示例验证

```json
{
  "two_girder_bridge.bsdl.json": {
    "level": "L4-valid",
    "stats": {
      "entities": 51,
      "nodes": 10,
      "components": 14,
      "activeFrameComponents": 13,
      "regions": 0,
      "loads": 6,
      "constrainedDofs": 14,
      "validLoads": 6,
      "coordinateSystems": 1,
      "componentLengthMin": 6.0,
      "componentLengthMax": 10.0,
      "designProcessPresent": false,
      "designBriefs": 0,
      "designIterations": 0,
      "designCandidates": 0,
      "designEvaluations": 0,
      "designDecisions": 0
    }
  },
  "cantilever_3d.bsdl.json": {
    "level": "L4-valid",
    "stats": {
      "entities": 14,
      "nodes": 2,
      "components": 1,
      "activeFrameComponents": 1,
      "regions": 0,
      "loads": 1,
      "constrainedDofs": 6,
      "validLoads": 1,
      "coordinateSystems": 1,
      "componentLengthMin": 8.774964387392123,
      "componentLengthMax": 8.774964387392123,
      "designProcessPresent": false,
      "designBriefs": 0,
      "designIterations": 0,
      "designCandidates": 0,
      "designEvaluations": 0,
      "designDecisions": 0
    }
  }
}
```

## PASS · BridgeMind 2.0 生成式设计示例

```json
{
  "languageVersion": "1.1.0",
  "designVersion": "2.0.0",
  "generativeLoop": [
    "modeling",
    "computation",
    "evaluation",
    "feedback"
  ],
  "candidateCount": 4,
  "iterationCount": 1,
  "screeningCount": 4,
  "partialVerificationCount": 4,
  "verifiedCount": 0,
  "decisionCount": 0,
  "validationLevel": "L4-valid"
}
```

## PASS · 多专家认知与快速 FEA

```json
{
  "initialRegions": 24,
  "feedbackRegions": 26,
  "hotspots": 2,
  "landmarks": 26,
  "mesh": {
    "nodeCount": 154,
    "elementCount": 157,
    "componentCount": 13,
    "minElementLength": 0.09999999999999964,
    "maxElementLength": 1.2166666666666686,
    "meanElementLength": 0.7006369426751592,
    "meshPolicyRef": "mesh.default",
    "baseSize": 1.25
  },
  "globalMetrics": {
    "maxTranslation": 0.040958737845062716,
    "maxVerticalDisplacement": 0.040958737845062716,
    "maxAxial": 0.0,
    "maxShear": 300000.0,
    "maxMoment": 4500000.000173569,
    "forceBalanceResidual": 0.005259037250652909,
    "relativeForceBalanceResidual": 4.3825310422107575e-09,
    "conditionNumber": 6350154170.330154,
    "dofCount": 924,
    "freeDofCount": 910,
    "constrainedDofCount": 14,
    "loadCaseRef": "lc.service",
    "wallSeconds": 0.23811357900012808
  }
}
```

## PASS · 修订—反馈—经验—Adapter 闭环

```json
{
  "seededProjects": 4,
  "seededTemplates": 6,
  "strategyRevision": 2,
  "feedbackRevision": 3,
  "runStatus": "succeeded",
  "experienceCount": 27,
  "revisionCount": 3,
  "templateCount": 6,
  "exportAdapters": [
    "bsdl",
    "gmsh",
    "calculix"
  ]
}
```

## PASS · 点云分割到 BSDL

```json
{
  "inputPoints": 6100,
  "sampledPoints": 3694,
  "clusters": 3,
  "components": 4,
  "validationLevel": "L4-valid"
}
```

## PASS · FastAPI 与 Web 资源

```json
{
  "health": {
    "status": "ok",
    "version": "2.0.0",
    "languageVersion": "1.1.0",
    "projects": 4
  },
  "projectCount": 4,
  "templateCount": 6,
  "htmlBytes": 16179,
  "javascriptBytes": 133512,
  "stylesheetBytes": 19418
}
```

## PASS · JavaScript 语法

```json
{
  "node": "/opt/nvm/versions/node/v22.16.0/bin/node",
  "file": "web/app.js",
  "bytes": 133512
}
```
