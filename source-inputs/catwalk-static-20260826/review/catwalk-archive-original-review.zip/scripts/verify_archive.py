from pathlib import Path
import sys,json,hashlib,subprocess,os,math,importlib.util
from collections import defaultdict
root=Path('/workspace/c05-review')
repo=root/'model-source'
base=repo/'catwalk-fem/eval/formfind_974211b2'
spec=importlib.util.spec_from_file_location('legacy',base/'emit_cases.py')
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
model=legacy.load_mct()
reference=json.loads((base/'mct_review/mct_six_static_cases_independent_audit.json').read_text(encoding='utf-8-sig'))
solver=root/'solver/ccx-2.23-UCOR6-UCAB3-FT14-linux-x86_64'
def loadblocks(text):
 step=0;active=False;out=defaultdict(dict)
 for line in text.splitlines():
  if line.startswith('**'):continue
  if line.startswith('*'):
   key=line.split(',')[0].strip().upper()
   if key=='*STEP':step+=1
   active=key=='*CLOAD'
  elif active and line.strip():
   n,d,v=line.split(',')[:3]; k=(int(n),int(d));out[step][k]=out[step].get(k,0)+float(v)
 return out

def repaired(text):
 blocks=loadblocks(text); totals=dict(blocks[1])
 for k,v in blocks[2].items():totals[k]=totals.get(k,0)+v
 out=[];step=0;skip=False
 for line in text.splitlines():
  if line.startswith('**'):
   if not skip:out.append(line)
   continue
  if line.startswith('*'):
   skip=False
   key=line.split(',')[0].strip().upper()
   if key=='*STEP':step+=1
   if key=='*CLOAD' and step==2:
    out.append('*CLOAD, OP=NEW')
    out.extend(f'{n}, {d}, {v:.12g}' for (n,d),v in sorted(totals.items()))
    skip=True;continue
  if not skip:out.append(line)
 return '\n'.join(out)+'\n'
rows=[]
for case in range(1,7):
 p=repo/'catwalk-fem/eval/ccx_P1_nlgeom_974211b2/migrate_P1.inp' if case==1 else root/f'candidate-inputs/migrate_P{case}_20260826.inp'
 text=p.read_text();blocks=loadblocks(text)
 for variant in ['original']:
  folder=root/'archive-comparison'/f'P{case}'/variant;folder.mkdir(parents=True,exist_ok=True)
  inp=text if variant=='original' else repaired(text)
  (folder/'job.inp').write_text(inp)
  with (folder/'solver.log').open('w') as log:
   proc=subprocess.run([str(solver),'-i','job'],cwd=folder,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'},timeout=120)
  dat=(folder/'job.dat').read_text();u=legacy.parse_dat_u(dat);stresses=legacy.parse_dat_s(dat)
  axial=legacy.axial_from_s(model,stresses)
  nid,disp=max(u.items(),key=lambda item:sum(v*v for v in item[1]));umax=math.sqrt(sum(v*v for v in disp))
  ref=reference['cases'][str(case)];refmax=ref['displacement_extrema']['USUM']['absolute_value_mm']
  force_ref=legacy.parse_review_force_csv(base/f'mct_review/mct_case_{case}_element_force.csv')
  row={'case':case,'variant':variant,'input_sha256':hashlib.sha256(inp.encode()).hexdigest(),'exit_code':proc.returncode,'job_finished':'Job finished' in (folder/'solver.log').read_text(),'umax_mm':umax,'peak_node':nid,'peak_displacement_mm':disp,'reference_umax_mm':refmax,'reference_peak_node':ref['displacement_extrema']['USUM']['node_id'],'relative_error_percent':100*(umax/refmax-1),'force_comparison_to_mapdl':legacy.compare_forces(axial,force_ref,set(axial)),'cload_sums_N':{str(s):{str(d):sum(v for (n,k),v in loads.items() if k==d) for d in [1,2,3]} for s,loads in loadblocks(inp).items()}}
  row['span_force_comparison']=[]
  for g,key in zip(legacy.SPAN_GROUPS,['north_side_span','main_span','south_side_span','south_auxiliary_span']):
   members=model['groups'][g]['elems']
   eid,value=max(((eid,axial[eid]) for eid in members if eid in axial),key=lambda t:t[1])
   report=ref['span_force_comparison'][key]['report_kn']
   row['span_force_comparison'].append({'span':g,'element_id':eid,'ccx_kN':value/1000,'report_kN':report,'error_percent':100*(value/1000/report-1)})
  rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
  (root/'archive-comparison/results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
