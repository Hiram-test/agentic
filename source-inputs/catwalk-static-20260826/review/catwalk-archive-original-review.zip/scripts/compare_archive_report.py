import importlib.util,json,sys,re,math
from pathlib import Path
root=Path('/workspace/c05-review');repo=root/'model-source';base=repo/'catwalk-fem/eval/formfind_974211b2'
spec=importlib.util.spec_from_file_location('legacy',base/'emit_cases.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
model=m.load_mct()
rows=json.loads((root/'archive-comparison/results.json').read_text())
report=(root/'catwalk-inputs/review_report_text.txt').read_text()
portal_tables={}
text=report[report.index('表1-14  门架承重索强度验算表'):]
for c in range(1,7):
 match=re.search(r'工况'+str(c)+r'\s+承重索轴力MaxN（KN）\s+([\d\s]+?)\s+承重索破断力',text)
 portal_tables[c]=[float(x) for x in match.group(1).split()]
for row in rows:
 folder=root/'archive-comparison'/f"P{row['case']}"/row['variant']; dat=(folder/'job.dat').read_text();u=m.parse_dat_u(dat);stress=m.parse_dat_s(dat)
 forces={}
 for eid,ips in stress.items():
  el=model['elems'].get(eid)
  if not el or el['type']!='TENSTR':continue
  coords=[]
  for node in [el['n1'],el['n2']]:
   coords.append([model['nodes'][node][k]+u[node][i] for i,k in enumerate(['x','y','z'])])
  chord=[coords[1][i]-coords[0][i] for i in range(3)];L=math.sqrt(sum(x*x for x in chord));x,y,z=[v/L for v in chord]
  forces[eid]=sum(sx*x*x+sy*y*y+sz*z*z+2*txy*x*y+2*txz*x*z+2*tyz*y*z for sx,sy,sz,txy,txz,tyz in ips)/len(ips)*model['sections'][el['sec']]['area_mm2']
 row['force_recovery_method']='average global Cauchy stress projected on deformed chord, multiplied by original section area'
 for s in row['span_force_comparison']:
  eid,v=max(((eid,forces[eid]) for eid in model['groups'][s['span']]['elems'] if eid in forces),key=lambda p:p[1]);s.update(element_id=eid,ccx_kN=v/1000,error_percent=100*(v/1000/s['report_kN']-1))
 row['portal_force_comparison']=[]
 for g,ref in zip(m.PORTAL_CABLE_GROUPS,portal_tables[row['case']]):
  eid,v=max(((eid,forces[eid]) for eid in model['groups'][g]['elems'] if eid in forces),key=lambda p:p[1]);row['portal_force_comparison'].append({'span':g,'element_id':eid,'ccx_kN':v/1000,'report_kN':ref,'error_percent':100*(v/1000/ref-1)})
 print(row['case'],row['variant'],'bottom%', [round(s['error_percent'],3) for s in row['span_force_comparison']],'portal%', [round(s['error_percent'],3) for s in row['portal_force_comparison']])
(root/'archive-comparison/report_comparison.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
