"""把历史 BSDL 经验读回到新的区域网格策略中。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
import math  # 提供对数尺度和数值相似度计算。
from typing import Any  # 提供通用 JSON 类型注解。
from .cognition.features import extract_features  # 复用结构局部特征提取器。
from .utils import content_hash, deep_copy, utc_now  # 复用哈希、深复制和统一时间戳。


def _safe_float(value: Any, default: float | None = None) -> float | None:  # 把未知数值安全转换为浮点数。
    if isinstance(value, bool):  # 排除布尔值被当作整数的情况。
        return default  # 返回默认值。
    if isinstance(value, (int, float)) and math.isfinite(float(value)):  # 检查有限数值。
        return float(value)  # 返回规范浮点值。
    return default  # 对其他输入返回默认值。


def _round_optional(value: Any, digits: int = 4) -> float | None:  # 对可选数值进行稳定舍入。
    number = _safe_float(value)  # 尝试转换数值。
    return round(number, digits) if number is not None else None  # 返回舍入值或空值。


def _first_task(document: dict[str, Any]) -> dict[str, Any]:  # 选择文档首个有效分析任务。
    return next((item for item in document.get("analysisTasks", []) if isinstance(item, dict)), {})  # 返回首个任务或空对象。


def _base_size(document: dict[str, Any]) -> float:  # 获取当前文档的全局网格基准尺寸。
    policy = next((item for item in document.get("meshPolicies", []) if isinstance(item, dict)), {})  # 选择首个网格策略。
    base = _safe_float(policy.get("baseSize"), 1.0)  # 读取合法基准尺寸。
    return max(float(base or 1.0), 1e-9)  # 避免零尺寸造成归一化异常。


def _median_positive(values: list[float]) -> float | None:  # 计算正数列表的中位数而不引入额外依赖。
    ordered = sorted(value for value in values if value > 0.0 and math.isfinite(value))  # 过滤并排序正数。
    if not ordered:  # 检查是否存在有效数据。
        return None  # 无有效数据时返回空值。
    middle = len(ordered) // 2  # 计算中间索引。
    if len(ordered) % 2 == 1:  # 处理奇数长度。
        return float(ordered[middle])  # 返回中间值。
    return float((ordered[middle - 1] + ordered[middle]) * 0.5)  # 返回偶数长度的中位数。


def describe_region(document: dict[str, Any], region: dict[str, Any], features: dict[str, Any] | None = None) -> dict[str, Any]:  # 构造跨项目可比较的区域特征描述。
    feature_pack = features if isinstance(features, dict) else extract_features(document)  # 读取或现场计算结构特征。
    task = _first_task(document)  # 读取分析任务上下文。
    global_features = feature_pack.get("global", {}) if isinstance(feature_pack.get("global"), dict) else {}  # 读取全局尺度特征。
    median_length = max(float(_safe_float(global_features.get("medianLength"), 1.0) or 1.0), 1e-9)  # 获取稳定全局长度尺度。
    component_areas = [float(item.get("area", 0.0)) for item in feature_pack.get("components", {}).values() if isinstance(item, dict) and _safe_float(item.get("area"), 0.0)]  # 收集构件截面面积。
    median_area = _median_positive(component_areas) or 1.0  # 获取稳定截面面积尺度。
    descriptor: dict[str, Any] = {  # 初始化与项目本地 ID 无关的特征描述。
        "semanticType": str(region.get("semanticType", "unknown")),  # 保存区域语义类型。
        "geometryKind": str(region.get("geometry", {}).get("kind", "unknown")),  # 保存区域几何类别。
        "elementFamily": str(region.get("elementFamily", "auto")),  # 保存有限元单元族。
        "amrEngine": str(region.get("amrEngine", "none")),  # 保存网格细化机制。
        "taskType": str(task.get("type", "unknown")),  # 保存分析任务类型。
        "taskQoI": sorted(str(item) for item in task.get("qoi", []) if isinstance(item, str)),  # 保存任务关注量集合。
        "projectTags": sorted(str(item) for item in document.get("project", {}).get("tags", []) if isinstance(item, str)),  # 保存低权重项目标签。
        "targetSizeRatio": _round_optional((_safe_float(region.get("targetSize"), 0.0) or 0.0) / _base_size(document), 4),  # 保存相对基准尺寸而不是绝对尺寸。
        "meshLevel": int(region.get("meshLevel", 0)) if isinstance(region.get("meshLevel"), int) else 0,  # 保存网格等级。
        "targetKinds": {"node": 0, "component": 0},  # 初始化目标对象类别计数。
    }  # 完成基础描述初始化。
    representative: dict[str, Any] | None = None  # 初始化代表性局部特征。
    representative_kind: str | None = None  # 初始化代表性对象类型。
    for target_ref in region.get("targetRefs", []):  # 遍历区域作用对象但不保存具体 ID。
        if target_ref in feature_pack.get("nodes", {}):  # 检查目标是否为结构节点。
            descriptor["targetKinds"]["node"] += 1  # 增加节点目标计数。
            if representative is None:  # 仅选择首个可解释节点作为代表特征。
                representative = feature_pack["nodes"][target_ref]  # 读取节点局部特征。
                representative_kind = "node"  # 标记代表对象类型。
        elif target_ref in feature_pack.get("components", {}):  # 检查目标是否为结构构件。
            descriptor["targetKinds"]["component"] += 1  # 增加构件目标计数。
            if representative is None:  # 仅选择首个可解释构件作为代表特征。
                representative = feature_pack["components"][target_ref]  # 读取构件局部特征。
                representative_kind = "component"  # 标记代表对象类型。
    if representative_kind == "node" and isinstance(representative, dict):  # 处理节点型局部特征。
        descriptor["local"] = {  # 构造节点的跨项目不变量描述。
            "kind": "node",  # 标记局部对象类型。
            "degree": int(representative.get("degree", 0)),  # 保存节点连接度。
            "isSupport": bool(representative.get("isSupport", False)),  # 保存是否承担约束。
            "constraints": sorted(str(item) for item in representative.get("constraints", [])),  # 保存约束自由度模式。
            "incidentCategories": sorted(str(item) for item in representative.get("incidentCategories", [])),  # 保存相邻构件类别集合。
            "materialCount": int(representative.get("materialCount", 0)),  # 保存相邻材料种类数。
            "sectionAreaRatio": _round_optional(representative.get("sectionAreaRatio"), 3),  # 保存截面突变比。
            "minAngle": _round_optional(representative.get("minAngle"), 3),  # 保存局部最小夹角。
            "localScaleRatio": _round_optional((_safe_float(representative.get("localScale"), median_length) or median_length) / median_length, 3),  # 保存局部尺度相对全局尺度。
        }  # 完成节点描述。
    elif representative_kind == "component" and isinstance(representative, dict):  # 处理构件型局部特征。
        descriptor["local"] = {  # 构造构件的跨项目不变量描述。
            "kind": "component",  # 标记局部对象类型。
            "category": str(representative.get("category", "unknown")),  # 保存构件类别。
            "elementType": str(representative.get("elementType", "unknown")),  # 保存分析单元类型。
            "lengthRatio": _round_optional((_safe_float(representative.get("length"), median_length) or median_length) / median_length, 3),  # 保存构件长度相对全局尺度。
            "areaRatio": _round_optional((_safe_float(representative.get("area"), median_area) or median_area) / max(median_area, 1e-12), 3),  # 保存截面面积相对全局中位值。
        }  # 完成构件描述。
    else:  # 处理无法回映到结构对象的区域。
        descriptor["local"] = {"kind": "unknown"}  # 使用保守未知局部描述。
    return descriptor  # 返回跨项目特征描述。


def feature_signature(descriptor: dict[str, Any]) -> str:  # 根据规范化描述生成稳定特征签名。
    return content_hash(descriptor)[:20]  # 返回短哈希签名。


def build_action_descriptor(document: dict[str, Any], region: dict[str, Any] | None) -> dict[str, Any]:  # 把区域最终状态压缩成可迁移动作。
    if not isinstance(region, dict):  # 检查区域是否存在。
        return {"removed": True}  # 对删除区域记录显式移除动作。
    return {  # 返回只包含可迁移字段的动作描述。
        "removed": False,  # 标记区域仍然存在。
        "active": bool(region.get("active", True)),  # 保存区域启用状态。
        "meshLevel": int(region.get("meshLevel", 0)),  # 保存网格等级。
        "targetSizeRatio": round(float(region.get("targetSize", 1.0)) / _base_size(document), 6),  # 保存相对基准网格尺寸。
        "elementFamily": str(region.get("elementFamily", "auto")),  # 保存单元族。
        "amrEngine": str(region.get("amrEngine", "none")),  # 保存 AMR 引擎。
        "maxIterations": int(region.get("maxIterations", 0)),  # 保存允许迭代次数。
        "status": str(region.get("status", "proposed")),  # 保存历史确认状态。
        "source": str(region.get("source", "agent")),  # 保存历史动作来源。
    }  # 完成动作描述。


def _jaccard(first: list[str], second: list[str]) -> float:  # 计算两个离散集合的 Jaccard 相似度。
    first_set = set(first)  # 转换第一个集合。
    second_set = set(second)  # 转换第二个集合。
    if not first_set and not second_set:  # 处理两个集合均为空。
        return 1.0  # 空集视为完全一致。
    union = first_set | second_set  # 计算并集。
    return len(first_set & second_set) / max(len(union), 1)  # 返回交并比。


def _numeric_similarity(first: Any, second: Any, scale: float = 1.0) -> float:  # 计算两个数值的平滑相似度。
    left = _safe_float(first)  # 转换第一个数值。
    right = _safe_float(second)  # 转换第二个数值。
    if left is None or right is None:  # 检查任一数值缺失。
        return 0.5  # 缺失信息使用中性相似度。
    distance = abs(left - right) / max(abs(left), abs(right), float(scale), 1e-9)  # 计算归一化差异。
    return max(0.0, 1.0 - min(distance, 1.0))  # 返回限制在零到一的相似度。


def similarity(current: dict[str, Any], historical: dict[str, Any]) -> float:  # 计算当前区域与历史经验的结构相似度。
    if current.get("semanticType") != historical.get("semanticType"):  # 语义类型不同视为不可迁移。
        return 0.0  # 立即返回零分。
    weights: list[tuple[float, float]] = []  # 初始化各特征得分和权重。
    weights.append((0.24, 1.0))  # 语义类型完全一致贡献核心权重。
    weights.append((0.08, 1.0 if current.get("geometryKind") == historical.get("geometryKind") else 0.0))  # 比较区域几何类别。
    weights.append((0.10, 1.0 if current.get("elementFamily") == historical.get("elementFamily") else 0.0))  # 比较单元族。
    weights.append((0.08, 1.0 if current.get("taskType") == historical.get("taskType") else 0.0))  # 比较分析任务类型。
    weights.append((0.06, _jaccard(list(current.get("taskQoI", [])), list(historical.get("taskQoI", [])))))  # 比较任务关注量。
    current_local = current.get("local", {}) if isinstance(current.get("local"), dict) else {}  # 读取当前局部特征。
    history_local = historical.get("local", {}) if isinstance(historical.get("local"), dict) else {}  # 读取历史局部特征。
    if current_local.get("kind") != history_local.get("kind"):  # 检查局部对象类型是否一致。
        weights.append((0.12, 0.0))  # 类型不一致给予明显惩罚。
    elif current_local.get("kind") == "node":  # 处理节点型局部相似度。
        weights.append((0.10, _numeric_similarity(current_local.get("degree"), history_local.get("degree"), 1.0)))  # 比较节点度数。
        weights.append((0.08, 1.0 if current_local.get("isSupport") == history_local.get("isSupport") else 0.0))  # 比较支承属性。
        weights.append((0.07, _jaccard(list(current_local.get("constraints", [])), list(history_local.get("constraints", [])))))  # 比较约束模式。
        weights.append((0.07, _jaccard(list(current_local.get("incidentCategories", [])), list(history_local.get("incidentCategories", [])))))  # 比较相邻构件类别。
        weights.append((0.05, _numeric_similarity(current_local.get("sectionAreaRatio"), history_local.get("sectionAreaRatio"), 1.0)))  # 比较截面突变程度。
        weights.append((0.03, _numeric_similarity(current_local.get("localScaleRatio"), history_local.get("localScaleRatio"), 1.0)))  # 比较局部尺度比例。
        weights.append((0.04, _numeric_similarity(current_local.get("minAngle"), history_local.get("minAngle"), math.pi / 2.0)))  # 比较节点几何夹角。
    elif current_local.get("kind") == "component":  # 处理构件型局部相似度。
        weights.append((0.12, 1.0 if current_local.get("category") == history_local.get("category") else 0.0))  # 比较构件类别。
        weights.append((0.06, 1.0 if current_local.get("elementType") == history_local.get("elementType") else 0.0))  # 比较单元类型。
        weights.append((0.08, _numeric_similarity(current_local.get("lengthRatio"), history_local.get("lengthRatio"), 1.0)))  # 比较构件尺度比例。
        weights.append((0.07, _numeric_similarity(current_local.get("areaRatio"), history_local.get("areaRatio"), 1.0)))  # 比较截面尺度比例。
    else:  # 处理未知局部对象类型。
        weights.append((0.20, _numeric_similarity(current.get("meshLevel"), historical.get("meshLevel"), 2.0)))  # 使用网格等级作为弱替代特征。
    total_weight = sum(weight for weight, _ in weights)  # 计算总权重。
    total_score = sum(weight * score for weight, score in weights)  # 计算加权得分。
    return max(0.0, min(1.0, total_score / max(total_weight, 1e-9)))  # 返回规范化相似度。


def _legacy_descriptor(record: dict[str, Any]) -> dict[str, Any] | None:  # 为旧版经验构造保守兼容描述。
    after = record.get("after")  # 读取历史区域最终状态。
    if not isinstance(after, dict):  # 检查历史区域是否存在。
        return None  # 删除或非区域经验不参与读回。
    return {  # 构造不依赖项目局部 ID 的低信息描述。
        "semanticType": str(after.get("semanticType", "unknown")),  # 保存区域语义类型。
        "geometryKind": str(after.get("geometry", {}).get("kind", "unknown")),  # 保存几何类别。
        "elementFamily": str(after.get("elementFamily", "auto")),  # 保存单元族。
        "amrEngine": str(after.get("amrEngine", "none")),  # 保存 AMR 引擎。
        "taskType": "unknown",  # 旧经验缺少任务上下文。
        "taskQoI": [],  # 旧经验缺少关注量。
        "projectTags": [],  # 旧经验缺少可比较标签。
        "targetSizeRatio": None,  # 旧经验不安全迁移绝对尺寸。
        "meshLevel": int(after.get("meshLevel", 0)),  # 保存可迁移网格等级。
        "targetKinds": {"node": 0, "component": 0},  # 旧经验不猜测目标对象类型。
        "local": {"kind": "unknown"},  # 明确局部特征未知。
    }  # 返回旧版兼容描述。


def _action_from_record(record: dict[str, Any]) -> dict[str, Any] | None:  # 从经验记录读取可迁移动作。
    action = record.get("actionDescriptor")  # 优先读取新版动作描述。
    if isinstance(action, dict):  # 检查新版动作存在。
        return action  # 直接返回新版动作。
    after = record.get("after")  # 读取旧版最终区域。
    if not isinstance(after, dict):  # 检查旧版区域存在。
        return None  # 删除经验不用于自动读回。
    return {"removed": False, "active": bool(after.get("active", True)), "meshLevel": int(after.get("meshLevel", 0)), "targetSizeRatio": None, "elementFamily": str(after.get("elementFamily", "auto")), "amrEngine": str(after.get("amrEngine", "none")), "maxIterations": int(after.get("maxIterations", 0)), "status": str(after.get("status", "proposed")), "source": str(after.get("source", "agent"))}  # 对旧经验只安全迁移离散字段。


def _trust(record: dict[str, Any], action: dict[str, Any]) -> float:  # 根据来源和证据估计经验可信权重。
    source = str(action.get("source", "agent"))  # 读取经验动作来源。
    status = str(action.get("status", "proposed"))  # 读取经验确认状态。
    weight = 0.55  # 使用普通 Agent 建议作为最低基础可信度。
    if source == "human":  # 检查是否为人工修订经验。
        weight = 0.90  # 人工修订赋予较高可信权重。
    elif source == "fea":  # 检查是否来自计算反馈。
        weight = 0.82  # FEA 热点经验赋予较高可信权重。
    if status == "accepted":  # 检查历史状态是否明确接受。
        weight += 0.06  # 对明确批准经验增加权重。
    metrics = record.get("metrics", {}) if isinstance(record.get("metrics"), dict) else {}  # 读取运行与改进指标。
    if any(key not in {"changeCount"} for key in metrics):  # 检查是否附带计算或工程指标。
        weight += 0.03  # 对有额外证据的经验增加小幅权重。
    return max(0.0, min(1.0, weight))  # 返回零到一的可信权重。


def _weighted_average(items: list[tuple[float, float]]) -> float | None:  # 计算带权平均值。
    valid = [(value, weight) for value, weight in items if math.isfinite(value) and weight > 0.0]  # 过滤非法样本。
    if not valid:  # 检查是否存在有效样本。
        return None  # 无有效样本时返回空值。
    denominator = sum(weight for _, weight in valid)  # 计算权重总和。
    return sum(value * weight for value, weight in valid) / max(denominator, 1e-12)  # 返回带权平均。


def apply_memory(document: dict[str, Any], experiences: list[dict[str, Any]], current_project_id: str, min_score: float = 0.72, max_per_region: int = 3, include_same_project: bool = False, actor_id: str = "software.bridgemind", require_review: bool = True) -> tuple[dict[str, Any], dict[str, Any]]:  # 把跨项目经验安全读回当前策略。
    updated = deep_copy(document)  # 深复制文档以保持函数无副作用。
    features = extract_features(updated)  # 提取当前项目结构特征。
    base_size = _base_size(updated)  # 获取当前项目网格基准尺寸。
    candidate_records: list[dict[str, Any]] = []  # 初始化可用经验列表。
    for record in experiences:  # 遍历数据库返回的经验。
        if not isinstance(record, dict) or record.get("scopeType") != "region":  # 只处理区域级经验。
            continue  # 跳过策略级和项目级经验。
        if not include_same_project and record.get("projectId") == current_project_id:  # 默认阻止同项目自我泄漏。
            continue  # 跳过当前项目经验。
        action = _action_from_record(record)  # 读取可迁移动作。
        if not isinstance(action, dict) or action.get("removed") is True or action.get("active") is False:  # 排除删除和禁用经验。
            continue  # 跳过不可直接复用的历史动作。
        if str(action.get("status", "proposed")) in {"rejected", "archived"}:  # 排除被拒绝或归档经验。
            continue  # 跳过负面经验的正向读回。
        descriptor = record.get("featureDescriptor") if isinstance(record.get("featureDescriptor"), dict) else _legacy_descriptor(record)  # 读取新版或兼容旧版特征描述。
        if not isinstance(descriptor, dict):  # 检查经验特征是否可用。
            continue  # 跳过无法比较的经验。
        candidate_records.append({"record": record, "descriptor": descriptor, "action": action})  # 保存候选经验及解析结果。
    applied_ids: list[str] = []  # 初始化已应用经验 ID。
    per_region: list[dict[str, Any]] = []  # 初始化逐区域读回报告。
    applied_region_count = 0  # 初始化应用区域计数。
    matched_region_count = 0  # 初始化匹配区域计数。
    for region in updated.get("regions", []):  # 遍历当前策略区域。
        if not isinstance(region, dict) or region.get("source") != "agent" or region.get("active") is not True:  # 只读回普通 Agent 生成的活跃区域。
            continue  # 跳过人工、导入和 FEA 热点区域。
        current_descriptor = describe_region(updated, region, features)  # 构造当前区域跨项目特征描述。
        matches: list[dict[str, Any]] = []  # 初始化当前区域候选匹配。
        for candidate in candidate_records:  # 遍历历史经验候选。
            score = similarity(current_descriptor, candidate["descriptor"])  # 计算结构相似度。
            if score < float(min_score):  # 检查是否达到读回阈值。
                continue  # 低相似经验不进入策略。
            trust = _trust(candidate["record"], candidate["action"])  # 计算历史经验可信权重。
            matches.append({**candidate, "score": score, "weight": score * trust})  # 保存相似度和综合权重。
        matches.sort(key=lambda item: (-float(item["weight"]), -float(item["score"]), str(item["record"].get("createdAt", ""))))  # 按可信相似度稳定排序。
        selected = matches[: max(1, int(max_per_region))]  # 选择有限数量的最高质量经验。
        if not selected:  # 检查当前区域是否找到可读回经验。
            continue  # 没有匹配时保留原策略。
        matched_region_count += 1  # 增加匹配区域计数。
        target_ratios = [(float(item["action"]["targetSizeRatio"]), float(item["weight"])) for item in selected if _safe_float(item["action"].get("targetSizeRatio")) is not None]  # 收集可迁移相对尺寸。
        mesh_levels = [(float(item["action"].get("meshLevel", region.get("meshLevel", 0))), float(item["weight"])) for item in selected]  # 收集网格等级。
        max_iterations = [(float(item["action"].get("maxIterations", region.get("maxIterations", 0))), float(item["weight"])) for item in selected]  # 收集迭代次数。
        ratio = _weighted_average(target_ratios)  # 计算经验建议的相对网格尺寸。
        level = _weighted_average(mesh_levels)  # 计算经验建议的网格等级。
        iteration_count = _weighted_average(max_iterations)  # 计算经验建议的迭代次数。
        before = {"meshLevel": region.get("meshLevel"), "targetSize": region.get("targetSize"), "maxIterations": region.get("maxIterations"), "status": region.get("status")}  # 保存读回前关键策略字段。
        changed = False  # 初始化当前区域是否真正发生改变。
        if ratio is not None:  # 检查是否存在跨项目归一化尺寸经验。
            new_size = max(1e-6, min(base_size * 4.0, base_size * float(ratio)))  # 把历史相对尺寸投影到当前项目尺度并限制极端值。
            if abs(float(region.get("targetSize", new_size)) - new_size) > max(1e-9, new_size * 1e-9):  # 检查尺寸是否实质变化。
                region["targetSize"] = float(new_size)  # 写入当前项目尺度下的新目标尺寸。
                changed = True  # 标记区域已改变。
        if level is not None:  # 检查是否存在网格等级经验。
            new_level = max(0, min(10, int(round(level))))  # 规范化网格等级范围。
            if int(region.get("meshLevel", 0)) != new_level:  # 检查网格等级是否变化。
                region["meshLevel"] = new_level  # 写入经验网格等级。
                changed = True  # 标记区域已改变。
        if iteration_count is not None:  # 检查是否存在迭代次数经验。
            new_iterations = max(0, min(100, int(round(iteration_count))))  # 规范化迭代次数范围。
            if int(region.get("maxIterations", 0)) != new_iterations:  # 检查迭代次数是否变化。
                region["maxIterations"] = new_iterations  # 写入经验迭代次数。
                changed = True  # 标记区域已改变。
        experience_ids = [str(item["record"].get("experienceId")) for item in selected if item["record"].get("experienceId")]  # 收集本区域使用的经验 ID。
        region.setdefault("attributes", {})["memoryExperienceRefs"] = experience_ids  # 把经验来源写入区域可追溯属性。
        region["attributes"]["memoryTopScore"] = round(float(selected[0]["score"]), 6)  # 保存最高相似度。
        region["attributes"]["memoryMatchCount"] = len(selected)  # 保存参与聚合的经验数量。
        region["reason"] = list(dict.fromkeys(list(region.get("reason", [])) + [f"历史经验读回：{len(selected)} 条相似区域经验，最高相似度 {selected[0]['score']:.3f}"]))  # 增加可解释读回理由。
        if changed and require_review and region.get("status") not in {"accepted", "rejected"}:  # 检查是否需要人工复核。
            region["status"] = "needs_review"  # 经验迁移默认进入待复核状态。
        applied_ids.extend(experience_ids)  # 汇总整个项目使用的经验 ID。
        if changed:  # 检查本区域是否真正修改策略。
            applied_region_count += 1  # 增加应用区域计数。
        per_region.append({"regionRef": region.get("id"), "semanticType": region.get("semanticType"), "changed": changed, "before": before, "after": {"meshLevel": region.get("meshLevel"), "targetSize": region.get("targetSize"), "maxIterations": region.get("maxIterations"), "status": region.get("status")}, "matches": [{"experienceId": item["record"].get("experienceId"), "sourceProjectId": item["record"].get("projectId"), "score": round(float(item["score"]), 6), "weight": round(float(item["weight"]), 6)} for item in selected]})  # 保存逐区域可审计读回报告。
    applied_ids = sorted(set(applied_ids))  # 去重并稳定排序经验 ID。
    updated["experienceRefs"] = sorted(set(list(updated.get("experienceRefs", [])) + applied_ids))  # 把读回经验挂到当前 BSDL 修订。
    region_by_id = {str(region.get("id")): region for region in updated.get("regions", []) if isinstance(region, dict)}  # 建立区域索引用于同步网格策略。
    for policy in updated.get("meshPolicies", []):  # 遍历当前网格策略。
        if not isinstance(policy, dict):  # 跳过非法策略项。
            continue  # 继续检查下一策略。
        for rule in policy.get("regionRules", []):  # 遍历区域规则。
            if not isinstance(rule, dict):  # 跳过非法规则。
                continue  # 继续检查下一规则。
            region = region_by_id.get(str(rule.get("regionRef")))  # 查找对应区域。
            if isinstance(region, dict):  # 检查区域存在。
                rule["targetSize"] = float(region.get("targetSize", rule.get("targetSize", base_size)))  # 同步经验修订后的网格尺寸。
    landmark_by_region: dict[str, dict[str, Any]] = {}  # 初始化区域到地标映射。
    decision_edges = updated.get("cognitiveMap", {}).get("decisionEdges", []) if isinstance(updated.get("cognitiveMap"), dict) else []  # 读取认知地图决策边。
    landmarks = updated.get("cognitiveMap", {}).get("landmarks", []) if isinstance(updated.get("cognitiveMap"), dict) else []  # 读取认知地图地标。
    landmark_index = {str(item.get("id")): item for item in landmarks if isinstance(item, dict)}  # 建立地标索引。
    for edge in decision_edges:  # 遍历认知地图决策边。
        if not isinstance(edge, dict):  # 跳过非法决策边。
            continue  # 继续检查下一决策边。
        target_region = region_by_id.get(str(edge.get("toRef")))  # 查找决策边目标区域。
        if not isinstance(target_region, dict) or not target_region.get("attributes", {}).get("memoryExperienceRefs"):  # 检查目标区域是否应用经验。
            continue  # 非经验区域保持原决策来源。
        edge["source"] = "experience"  # 把决策来源标记为经验。
        edge["action"] = f"meshLevel={target_region.get('meshLevel')}, targetSize={target_region.get('targetSize')}"  # 同步经验修订后的动作。
        edge["condition"] = "; ".join(target_region.get("reason", [])) or "历史经验与当前结构特征匹配"  # 同步可解释触发条件。
        landmark = landmark_index.get(str(edge.get("fromRef")))  # 查找对应地标。
        if isinstance(landmark, dict):  # 检查地标存在。
            landmark.setdefault("featureVector", {})["meshLevel"] = target_region.get("meshLevel")  # 同步地标网格等级。
            landmark["featureVector"]["targetSize"] = target_region.get("targetSize")  # 同步地标目标尺寸。
            landmark_by_region[str(target_region.get("id"))] = landmark  # 记录已同步地标。
    feedback_id = f"feedback.memory.{len(updated.get('feedback', [])) + 1}"  # 生成经验读回反馈 ID。
    if applied_ids:  # 仅在实际命中经验时写入反馈。
        updated.setdefault("feedback", []).append({"id": feedback_id, "source": "agent", "kind": "experience", "createdAt": utc_now(), "createdBy": actor_id, "targetRefs": [item["regionRef"] for item in per_region], "before": {"candidateExperienceCount": len(candidate_records)}, "after": {"matchedRegionCount": matched_region_count, "appliedRegionCount": applied_region_count, "experienceRefs": applied_ids}, "metrics": {"candidateExperienceCount": len(candidate_records), "matchedRegionCount": matched_region_count, "appliedRegionCount": applied_region_count}, "comment": "BSDL 经验读回链根据跨项目结构特征匹配历史经验，并把可迁移动作投影到当前网格策略。", "status": "recorded"})  # 保存读回活动反馈。
    report = {"enabled": True, "candidateExperienceCount": len(candidate_records), "matchedRegionCount": matched_region_count, "appliedRegionCount": applied_region_count, "experienceRefs": applied_ids, "minScore": float(min_score), "maxPerRegion": int(max_per_region), "includeSameProject": bool(include_same_project), "perRegion": per_region}  # 汇总经验读回报告。
    return updated, report  # 返回更新文档和可审计读回报告。
