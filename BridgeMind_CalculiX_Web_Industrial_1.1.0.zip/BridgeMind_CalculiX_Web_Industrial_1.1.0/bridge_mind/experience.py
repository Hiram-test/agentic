"""把 BSDL 修订差异提取为可检索、可读回的局部结构经验。"""  # 说明模块用途。
from __future__ import annotations  # 启用延迟类型注解。
from typing import Any  # 提供通用 JSON 类型注解。
from .cognition.features import extract_features  # 导入统一结构特征提取器。
from .memory import build_action_descriptor, describe_region, feature_signature  # 导入跨项目经验描述与动作压缩工具。
from .utils import content_hash, json_diff, utc_now  # 复用内容哈希、JSON 差异和时间戳。


def _index(values: list[Any]) -> dict[str, dict[str, Any]]:  # 按 ID 索引对象数组。
    return {str(item["id"]): item for item in values if isinstance(item, dict) and isinstance(item.get("id"), str)}  # 返回稳定对象索引。


def extract_experiences(project_id: str, revision_from: int, revision_to: int, before: dict[str, Any], after: dict[str, Any], run_metrics: dict[str, Any] | None = None) -> list[dict[str, Any]]:  # 比较两个修订并生成结构化经验记录。
    before_regions = _index(before.get("regions", []))  # 索引旧修订区域。
    after_regions = _index(after.get("regions", []))  # 索引新修订区域。
    before_features = extract_features(before)  # 提取旧修订结构特征。
    after_features = extract_features(after)  # 提取新修订结构特征。
    records: list[dict[str, Any]] = []  # 初始化经验记录列表。
    all_region_ids = sorted(set(before_regions) | set(after_regions))  # 收集前后所有区域 ID。
    for region_id in all_region_ids:  # 遍历区域变化。
        previous = before_regions.get(region_id)  # 读取旧区域。
        current = after_regions.get(region_id)  # 读取新区域。
        if previous == current:  # 跳过完全未变化区域。
            continue  # 继续检查下一区域。
        reference = current or previous or {}  # 选择可用于特征提取的区域版本。
        reference_document = after if current is not None else before  # 选择与区域版本一致的文档。
        reference_features = after_features if current is not None else before_features  # 选择与区域版本一致的结构特征。
        descriptor = describe_region(reference_document, reference, reference_features)  # 构造不依赖项目局部 ID 的经验特征描述。
        action_descriptor = build_action_descriptor(after, current)  # 构造可迁移的最终动作描述。
        if previous is None:  # 判断区域新增。
            action = "新增区域"  # 设置动作摘要。
            outcome = "created"  # 设置经验结果状态。
        elif current is None:  # 判断区域删除。
            action = "删除区域"  # 设置动作摘要。
            outcome = "removed"  # 设置经验结果状态。
        else:  # 处理区域参数变化。
            action = "修改区域参数"  # 设置动作摘要。
            outcome = "modified"  # 设置经验结果状态。
        changes = json_diff(previous, current, f"/regions/{region_id}")  # 计算区域字段差异。
        semantic_type = reference.get("semanticType", "unknown")  # 读取区域语义类型。
        target_refs = reference.get("targetRefs", [])  # 读取区域目标对象用于人类可读摘要。
        summary = f"{action}：{semantic_type}，目标 {', '.join(target_refs) if target_refs else '未限定'}，共 {len(changes)} 项字段变化。"  # 生成确定性经验摘要。
        records.append({"experienceId": f"experience.{content_hash({'project': project_id, 'from': revision_from, 'to': revision_to, 'region': region_id})[:24]}", "projectId": project_id, "revisionFrom": revision_from, "revisionTo": revision_to, "scopeType": "region", "scopeRef": region_id, "featureSignature": feature_signature(descriptor), "featureDescriptor": descriptor, "actionDescriptor": action_descriptor, "before": previous, "after": current, "metrics": {"changeCount": len(changes), **(run_metrics or {})}, "summary": summary, "outcome": outcome, "tags": [str(semantic_type), str(reference.get("source", "unknown")), "region_strategy", "memory_ready"], "createdAt": utc_now()})  # 保存区域经验对象。
    before_policy = before.get("meshPolicies", [])  # 读取旧网格策略。
    after_policy = after.get("meshPolicies", [])  # 读取新网格策略。
    policy_changes = json_diff(before_policy, after_policy, "/meshPolicies")  # 计算网格策略整体变化。
    if policy_changes:  # 检查是否存在策略变化。
        records.append({"experienceId": f"experience.{content_hash({'project': project_id, 'from': revision_from, 'to': revision_to, 'scope': 'meshPolicy'})[:24]}", "projectId": project_id, "revisionFrom": revision_from, "revisionTo": revision_to, "scopeType": "mesh_policy", "scopeRef": after_policy[0].get("id") if after_policy and isinstance(after_policy[0], dict) else None, "featureSignature": content_hash({"projectTags": after.get("project", {}).get("tags", []), "taskTypes": [item.get("type") for item in after.get("analysisTasks", []) if isinstance(item, dict)]})[:20], "featureDescriptor": {"scopeType": "mesh_policy", "taskTypes": [item.get("type") for item in after.get("analysisTasks", []) if isinstance(item, dict)], "projectTags": sorted(after.get("project", {}).get("tags", []))}, "actionDescriptor": {"policyCount": len(after_policy)}, "before": before_policy, "after": after_policy, "metrics": {"changeCount": len(policy_changes), **(run_metrics or {})}, "summary": f"网格策略从 V{revision_from} 更新到 V{revision_to}，包含 {len(policy_changes)} 项变化。", "outcome": "modified", "tags": ["mesh_policy", "revision_diff"], "createdAt": utc_now()})  # 保存策略级经验对象。
    if not records:  # 处理没有区域或策略差异的情况。
        overall_changes = json_diff(before, after)  # 计算完整文档差异。
        if overall_changes:  # 检查是否存在其他变化。
            records.append({"experienceId": f"experience.{content_hash({'project': project_id, 'from': revision_from, 'to': revision_to, 'scope': 'project'})[:24]}", "projectId": project_id, "revisionFrom": revision_from, "revisionTo": revision_to, "scopeType": "project", "scopeRef": project_id, "featureSignature": content_hash({"tags": sorted(after.get("project", {}).get("tags", [])), "taskTypes": [item.get("type") for item in after.get("analysisTasks", []) if isinstance(item, dict)]})[:20], "featureDescriptor": {"scopeType": "project", "projectTags": sorted(after.get("project", {}).get("tags", [])), "taskTypes": [item.get("type") for item in after.get("analysisTasks", []) if isinstance(item, dict)]}, "actionDescriptor": {"projectRevision": revision_to}, "before": {"revision": before.get("revision")}, "after": {"revision": after.get("revision")}, "metrics": {"changeCount": len(overall_changes), **(run_metrics or {})}, "summary": f"项目从 V{revision_from} 更新到 V{revision_to}，共 {len(overall_changes)} 项文档变化。", "outcome": "modified", "tags": ["project", "revision_diff"], "createdAt": utc_now()})  # 保存项目级经验对象。
    return records  # 返回全部提取经验。
