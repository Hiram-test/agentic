"""验证 BSDL 经验写入、跨项目检索、策略读回和新用户继承闭环。"""  # 说明测试文件用途。
from pathlib import Path  # 提供项目根目录和临时路径处理。
from bridge_mind.memory import describe_region  # 导入跨项目区域特征描述器。
from bridge_mind.service import BridgeMindService  # 导入高层业务服务。
from bridge_mind.utils import deep_copy, load_json  # 导入深复制和示例读取工具。


def _sync_policy(document: dict, region: dict) -> None:  # 把人工区域修改同步到网格策略规则。
    policy = next(item for item in document.get("meshPolicies", []) if isinstance(item, dict))  # 选择当前首个网格策略。
    rule = next(item for item in policy.get("regionRules", []) if isinstance(item, dict) and item.get("regionRef") == region.get("id"))  # 查找对应区域规则。
    rule["targetSize"] = float(region["targetSize"])  # 同步人工修改后的目标网格尺寸。


def test_region_descriptor_does_not_store_project_local_target_ids(bridge_document: dict) -> None:  # 检查跨项目特征描述不会把本地对象 ID 当作泛化特征。
    service_root = Path(__file__).resolve().parents[1]  # 获取项目根目录供规则策略生成使用。
    service = BridgeMindService(service_root, service_root / "data" / "__descriptor_test.sqlite3")  # 创建只用于本测试的临时服务对象。
    try:  # 确保测试结束后删除临时数据库。
        service.repository.ensure_project(bridge_document)  # 确保示例项目进入临时数据库。
        proposed = service.propose_project_strategy("project.two_girder_bridge", commit=False, use_memory=False)["document"]  # 生成不使用历史经验的基础区域。
        region = next(item for item in proposed.get("regions", []) if isinstance(item, dict) and item.get("source") == "agent")  # 选择一个普通 Agent 区域。
        descriptor = describe_region(proposed, region)  # 构造跨项目可比较描述。
        serialized = str(descriptor)  # 把描述转换成便于断言的文本。
        for target_ref in region.get("targetRefs", []):  # 遍历当前区域本地对象 ID。
            assert str(target_ref) not in serialized  # 确认特征描述没有泄漏本地对象 ID。
        assert proposed.get("project", {}).get("id") not in serialized  # 确认项目 ID 不进入特征描述。
    finally:  # 无论断言是否成功都执行清理。
        path = service.repository.database_path  # 获取临时数据库路径。
        if path.exists():  # 检查数据库文件存在。
            path.unlink()  # 删除临时数据库文件。
        wal = Path(str(path) + "-wal")  # 构造 SQLite WAL 文件路径。
        shm = Path(str(path) + "-shm")  # 构造 SQLite SHM 文件路径。
        if wal.exists():  # 检查 WAL 文件存在。
            wal.unlink()  # 删除 WAL 文件。
        if shm.exists():  # 检查 SHM 文件存在。
            shm.unlink()  # 删除 SHM 文件。


def test_cross_project_memory_readback_changes_new_project_strategy(tmp_path: Path) -> None:  # 检查专家 A 的历史修订能直接改变新项目 B 的首次策略。
    root = Path(__file__).resolve().parents[1]  # 获取项目根目录。
    service = BridgeMindService(root, tmp_path / "memory.sqlite3", tmp_path / "runs")  # 使用隔离数据库和运行目录创建服务。
    service.seed_examples()  # 装入标准示例项目。
    service.seed_templates()  # 装入默认经验读回模板。
    source_project = "project.two_girder_bridge"  # 指定专家 A 用于产生经验的项目。
    v2 = service.propose_project_strategy(source_project, commit=True, use_memory=False)["document"]  # 生成无记忆基础策略并保存为 V2。
    human_document = deep_copy(v2)  # 深复制 V2 作为专家人工修订工作版本。
    human_region = next(item for item in human_document.get("regions", []) if isinstance(item, dict) and item.get("source") == "agent" and item.get("semanticType") == "support")  # 选择一个支承区域模拟专家修改。
    original_size = float(human_region["targetSize"])  # 保存 Agent 原始目标尺寸。
    human_region["source"] = "human"  # 标记最终决策来自人工专家。
    human_region["status"] = "accepted"  # 标记该经验已经人工确认。
    human_region["meshLevel"] = min(10, int(human_region["meshLevel"]) + 2)  # 让专家明确提高局部网格等级。
    human_region["targetSize"] = original_size * 0.5  # 让专家把局部目标尺寸减半形成可测迁移动作。
    human_region["reason"] = list(human_region.get("reason", [])) + ["专家 A 将支承局部尺寸减半"]  # 保存人工修改理由。
    _sync_policy(human_document, human_region)  # 同步人工尺寸到网格策略规则。
    saved = service.save_revision(source_project, human_document, "human.expert_a", "human", "专家 A 修改支承局部网格", "reviewed", 2)  # 保存人工修订为 V3。
    assert saved["revision"]["revision"] == 3  # 确认人工修订进入 V3。
    extracted = service.extract_and_save_experiences(source_project, 2, 3)  # 把 V2 到 V3 的差异提取为结构化经验。
    assert extracted["recordCount"] > 0  # 确认至少形成一条经验。
    assert any(isinstance(item.get("featureDescriptor"), dict) for item in extracted["records"] if item.get("scopeType") == "region")  # 确认区域经验具有跨项目特征描述。
    target_document = load_json(root / "examples" / "two_girder_bridge.bsdl.json")  # 读取相同结构家族作为未见项目 B。
    target_document["documentId"] = "doc.memory_holdout_bridge"  # 替换根文档稳定 ID。
    target_document["project"]["id"] = "project.memory_holdout_bridge"  # 替换项目 ID 以确保跨项目检索。
    target_document["project"]["name"] = "Memory Holdout Bridge"  # 设置留出项目名称。
    service.create_project(target_document, "human.new_user_b", "manual", "新用户 B 的严格留出项目")  # 创建未参与专家训练的新项目。
    target_project = "project.memory_holdout_bridge"  # 保存新项目 ID。
    baseline = service.propose_project_strategy(target_project, commit=False, use_memory=False)  # 生成完全不使用历史经验的对照策略。
    enhanced = service.propose_project_strategy(target_project, commit=False, use_memory=True)  # 使用同一模型和规则但开启经验读回。
    assert baseline["memory"]["enabled"] is False  # 确认对照组没有读取历史经验。
    assert enhanced["memory"]["enabled"] is True  # 确认实验组开启经验读回。
    assert enhanced["memory"]["candidateExperienceCount"] > 0  # 确认系统确实读取到专家 A 的历史经验。
    assert enhanced["memory"]["appliedRegionCount"] > 0  # 确认至少一个新项目区域被历史经验实质修改。
    memory_regions = [item for item in enhanced["document"].get("regions", []) if isinstance(item, dict) and item.get("attributes", {}).get("memoryExperienceRefs")]  # 收集真正应用历史经验的区域。
    assert memory_regions  # 确认新项目文档中存在经验增强区域。
    baseline_regions = {str(item.get("id")): item for item in baseline["document"].get("regions", []) if isinstance(item, dict)}  # 建立对照组区域索引。
    changed = [item for item in memory_regions if str(item.get("id")) in baseline_regions and (float(item.get("targetSize")) != float(baseline_regions[str(item.get("id"))].get("targetSize")) or int(item.get("meshLevel")) != int(baseline_regions[str(item.get("id"))].get("meshLevel")))]  # 找出读回后策略字段确实变化的区域。
    assert changed  # 确认产品行为改变来源于历史经验而不是单纯记录日志。
    assert enhanced["document"].get("experienceRefs")  # 确认当前 BSDL 修订显式引用使用过的历史经验。
    applied_ids = set(enhanced["document"].get("experienceRefs", []))  # 收集当前项目采用的经验 ID。
    source_ids = {item.get("experienceId") for item in extracted["records"]}  # 收集专家 A 本次产生的经验 ID。
    assert applied_ids.intersection(source_ids)  # 确认新项目实际引用来自专家 A 的经验。
    experience_edges = [edge for edge in enhanced["document"].get("cognitiveMap", {}).get("decisionEdges", []) if isinstance(edge, dict) and edge.get("source") == "experience"]  # 收集认知地图中的经验决策边。
    assert experience_edges  # 确认认知地图已经把决策来源更新为 experience。
    assert enhanced["validation"]["valid"] is True  # 确认经验读回后 BSDL 文档仍然合法。


def test_memory_preview_never_creates_revision(tmp_path: Path) -> None:  # 检查读回预览不会偷偷改变项目版本链。
    root = Path(__file__).resolve().parents[1]  # 获取项目根目录。
    service = BridgeMindService(root, tmp_path / "preview.sqlite3", tmp_path / "runs")  # 创建隔离测试服务。
    service.seed_examples()  # 装入示例项目。
    service.seed_templates()  # 装入经验策略模板。
    project_id = "project.two_girder_bridge"  # 指定测试项目。
    before = int(service.repository.get_document(project_id)["revision"]["number"])  # 读取预览前当前修订号。
    preview = service.preview_project_memory(project_id)  # 执行只读经验预览。
    after = int(service.repository.get_document(project_id)["revision"]["number"])  # 读取预览后当前修订号。
    assert preview["validation"]["valid"] is True  # 确认预览结果合法。
    assert before == after  # 确认预览没有创建任何新修订。
