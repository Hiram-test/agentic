# BSDL 跨项目经验读回链 v1.1

本版本把原有“Revision / Feedback / Run / Experience / Template 只负责记录”的闭环继续接通到下一次策略生成，使历史专家经验能够在不修改基础大模型权重的情况下直接影响新项目首次网格策略。基础规则专家仍先根据当前 BSDL 文档生成 Region 和 MeshPolicy；随后系统读取全局 Experience 数据库，把历史区域经验转换为与项目局部 ID、绝对坐标和绝对网格尺寸解耦的结构特征描述，执行相似度检索，并将可信的历史动作投影到当前项目尺度。

读回链固定执行顺序为：`当前 BSDL → 规则专家基础策略 → 跨项目特征描述 → Experience 检索 → 适用性评分 → 相对尺寸/等级投影 → needs_review → MeshPolicy 同步 → CognitiveMap 标记 experience → experienceRefs / Feedback / Audit 留痕 → FEA 再验证`。默认只使用其他项目的经验，避免同项目历史泄漏；人工区域、导入区域和 FEA 热点不会被历史经验覆盖。

跨项目特征描述重点保存语义类型、几何类别、单元族、分析任务、QoI、节点连接度、支承与约束模式、相邻构件类别、截面突变比、局部尺度比、构件类别和无量纲尺度，而不保存当前项目的 `targetRefs`、Project ID 或绝对坐标。历史 `targetSize` 不直接复制，保存并迁移的是 `targetSize / baseSize` 比值，因此相似经验可以投影到不同尺寸的结构上。

新版经验记录在原 SQLite `experiences` 表内兼容保存 `featureDescriptor` 与 `actionDescriptor`，无需迁移数据库 Schema。旧版 Experience 仍可读取，但由于缺少完整结构上下文，只进行保守兼容匹配，不迁移绝对网格尺寸。

默认 `memory_policy` 模板参数为：启用读回、最低相似度 0.72、最多读取 500 条经验、每个区域聚合最多 3 条、默认排除当前项目、经验迁移后必须人工复核。模板可通过现有 Template API 版本化修改。

策略接口 `POST /api/projects/{project_id}/strategy` 新增 `useMemory`、`memoryMinScore`、`memoryLimit`、`memoryMaxPerRegion` 和 `includeSameProjectMemory` 参数，响应新增 `memory` 报告。另增加 `POST /api/projects/{project_id}/memory/preview`，用于不创建 Revision 的读回预览。

验证重点不是“同一个专家越用越熟”，而是专家 A 在项目 A 中形成 Experience 后，新用户 B 在项目 B 首次运行策略时，即使基础模型、规则专家和输入任务保持不变，开启 Memory 后仍出现可追溯的策略变化。自动测试 `tests/test_memory_readback.py` 覆盖本地 ID 不进入特征签名、跨项目读回改变新项目策略、CognitiveMap 决策来源变为 `experience`、BSDL 验证仍通过，以及 Preview 不创建新 Revision。
