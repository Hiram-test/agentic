# BridgeMind CalculiX Web + BSDL Industrial 1.0 自检报告

自检日期：2026-08-13

## 总结

| 检查项 | 结果 |
|---|---|
| 自动化测试 | 26 通过，0 失败 |
| Python 编译 | 通过 |
| 前端 JavaScript 语法 | 通过 |
| JSON 文件解析 | 通过 |
| YAML 文件解析 | 通过 |
| Core 与 Industrial Schema 元校验 | 通过 |
| 工业主示例 | L4-valid，0 错误，0 警告 |
| 初始应力预应力夹具 | L4-valid，0 错误，0 警告 |
| 原生预紧夹具 | L4-valid，0 错误，0 警告 |
| 三个 CalculiX deck 静态检查 | 全部通过，0 错误，0 警告 |
| HTTP 冒烟 | 首页、Manifest、health、CalculiX status 均为 200 |
| 原生 CalculiX | 当前环境不可用，未执行原生数值求解 |
| IfcOpenShell | 当前环境不可用，未执行真实 IFC 解析 |
| Docker CLI | 当前环境不可用，未构建容器镜像 |

## 工业示例统计

主工业模型包含 33 个显式 FE 节点、16 个单元和 16 个集合，单元类型为 `S4R`、`C3D8R` 和 `T3D2`，同时包含 1 个摩擦接触、1 个预应力系统、4 个施工阶段和 1 个验算计划。生成的主 deck 为 288 行、97 个关键字和 5 个分析步；预应力初始应力 deck 为 278 行，原生预紧 deck 为 283 行。

## 测试覆盖

测试覆盖 API、移动 PWA、触屏手势、浏览器会话密钥、API 密钥中间件、项目修订、乐观并发、策略生成、内置梁系求解、点云导入、工业模型验证、CalculiX 混合单元导出、预应力关键字、外部进程与结果回读、结果修订、规则验算、IFC/MVD 契约、能力矩阵、生产路径和部署文件。

## 环境状态

验证环境使用 Python 3.13.5 和 Node.js 22.16.0。`ccx`、IfcOpenShell 和 Docker CLI 未安装；相应功能通过依赖检测明确显示不可用，没有用接口占位或测试替身伪装为原生能力。

## 可复核文件

- `reports/pytest.txt`：测试输出。
- `reports/source_checks.txt`：源码与环境检查。
- `reports/industrial_validation.json`：示例、deck、能力和环境的机器可读报告。
- `runs/industrial_demo/`：三个 CalculiX deck、ID Map 和转换报告。
- `PACKAGE_MANIFEST.json`：最终包内文件尺寸和 SHA-256。

## 投产前验收要求

在目标服务器安装或挂载 CalculiX 2.23 后，至少执行单元补丁测试、混合模型解析、接触启闭、预应力解析解、施工阶段回归、反力平衡、收敛和网格独立性；安装 IfcOpenShell 后，用实际桥梁 IFC 4.3 文件执行项目 MVD、GlobalId、坐标、单位、几何和属性映射测试；公网部署需构建镜像、启用 HTTPS、设置 API 密钥、验证备份恢复和配置作业资源限制。
